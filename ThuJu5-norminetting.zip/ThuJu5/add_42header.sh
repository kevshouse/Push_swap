#!/bin/bash

# 42 Header Generator Script
# Usage: ./add_42header.sh <filename>
# Example: ./add_42header.sh src/main.c

# Configuration - UPDATE THESE WITH YOUR INFO
USERNAME="keanders"
EMAIL="keanders@student.42.fr"

# Check if filename provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <filename>"
    echo "Example: $0 src/main.c"
    exit 1
fi

FILENAME="$1"
BASENAME=$(basename "$FILENAME")

# Get current date and time
DATE=$(date '+%Y/%m/%d %H:%M:%S')

# Determine file extension for proper commenting
EXT="${FILENAME##*.}"
case "$EXT" in
    "c"|"h"|"cpp"|"hpp"|"cc")
        COMMENT_START="/*"
        COMMENT_END="*/"
        COMMENT_MID="*"
        ;;
    "py")
        COMMENT_START="#"
        COMMENT_END="#"
        COMMENT_MID="#"
        ;;
    "sh")
        COMMENT_START="#"
        COMMENT_END="#"
        COMMENT_MID="#"
        ;;
    *)
        # Default to C-style comments
        COMMENT_START="/*"
        COMMENT_END="*/"
        COMMENT_MID="*"
        ;;
esac

# Generate the 42 header
generate_header() {
    if [[ "$EXT" == "py" || "$EXT" == "sh" ]]; then
        # Python/Shell style header
        cat << EOF
#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    $BASENAME$(printf "%*s" $((44 - ${#BASENAME})) ""):+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: $USERNAME <$EMAIL>$(printf "%*s" $((24 - ${#USERNAME} - ${#EMAIL})) "")+#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: $DATE by $USERNAME$(printf "%*s" $((14 - ${#USERNAME})) "")#+#    #+#              #
#    Updated: $DATE by $USERNAME$(printf "%*s" $((10 - ${#USERNAME})) "")###   ########.fr        #
#                                                                              #
# **************************************************************************** #

EOF
    else
        # C-style header
        cat << EOF
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   $(printf "%-51s" "$BASENAME"):+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: $USERNAME <$EMAIL>$(printf "%*s" $((18 - ${#USERNAME} - ${#EMAIL})) "")+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: $DATE by $USERNAME$(printf "%*s" $((10 - ${#USERNAME})) "")#+#    #+#             */
/*   Updated: $DATE by $USERNAME$(printf "%*s" $((6 - ${#USERNAME})) "")###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

EOF
    fi
}

# Check if file exists
if [ -f "$FILENAME" ]; then
    echo "File '$FILENAME' already exists."
    read -p "Do you want to prepend the header? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # Create temporary file with header + existing content
        TEMP_FILE=$(mktemp)
        generate_header > "$TEMP_FILE"
        cat "$FILENAME" >> "$TEMP_FILE"
        mv "$TEMP_FILE" "$FILENAME"
        echo "Header added to '$FILENAME'"
    else
        echo "Operation cancelled."
        exit 0
    fi
else
    # Create new file with header
    generate_header > "$FILENAME"
    echo "New file '$FILENAME' created with 42 header."
fi

# Make script files executable
if [[ "$EXT" == "sh" ]]; then
    chmod +x "$FILENAME"
    echo "Made '$FILENAME' executable."
fi

echo "Done!"