/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2024/01/01 00:00:00 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

#ifndef BUFFER_SIZE
# define BUFFER_SIZE 42
#endif

ssize_t	read_from_fd(int fd, char *tmp_buf)
{
	ssize_t	bytes_read;

	bytes_read = read(fd, tmp_buf, BUFFER_SIZE);
	if (bytes_read >= 0)
		tmp_buf[bytes_read] = '\0';
	return (bytes_read);
}

char	*update_buffer(char **buf, char *tmp_buf, ssize_t bytes_read)
{
	char	*new_buf;

	if (bytes_read <= 0)
		return (*buf);
	if (!*buf)
		new_buf = ft_strdup(tmp_buf);
	else
	{
		new_buf = ft_strjoin(*buf, tmp_buf);
		free(*buf);
	}
	*buf = new_buf;
	return (*buf);
}

static char	*extract_line(char **buf)
{
	char	*line;
	char	*newline_pos;
	char	*remainder;
	size_t	line_len;

	if (!*buf || !**buf)
		return (NULL);
	newline_pos = ft_strchr(*buf, '\n');
	if (newline_pos)
	{
		line_len = newline_pos - *buf + 1;
		line = ft_substr(*buf, 0, line_len);
		remainder = ft_strdup(newline_pos + 1);
		free(*buf);
		*buf = remainder;
		if (*buf && !**buf)
		{
			free(*buf);
			*buf = NULL;
		}
	}
	else
	{
		line = ft_strdup(*buf);
		free(*buf);
		*buf = NULL;
	}
	return (line);
}

char	*get_next_line(int fd)
{
	static char	*buffer;
	char		tmp_buf[BUFFER_SIZE + 1];
	ssize_t		bytes_read;
	char		*line;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	while (1)
	{
		if (buffer && ft_strchr(buffer, '\n'))
			break ;
		bytes_read = read_from_fd(fd, tmp_buf);
		if (bytes_read < 0)
		{
			if (buffer)
			{
				free(buffer);
				buffer = NULL;
			}
			return (NULL);
		}
		if (bytes_read == 0)
			break ;
		update_buffer(&buffer, tmp_buf, bytes_read);
	}
	line = extract_line(&buffer);
	return (line);
}