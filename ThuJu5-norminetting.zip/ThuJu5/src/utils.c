/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 00:43:08 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 00:45:29 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/utils.h"

t_bool	has_duplicates(const int *arr, int count)
{
	int	i;
	int	j;

	i = -1;
	while (++i < count - 1)
	{
		j = i;
		while (++j < count)
			if (arr[i] == arr[j])
				return (FT_TRUE);
	}
	return (FT_FALSE);
}
