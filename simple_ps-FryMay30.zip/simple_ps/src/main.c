#include "../include/machine.h"
#include "../include/sorting_machine.h"

int
main(int argc, char** argv)
{
    t_machine* m;

    if (argc < 2)
        return (1);
    m = machine_init(argc - 1, argv + 1);
    if (!m)
        return (1);
    sorting_control(m);
    machine_free(m);
    return (0);
}
