#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <stdio.h>
#include <limits.h>

static void sort_three(t_machine* m)
{
    if (machine_is_sorted(m, STACK_A)) {
        return;
    }

    int a = machine_top_value(m, STACK_A);
    machine_execute(m, OP_RA);
    int b = machine_top_value(m, STACK_A);
    machine_execute(m, OP_RRA);

    machine_execute(m, OP_RRA);
    int c = machine_top_value(m, STACK_A);
    machine_execute(m, OP_RA);

    if (a < b && b < c) {
        return;
    } else if (a < c && c < b) {
        machine_execute(m, OP_RRA);
        machine_execute(m, OP_SA);
    } else if (b < a && a < c) {
        machine_execute(m, OP_SA);
    } else if (c < a && a < b) {
        machine_execute(m, OP_RRA);
    } else if (b < c && c < a) {
        machine_execute(m, OP_RA);
    } else if (c < b && b < a) {
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RRA);
    }
}

static void sort_five(t_machine* m)
{
    // Push two smallest elements to B
    for (int i = 0; i < 2; i++) {
        int min_val = INT_MAX;
        size_t min_index = 0;
        size_t size = machine_stack_size(m, STACK_A);

        // Find min value and its position
        for (size_t j = 0; j < size; j++) {
            int val = machine_top_value(m, STACK_A);
            if (val < min_val) {
                min_val = val;
                min_index = j;
            }
            machine_execute(m, OP_RA);
        }

        // Bring min to top
        if (min_index <= size / 2) {
            for (size_t j = 0; j < min_index; j++) {
                machine_execute(m, OP_RA);
            }
        } else {
            for (size_t j = 0; j < size - min_index; j++) {
                machine_execute(m, OP_RRA);
            }
        }

        machine_execute(m, OP_PB);
    }

    // Sort remaining three
    sort_three(m);

    // Push back from B
    machine_execute(m, OP_PA);
    machine_execute(m, OP_PA);

    // Final rotation to correct order
    int min_value = INT_MAX;
    size_t size = machine_stack_size(m, STACK_A);
    size_t min_position = 0;

    for (size_t i = 0; i < size; i++) {
        int val = machine_top_value(m, STACK_A);
        if (val < min_value) {
            min_value = val;
            min_position = i;
        }
        machine_execute(m, OP_RA);
    }

    if (min_position <= size / 2) {
        for (size_t i = 0; i < min_position; i++) {
            machine_execute(m, OP_RA);
        }
    } else {
        for (size_t i = 0; i < size - min_position; i++) {
            machine_execute(m, OP_RRA);
        }
    }
}

void sorting_control(t_machine* m)
{
    if (!m) return;

    size_t size = machine_stack_size(m, STACK_A);

    if (size <= 1) {
        return;
    }

    if (size == 2) {
        int first = machine_top_value(m, STACK_A);
        machine_execute(m, OP_RA);
        int second = machine_top_value(m, STACK_A);
        machine_execute(m, OP_RRA);

        if (first > second) {
            machine_execute(m, OP_SA);
        }
    }
    else if (size == 3) {
        sort_three(m);
    }
    else if (size <= 5) {
        sort_five(m);
    }
}
