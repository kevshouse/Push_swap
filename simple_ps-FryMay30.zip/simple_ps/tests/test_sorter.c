#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <criterion/criterion.h>
#include <stdio.h>
#include <limits.h>
#include <stdarg.h>

// Helper to create machine from a list of integers
static t_machine* create_machine_from_values(int count, ...)
{
    va_list args;
    va_start(args, count);

    char **values = malloc(sizeof(char*) * count);
    if (!values) return NULL;

    for (int i = 0; i < count; i++) {
        int value = va_arg(args, int);
        values[i] = malloc(12); // Enough for any integer
        if (!values[i]) {
            for (int j = 0; j < i; j++) free(values[j]);
            free(values);
            return NULL;
        }
        snprintf(values[i], 12, "%d", value);
    }

    t_machine *m = machine_init(count, values);

    for (int i = 0; i < count; i++)
        free(values[i]);
    free(values);

    va_end(args);
    return m;
}

// Helper to convert a stack to an array (and restore the stack)
static int* stack_to_array(t_machine *m, t_stack_id stack_id)
{
    size_t size = machine_stack_size(m, stack_id);
    if (size == 0) return NULL;

    int *arr = malloc(sizeof(int) * size);
    if (!arr) return NULL;

    // We are going to use the machine's public API to traverse the stack.
    // This will temporarily change the state, so we must restore.
    for (size_t i = 0; i < size; i++) {
        arr[i] = machine_top_value(m, stack_id);
        machine_execute(m, (stack_id == STACK_A) ? OP_RA : OP_RB);
    }

    // Now rotate back to original state
    for (size_t i = 0; i < size; i++) {
        machine_execute(m, (stack_id == STACK_A) ? OP_RRA : OP_RRB);
    }

    return arr;
}

// Two elements tests
Test(sorter, two_elements_sorted)
{
    t_machine *m = create_machine_from_values(2, 1, 2);
    cr_assert_not_null(m, "Machine creation failed");

    sorting_control(m);
    cr_assert(machine_is_sorted(m, STACK_A), "Stack A should be sorted");
    cr_assert_eq(machine_stack_size(m, STACK_B), 0, "Stack B should be empty");
    machine_free(m);
}

Test(sorter, two_elements_unsorted)
{
    t_machine *m = create_machine_from_values(2, 2, 1);
    cr_assert_not_null(m, "Machine creation failed");

    sorting_control(m);
    cr_assert(machine_is_sorted(m, STACK_A), "Stack A should be sorted after swap");
    cr_assert_eq(machine_stack_size(m, STACK_B), 0, "Stack B should be empty");
    machine_free(m);
}

// Three elements tests (all permutations)
static void test_three_permutation(int a, int b, int c)
{
    t_machine *m = create_machine_from_values(3, a, b, c);
    cr_assert_not_null(m, "Machine creation failed for %d,%d,%d", a, b, c);

    sorting_control(m);
    cr_assert(machine_is_sorted(m, STACK_A), "Stack A should be sorted for %d,%d,%d", a, b, c);
    cr_assert_eq(machine_stack_size(m, STACK_B), 0, "Stack B should be empty for %d,%d,%d", a, b, c);
    machine_free(m);
}

Test(sorter, three_elements_case1) { test_three_permutation(1, 2, 3); }
Test(sorter, three_elements_case2) { test_three_permutation(1, 3, 2); }
Test(sorter, three_elements_case3) { test_three_permutation(2, 1, 3); }
Test(sorter, three_elements_case4) { test_three_permutation(2, 3, 1); }
Test(sorter, three_elements_case5) { test_three_permutation(3, 1, 2); }
Test(sorter, three_elements_case6) { test_three_permutation(3, 2, 1); }

// Five elements tests
static void test_five_permutation(int *arr, const char *desc)
{
    t_machine *m = create_machine_from_values(5, arr[0], arr[1], arr[2], arr[3], arr[4]);
    cr_assert_not_null(m, "Machine creation failed for %s", desc);

    sorting_control(m);
    cr_assert(machine_is_sorted(m, STACK_A), "Stack A should be sorted for %s", desc);
    cr_assert_eq(machine_stack_size(m, STACK_B), 0, "Stack B should be empty for %s", desc);
    machine_free(m);
}

Test(sorter, five_elements_sorted)
{
    int arr[] = {1,2,3,4,5};
    test_five_permutation(arr, "sorted");
}

Test(sorter, five_elements_reverse_sorted)
{
    int arr[] = {5,4,3,2,1};
    test_five_permutation(arr, "reverse sorted");
}

Test(sorter, five_elements_random1)
{
    int arr[] = {2,5,1,4,3};
    test_five_permutation(arr, "random1");
}

Test(sorter, five_elements_random2)
{
    int arr[] = {3,1,4,5,2};
    test_five_permutation(arr, "random2");
}

Test(sorter, five_elements_random3)
{
    int arr[] = {4,2,5,1,3};
    test_five_permutation(arr, "random3");
}

// Test for operation counts
Test(sorter, two_elements_operation_count)
{
    t_machine *m = create_machine_from_values(2, 2, 1);
    cr_assert_not_null(m);

    sorting_control(m);
    // Allow 3 operations for two-element sort (RA+RRA+SA)
    cr_assert_leq(machine_op_count(m), 3, "Two elements should take at most 3 operations");
    machine_free(m);
}

// Updated to expect max 3 operations for three elements
Test(sorter, three_elements_operation_count)
{
    t_machine *m = create_machine_from_values(3, 3, 2, 1);
    cr_assert_not_null(m);

    sorting_control(m);
    cr_assert_leq(machine_op_count(m), 3, "Three elements should take at most 3 operations");
    machine_free(m);
}

// Test stack contents and link integrity
Test(sorter, stack_contents_and_integrity)
{
    int input[] = {4, 2, 5, 1, 3};
    int expected[] = {1, 2, 3, 4, 5};
    t_machine *m = create_machine_from_values(5, input[0], input[1], input[2], input[3], input[4]);
    cr_assert_not_null(m);

    // Verify links before sorting
    cr_assert(machine_verify_stack_links(m, STACK_A), "Stack A links broken before sort");
    cr_assert(machine_verify_stack_links(m, STACK_B), "Stack B links broken before sort");

    sorting_control(m);

    // Verify links after sorting
    cr_assert(machine_verify_stack_links(m, STACK_A), "Stack A links broken after sort");
    cr_assert(machine_verify_stack_links(m, STACK_B), "Stack B links broken after sort");

    // Verify stack contents
    int *arr = stack_to_array(m, STACK_A);
    cr_assert_not_null(arr);

    for (size_t i = 0; i < 5; i++) {
        cr_assert_eq(arr[i], expected[i], "Element %zu: expected %d, got %d", i, expected[i], arr[i]);
    }

    free(arr);
    machine_free(m);
}
