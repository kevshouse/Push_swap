#ifndef LIBFT_H
# define LIBFT_H

# include <limits.h>
# include <stdlib.h>
# include <stdint.h>
# include <unistd.h>
# include "ft_printf.h"

int     ft_printf(const char *format, ...);
long	ft_atoi(const char *str);
long	ft_atol(const char *str);
char	**ft_split(char const *s, char c);
void	*ft_memcpy(void *dst, const void *src, size_t n);
int		ft_isdigit(int c);
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *str, int fd);
void	ft_putendl_fd(char *s, int fd);
void	ft_putstr_fd(char *str, int fd);
void	ft_swap(int *a, int *b);
void	ft_free_split(char **split);
int		ft_isvalidnum(const char *str);
void    ft_bzero(void* s, size_t n);
void    *ft_calloc(size_t count, size_t size);

#endif
