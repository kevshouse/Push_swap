/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atol.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/20 13:04:17 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 16:21:13 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

static int	skip_whitespace(const char *str, int *i)
{
	while (str[*i] == ' ' || (str[*i] >= '\t' && str[*i] <= '\r'))
		(*i)++;
	return (1);
}

static int	get_sign(const char *str, int *i)
{
	if (str[*i] == '-' || str[*i] == '+')
	{
		if (str[*i] == '-')
			return (-1);
		(*i)++;
	}
	return (1);
}

static int	check_overflow(long result, int sign, char digit)
{
	if (sign == 1 && (result > LONG_MAX / 10
			|| (result == LONG_MAX / 10 && (digit - '0') > LONG_MAX % 10)))
		return (1);
	if (sign == -1 && (result * sign < LONG_MIN / 10
			|| (result * sign == LONG_MIN / 10
				&& (digit - '0') > -(LONG_MIN % 10))))
		return (-1);
	return (0);
}

long	ft_atol(const char *str)
{
	long	result;
	int		sign;
	int		i;
	int		overflow;

	result = 0;
	i = 0;
	skip_whitespace(str, &i);
	sign = get_sign(str, &i);
	while (str[i] >= '0' && str[i] <= '9')
	{
		overflow = check_overflow(result, sign, str[i]);
		if (overflow == 1)
			return (LONG_MAX);
		if (overflow == -1)
			return (LONG_MIN);
		result = result * 10 + (str[i] - '0');
		i++;
	}
	return (result * sign);
}
