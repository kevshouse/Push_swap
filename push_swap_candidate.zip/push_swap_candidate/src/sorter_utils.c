/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 07:07:14 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include "../libft/includes/libft.h"
#include <limits.h>

int	find_max_index_in_b(t_machine *m)
{
	int		max_val;
	int		max_index;
	int		i;
	t_node	*current;

	if (!m || !m->b || !m->b->top)
		return (-1);
	max_val = m->b->top->value;
	max_index = 0;
	i = 0;
	current = m->b->top;
	while (current)
	{
		if (current->value > max_val)
		{
			max_val = current->value;
			max_index = i;
		}
		current = current->next;
		i++;
	}
	return (max_index);
}

void	push_b_to_a(t_machine *m)
{
	int	max_index;
	int	size_b;
	int	cost;

	while (machine_stack_size(m, STACK_B) > 0)
	{
		size_b = machine_stack_size(m, STACK_B);
		max_index = find_max_index_in_b(m);
		if (max_index >= 0 && size_b > 1)
		{
			cost = calculate_rotation_cost(m, max_index);
			if (ft_abs(cost) <= size_b / 3)
				rotate_to_top_b(m, max_index);
		}
		execution_dispatcher(m, OP_PA);
	}
}

void	rotate_min_to_top_a(t_machine *m)
{
	int		min_index;
	int		size_a;
	int		cost;
	int		k;

	min_index = find_min_index(m->a);
	if (min_index < 0)
		return ;
	size_a = m->a->size;
	k = 0;
	if (min_index < size_a - min_index)
		cost = min_index;
	else
		cost = -(size_a - min_index);
	if (cost > 0)
	{
		while (k++ < cost)
			execution_dispatcher(m, OP_RA);
	}
	else
	{
		while (k++ < -cost)
			execution_dispatcher(m, OP_RRA);
	}
}

int	find_closest_element_cost(t_machine *m, t_chunk_info info)
{
	t_node	*current;
	int		min_cost;
	int		i;
	int		stack_size;

	if (!m || !m->a || !m->a->top)
		return (INT_MAX);
	current = m->a->top;
	min_cost = INT_MAX;
	i = 0;
	stack_size = (int)machine_stack_size(m, STACK_A);
	while (current && i < stack_size)
	{
		if (current->value >= info.sorted_arr[info.start]
			&& current->value <= info.sorted_arr[info.end])
		{
			if (i < stack_size / 2 && i < min_cost)
				min_cost = i;
			else if (stack_size - i < min_cost)
				min_cost = stack_size - i;
		}
		current = current->next;
		i++;
	}
	return (min_cost);
}
