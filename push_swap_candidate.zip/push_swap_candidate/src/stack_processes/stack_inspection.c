/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_inspection.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 22:48:05 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"

int	machine_top_value(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s;

	if (stack_id == STACK_A)
		s = m->a;
	else
		s = m->b;
	if (!s || !s->top)
		return (0);
	return (s->top->value);
}

size_t	machine_stack_size(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s;

	if (stack_id == STACK_A)
		s = m->a;
	else
		s = m->b;
	if (!s)
		return (0);
	return (s->size);
}

t_bool	machine_is_sorted(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s;
	t_node			*current;

	if (stack_id == STACK_A)
		s = m->a;
	else
		s = m->b;
	if (!s || s->size < 2)
		return (FT_TRUE);
	current = s->top;
	while (current->next)
	{
		if (current->value > current->next->value)
			return (FT_FALSE);
		current = current->next;
	}
	return (FT_TRUE);
}

size_t	machine_op_count(const t_machine *m)
{
	if (!m)
		return (0);
	return (m->op_count);
}
