/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:06:00 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 23:49:36 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>

/* This file serves as a central include point for stack machine functionality.
 * The actual implementations are distributed across specialized files:
 * - stack_utils.c: Basic stack operations
 * - machine_init.c: Machine initialization
 * - machine_free.c: Machine cleanup
 * - stack_inspection.c: Stack inspection functions
 * - execution_dispatcher.c: Operation execution
 */