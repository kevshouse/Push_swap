/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine_init.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 19:35:54 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include "../../include/ft_bool.h"

static t_bool	setup_machine_stacks(t_machine *m, int count, char **values)
{
	int	*numbers;

	if (count == 0)
		return (FT_TRUE);
	if (!parse_arguments(count, values, &numbers))
		return (FT_FALSE);
	if (!validate_numbers(numbers, count))
	{
		free(numbers);
		return (FT_FALSE);
	}
	if (!create_stacks(m))
	{
		free(numbers);
		return (FT_FALSE);
	}
	populate_stack_a(m, numbers, count);
	free(numbers);
	return (FT_TRUE);
}

t_machine	*machine_init(int count, char **values)
{
	t_machine	*m;

	if (!validate_arguments(count, values))
		return (NULL);
	m = create_machine();
	if (!m)
		return (NULL);
	if (!setup_machine_stacks(m, count, values))
	{
		machine_free(m);
		return (NULL);
	}
	return (m);
}
