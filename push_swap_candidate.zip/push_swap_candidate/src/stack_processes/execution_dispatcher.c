/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execution_dispatcher.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 17:28:49 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:36:58 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include "../../include/ft_io.h"

static const char	*g_op_names[]
	= {[OP_SA]
	= "sa", [OP_SB]
	= "sb", [OP_SS]
	= "ss", [OP_PA]
	= "pa", [OP_PB]
	= "pb", [OP_RA]
	= "ra", [OP_RB]
	= "rb", [OP_RR]
	= "rr", [OP_RRA]
	= "rra", [OP_RRB]
	= "rrb", [OP_RRR] = "rrr", [OP_INVALID] = "unknown"};

static t_bool	is_valid_operation(t_operation op)
{
	return (op >= OP_SA && op <= OP_RRR);
}

static t_bool	is_stack_ready(t_stack *s, t_operation op)
{
	if (!s)
		return (FT_FALSE);
	if (op == OP_SA || op == OP_RA || op == OP_RRA)
		return (s->size >= 2);
	if (op == OP_SB || op == OP_RB || op == OP_RRB)
		return (s->size >= 2);
	if (op == OP_PA)
		return (s->size > 0);
	if (op == OP_PB)
		return (s->size > 0);
	if (op == OP_SS || op == OP_RR || op == OP_RRR)
		return (FT_TRUE);
	return (FT_FALSE);
}

static void	init_operations_array(void (*operations[])(t_machine *))
{
	operations[OP_SA] = do_sa;
	operations[OP_SB] = do_sb;
	operations[OP_SS] = do_ss;
	operations[OP_PA] = do_pa;
	operations[OP_PB] = do_pb;
	operations[OP_RA] = do_ra;
	operations[OP_RB] = do_rb;
	operations[OP_RR] = do_rr;
	operations[OP_RRA] = do_rra;
	operations[OP_RRB] = do_rrb;
	operations[OP_RRR] = do_rrr;
}

static t_bool	check_stack_readiness(t_machine *m, t_operation op)
{
	if (op == OP_SA || op == OP_RA || op == OP_RRA || op == OP_PB)
		return (is_stack_ready(m->a, op));
	else if (op == OP_SB || op == OP_RB || op == OP_RRB || op == OP_PA)
		return (is_stack_ready(m->b, op));
	else if (op == OP_SS || op == OP_RR || op == OP_RRR)
		return (is_stack_ready(m->a, op) || is_stack_ready(m->b, op));
	return (FT_TRUE);
}

void	execution_dispatcher(t_machine *m, t_operation op)
{
	const char	*op_name;
	void		(*operations[12])(t_machine *);
	t_bool		ready;

	if (!m)
	{
		ft_putstr_const_fd("Error: Null machine pointer\n", STDERR_FILENO);
		return ;
	}
	if (!is_valid_operation(op))
	{
		log_message(m, LOG_ERROR, "Invalid operation code");
		return ;
	}
	init_operations_array(operations);
	ready = check_stack_readiness(m, op);
	op_name = g_op_names[op];
	if (ready)
		operations[op](m);
}
