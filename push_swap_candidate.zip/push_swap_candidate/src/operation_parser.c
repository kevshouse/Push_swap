/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operation_parser.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 09:02:07 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../libft/includes/libft.h"

static int	ft_strcmp_local(const char *s1, const char *s2)
{
	if (!s1 || !s2)
		return (-1);
	while (*s1 && *s2 && *s1 == *s2)
	{
		s1++;
		s2++;
	}
	return ((unsigned char)*s1 - (unsigned char)*s2);
}

t_operation	parse_operation(const char *op_str)
{
	if (!op_str)
		return (OP_INVALID);
	if (ft_strcmp_local(op_str, "sa") == 0)
		return (OP_SA);
	if (ft_strcmp_local(op_str, "sb") == 0)
		return (OP_SB);
	if (ft_strcmp_local(op_str, "ss") == 0)
		return (OP_SS);
	if (ft_strcmp_local(op_str, "pa") == 0)
		return (OP_PA);
	if (ft_strcmp_local(op_str, "pb") == 0)
		return (OP_PB);
	if (ft_strcmp_local(op_str, "ra") == 0)
		return (OP_RA);
	if (ft_strcmp_local(op_str, "rb") == 0)
		return (OP_RB);
	if (ft_strcmp_local(op_str, "rr") == 0)
		return (OP_RR);
	if (ft_strcmp_local(op_str, "rra") == 0)
		return (OP_RRA);
	if (ft_strcmp_local(op_str, "rrb") == 0)
		return (OP_RRB);
	if (ft_strcmp_local(op_str, "rrr") == 0)
		return (OP_RRR);
	return (OP_INVALID);
}
