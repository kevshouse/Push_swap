/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_small.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 14:54:13 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"

static int	find_min_position(t_machine *m)
{
	t_node	*current;
	int		min_val;
	int		min_pos;
	int		pos;

	if (!m || !m->a || !m->a->top)
		return (-1);
	current = m->a->top;
	min_val = current->value;
	min_pos = 0;
	pos = 0;
	while (current)
	{
		if (current->value < min_val)
		{
			min_val = current->value;
			min_pos = pos;
		}
		current = current->next;
		pos++;
	}
	return (min_pos);
}

static void	rotate_min_to_top_small(t_machine *m, int min_pos)
{
	int	size;
	int	i;

	size = machine_stack_size(m, STACK_A);
	if (min_pos <= size / 2)
	{
		i = 0;
		while (i < min_pos)
		{
			execution_dispatcher(m, OP_RA);
			i++;
		}
	}
	else
	{
		i = 0;
		while (i < size - min_pos)
		{
			execution_dispatcher(m, OP_RRA);
			i++;
		}
	}
}

static void	sort_three_in_a(t_machine *m)
{
	int	a;
	int	b;
	int	c;

	if (!m || !m->a || m->a->size < 3)
		return ;
	a = m->a->top->value;
	b = m->a->top->next->value;
	c = m->a->top->next->next->value;
	if (a > b && b < c && a < c)
		execution_dispatcher(m, OP_SA);
	else if (a > b && b > c)
	{
		execution_dispatcher(m, OP_SA);
		execution_dispatcher(m, OP_RRA);
	}
	else if (a > b && b < c && a > c)
		execution_dispatcher(m, OP_RA);
	else if (a < b && b > c && a < c)
	{
		execution_dispatcher(m, OP_SA);
		execution_dispatcher(m, OP_RA);
	}
	else if (a < b && b > c && a > c)
		execution_dispatcher(m, OP_RRA);
}

void	sort_small(t_machine *m)
{
	size_t	size;
	int		min_pos;

	if (!m || !m->a)
		return ;
	size = machine_stack_size(m, STACK_A);
	while (size > 3)
	{
		min_pos = find_min_position(m);
		rotate_min_to_top_small(m, min_pos);
		execution_dispatcher(m, OP_PB);
		size--;
	}
	sort_three_in_a(m);
	while (machine_stack_size(m, STACK_B) > 0)
		execution_dispatcher(m, OP_PA);
}
