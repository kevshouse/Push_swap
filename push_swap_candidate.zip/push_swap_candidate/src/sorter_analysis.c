/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_analysis.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/07 00:48:24 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 06:56:04 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"

int	count_inversions(t_stack *stack)
{
	t_node	*current;
	t_node	*compare;
	int		inversions;

	if (!stack || !stack->top)
		return (0);
	inversions = 0;
	current = stack->top;
	while (current)
	{
		compare = current->next;
		while (compare)
		{
			if (current->value > compare->value)
				inversions++;
			compare = compare->next;
		}
		current = current->next;
	}
	return (inversions);
}

int	find_longest_sorted_sequence(t_stack *stack)
{
	t_node	*current;
	int		max_len;
	int		current_len;

	if (!stack || !stack->top)
		return (0);
	max_len = 1;
	current_len = 1;
	current = stack->top;
	while (current->next)
	{
		if (current->value < current->next->value)
			current_len++;
		else
		{
			if (current_len > max_len)
				max_len = current_len;
			current_len = 1;
		}
		current = current->next;
	}
	if (current_len > max_len)
		max_len = current_len;
	return (max_len);
}

int	find_median_position(t_stack *stack, int median_value)
{
	t_node	*current;
	int		position;

	if (!stack || !stack->top)
		return (-1);
	position = 0;
	current = stack->top;
	while (current)
	{
		if (current->value == median_value)
			return (position);
		current = current->next;
		position++;
	}
	return (-1);
}

int	analyse_stack_complexity(t_stack *stack)
{
	size_t	size;

	if (!stack)
		return (8);
	size = stack->size;
	if (size >= 500)
		return (size / 22);
	else if (size >= 100)
		return (size / 12);
	else
		return (size / 10);
}
