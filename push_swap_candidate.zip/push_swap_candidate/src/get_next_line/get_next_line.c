/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 07:36:40 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char	*extract_line(char *storage)
{
	char	*line;
	char	*newline_pos;
	size_t	len;
	size_t	i;

	if (!storage || !*storage)
		return (NULL);
	newline_pos = gnl_strchr(storage, '\n');
	if (newline_pos)
		len = newline_pos - storage + 1;
	else
		len = gnl_strlen(storage);
	line = malloc(len + 1);
	if (!line)
		return (NULL);
	i = 0;
	while (i < len)
	{
		line[i] = storage[i];
		i++;
	}
	line[i] = '\0';
	return (line);
}

static char	*update_storage(char *storage)
{
	char	*newline_pos;
	char	*new_storage;

	newline_pos = gnl_strchr(storage, '\n');
	if (!newline_pos)
	{
		free(storage);
		return (NULL);
	}
	new_storage = gnl_strdup(newline_pos + 1);
	free(storage);
	return (new_storage);
}

char	*get_next_line(int fd)
{
	static char	*storage;
	char		buffer[BUFFER_SIZE + 1];
	char		*line;
	ssize_t		bytes_read;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	bytes_read = 1;
	while (bytes_read > 0 && !gnl_strchr(storage, '\n'))
	{
		bytes_read = read(fd, buffer, BUFFER_SIZE);
		if (bytes_read < 0)
		{
			free(storage);
			storage = NULL;
			return (NULL);
		}
		buffer[bytes_read] = '\0';
		storage = gnl_strjoin(storage, buffer);
	}
	line = extract_line(storage);
	storage = update_storage(storage);
	return (line);
}