/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 08:59:49 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "get_next_line/get_next_line.h"
#include "../libft/includes/libft.h"
#include <string.h>
#include <unistd.h>

int	execute_operation_from_string(t_machine *m, const char *op_str);

void	print_error_and_exit(t_machine *m, const char *line)
{
	ft_putstr_fd("Error\n", STDERR_FILENO);
	if (line)
		free((char *)line);
	if (m)
		machine_free(m);
	exit(1);
}

static void	process_operations(t_machine *m, int fd)
{
	char	*line;
	size_t	len;

	line = get_next_line(fd);
	while (line != NULL)
	{
		len = 0;
		while (line[len] && line[len] != '\n')
			len++;
		if (line[len] == '\n')
			line[len] = '\0';
		if (len > 0)
		{
			if (!execute_operation_from_string(m, line))
				print_error_and_exit(m, line);
		}
		free(line);
		line = get_next_line(fd);
	}
}

static void	check_and_output_result(t_machine *m)
{
	if (machine_is_sorted(m, STACK_A) && machine_stack_size(m, STACK_B) == 0)
		ft_putstr_fd("OK\n", STDOUT_FILENO);
	else
		ft_putstr_fd("KO\n", STDOUT_FILENO);
}

int	main(int argc, char **argv)
{
	t_machine	*m;

	if (argc < 2)
		return (1);
	m = machine_init(argc - 1, argv + 1);
	if (!m)
	{
		ft_putstr_fd("Error\n", STDERR_FILENO);
		return (1);
	}
	process_operations(m, STDIN_FILENO);
	check_and_output_result(m);
	machine_free(m);
	return (0);
}
