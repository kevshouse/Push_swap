#!/usr/bin/env python3
import subprocess
import sys
import random

def analyze_push_swap(push_swap_path, numbers):
    """Analyze push_swap performance with given numbers"""
    try:
        # Run push_swap and get operations
        result = subprocess.run([push_swap_path] + [str(n) for n in numbers], 
                              capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"❌ Error running push_swap: {result.stderr}")
            return
        
        operations = result.stdout.strip().split('\n') if result.stdout.strip() else []
        op_count = len(operations)
        
        print(f"📊 Numbers: {numbers}")
        print(f"📈 Operations: {op_count}")
        print(f"📋 Operations: {', '.join(operations[:10])}{'...' if op_count > 10 else ''}")
        
        # Performance analysis
        size = len(numbers)
        if size <= 3:
            expected = "0-2"
        elif size <= 5:
            expected = "≤12"
        elif size <= 100:
            expected = "≤700"
        elif size <= 500:
            expected = "≤5500"
        else:
            expected = "N/A"
            
        print(f"🎯 Expected: {expected}, Actual: {op_count}")
        
        if size <= 100 and op_count <= 700:
            print("✅ Excellent performance!")
        elif size <= 500 and op_count <= 5500:
            print("✅ Good performance!")
        else:
            print("⚠️  Could be optimized")
            
        print("-" * 50)
        
    except Exception as e:
        print(f"❌ Error: {e}")

def main():
    push_swap_path = "./push_swap"
    
    if len(sys.argv) > 1:
        # Use provided numbers
        numbers = [int(x) for x in sys.argv[1:]]
        analyze_push_swap(push_swap_path, numbers)
    else:
        # Run standard tests
        print("🚀 Push_swap Performance Analyzer")
        print("=" * 50)
        
        # Test cases
        test_cases = [
            [3, 1, 2],
            [5, 2, 8, 1, 9, 3, 7, 6, 4],
            [15, 5, 21, 6, 24, 18, 25, 26, 33, 9],
            list(range(100, 0, -1))[:20],  # Reverse sorted
            random.sample(range(1, 101), 50),  # Random 50
        ]
        
        for i, numbers in enumerate(test_cases, 1):
            print(f"\n🔍 Test {i}:")
            analyze_push_swap(push_swap_path, numbers)

if __name__ == "__main__":
    main()
