#!/bin/bash

PUSH_SWAP="./push_swap"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

echo -e "${BLUE}🎯 Push_swap Performance Analysis${NC}"
echo -e "${BLUE}Based on 42 School Standards${NC}"
echo "======================================"

test_performance() {
    local size=$1
    local tests=$2
    local excellent=$3
    local good=$4
    local acceptable=$5
    
    echo -e "\n${PURPLE}Testing $size numbers ($tests tests):${NC}"
    
    local total=0
    local min=99999
    local max=0
    local excellent_count=0
    local good_count=0
    local acceptable_count=0
    
    for i in $(seq 1 $tests); do
        # Generate test numbers based on size
        if [ $size -eq 3 ]; then
            case $i in
                1) numbers=(3 1 2) ;;
                2) numbers=(2 3 1) ;;
                3) numbers=(1 3 2) ;;
                *) numbers=($(shuf -i 1-10 -n 3)) ;;
            esac
        elif [ $size -eq 5 ]; then
            numbers=($(shuf -i 1-10 -n 5))
        else
            numbers=($(shuf -i 1-$((size*2)) -n $size))
        fi
        
        # Run push_swap
        ops=$($PUSH_SWAP "${numbers[@]}" 2>/dev/null)
        exit_code=$?
        
        if [ $exit_code -eq 0 ]; then
            op_count=$(echo "$ops" | wc -l)
            total=$((total + op_count))
            
            [ $op_count -lt $min ] && min=$op_count
            [ $op_count -gt $max ] && max=$op_count
            
            # Categorize performance
            if [ $op_count -le $excellent ]; then
                echo -e "  Test $i: ${GREEN}$op_count ops (EXCELLENT)${NC} [${numbers[*]}]"
                ((excellent_count++))
            elif [ $op_count -le $good ]; then
                echo -e "  Test $i: ${BLUE}$op_count ops (GOOD)${NC} [${numbers[*]}]"
                ((good_count++))
            elif [ $op_count -le $acceptable ]; then
                echo -e "  Test $i: ${YELLOW}$op_count ops (ACCEPTABLE)${NC} [${numbers[*]}]"
                ((acceptable_count++))
            else
                echo -e "  Test $i: ${RED}$op_count ops (NEEDS WORK)${NC} [${numbers[*]}]"
            fi
        else
            echo -e "  Test $i: ${RED}FAILED${NC} [${numbers[*]}]"
        fi
    done
    
    local avg=$((total / tests))
    echo -e "\n${PURPLE}📊 RESULTS FOR $size NUMBERS:${NC}"
    echo -e "  Average: $avg operations"
    echo -e "  Range: $min - $max operations"
    echo -e "  Excellent: $excellent_count/$tests tests (≤$excellent ops)"
    echo -e "  Good: $good_count/$tests tests (≤$good ops)"
    echo -e "  Acceptable: $acceptable_count/$tests tests (≤$acceptable ops)"
    
    # Final verdict for this size
    echo -e "\n${PURPLE}🎯 VERDICT FOR $size NUMBERS:${NC}"
    if [ $avg -le $excellent ]; then
        echo -e "  ${GREEN}✅ EXCELLENT!${NC} Your algorithm is optimal for this size."
    elif [ $avg -le $good ]; then
        echo -e "  ${BLUE}✅ GOOD!${NC} Your algorithm performs well."
    elif [ $avg -le $acceptable ]; then
        echo -e "  ${YELLOW}✅ ACCEPTABLE.${NC} Meets minimum requirements."
    else
        echo -e "  ${RED}⚠️  NEEDS OPTIMIZATION.${NC} Consider improving for this size."
    fi
    
    return $avg
}

# Test all sizes with official 42 standards
test_performance 3 10 2 3 5
test_performance 5 10 12 15 20  
test_performance 100 5 700 900 1100
test_performance 500 3 5500 7000 11500

echo -e "\n${GREEN}🏆 OVERALL ASSESSMENT:${NC}"
echo "========================================="
echo "Your push_swap algorithm has been tested against official 42 standards."
echo "• 3 numbers: Generally excellent"
echo "• 5 numbers: May need optimization" 
echo "• Larger sets: Testing will show current performance"
echo ""
echo "Remember: Consistency matters more than perfect single tests!"
