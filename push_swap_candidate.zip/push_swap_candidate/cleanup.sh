#!/bin/bash

# Push_swap Project Cleanup Script
# Removes all non-essential files while preserving source code and requirements

echo "🧹 Cleaning push_swap project..."
echo "================================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to safely remove files/directories
safe_remove() {
    if [ -e "$1" ]; then
        echo -e "${YELLOW}Removing:${NC} $1"
        rm -rf "$1"
    fi
}

# Clean build artifacts
echo -e "${GREEN}Cleaning build artifacts...${NC}"
safe_remove "push_swap"
safe_remove "checker"
safe_remove "unit_tests"
safe_remove "*.o"
safe_remove "obj/"
safe_remove "libft/obj/"
safe_remove "libft/libft.a"

# Clean temporary and backup files
echo -e "${GREEN}Cleaning temporary files...${NC}"
safe_remove ".DS_Store"
safe_remove "*~"
safe_remove "*.swp"
safe_remove "*.swo"
safe_remove "*.tmp"
safe_remove "*.bak"
safe_remove "*.orig"
safe_remove "core"
safe_remove "a.out"
safe_remove "vgcore.*"

# Clean test output files
echo -e "${GREEN}Cleaning test outputs...${NC}"
safe_remove "output.txt"
safe_remove "test_ops.txt"
safe_remove "/tmp/ops"
safe_remove "*.log"

# Clean development/debug files
echo -e "${GREEN}Cleaning development files...${NC}"
safe_remove "bench_mark.sh"
safe_remove "check.sh" 
safe_remove "debug"
safe_remove "debug.txt"
safe_remove "valgrind.log"

# Clean editor files
echo -e "${GREEN}Cleaning editor files...${NC}"
find . -name ".vscode" -type d -exec rm -rf {} + 2>/dev/null
find . -name ".idea" -type d -exec rm -rf {} + 2>/dev/null
find . -name "*.sublime-*" -delete 2>/dev/null

# Clean system files
echo -e "${GREEN}Cleaning system files...${NC}"
find . -name "Thumbs.db" -delete 2>/dev/null
find . -name "*.DS_Store" -delete 2>/dev/null
find . -name "desktop.ini" -delete 2>/dev/null

# Clean git artifacts (if any)
echo -e "${GREEN}Cleaning git artifacts...${NC}"
safe_remove ".git"
safe_remove ".gitignore"

# Clean any accidental downloads or large files
echo -e "${GREEN}Cleaning large/misc files...${NC}"
find . -name "*.zip" -delete 2>/dev/null
find . -name "*.tar.gz" -delete 2>/dev/null
find . -name "*.pdf" -delete 2>/dev/null

echo ""
echo -e "${GREEN}✅ Files that will be KEPT (project essentials):${NC}"
echo "📁 Source files:"
find . -name "*.c" -o -name "*.h" | grep -v tests/ | sort
echo ""
echo "📁 Build files:"
find . -name "Makefile" | sort
echo ""
echo "📁 Criterion tests (preserved):"
find tests/ -name "*.c" -o -name "*.h" 2>/dev/null | sort

echo ""
echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}🎉 Cleanup complete!${NC}"
echo ""
echo -e "${YELLOW}Verify your project still compiles:${NC}"
echo "  make clean"
echo "  make"
echo "  make bonus"
echo ""
echo -e "${YELLOW}Final project structure:${NC}"
ls -la