#!/bin/bash

PUSH_SWAP="./push_swap"
CHECKER="./checker"

echo "🔍 DEBUGGING PUSH_SWAP PERFORMANCE"
echo "=================================="

# Check if files exist
echo "Checking files:"
echo "Push_swap: $(ls -la $PUSH_SWAP 2>/dev/null || echo 'NOT FOUND')"
echo "Checker: $(ls -la $CHECKER 2>/dev/null || echo 'NOT FOUND')"
echo ""

# Test 1: Simple 3 numbers
echo "Test 1: Testing 3 1 2"
echo "Command: $PUSH_SWAP 3 1 2"
ops=$($PUSH_SWAP 3 1 2 2>&1)
exit_code=$?
echo "Exit code: $exit_code"
echo "Output: '$ops'"
if [ $exit_code -eq 0 ]; then
    op_count=$(echo "$ops" | wc -l)
    echo "Operation count: $op_count"
    
    # Test with checker if available
    if [ -f "$CHECKER" ]; then
        result=$(echo "$ops" | $CHECKER 3 1 2 2>&1)
        echo "Checker result: '$result'"
    fi
else
    echo "❌ Push_swap failed!"
fi
echo ""

# Test 2: Five numbers
echo "Test 2: Testing 5 2 8 1 9"
echo "Command: $PUSH_SWAP 5 2 8 1 9"
ops=$($PUSH_SWAP 5 2 8 1 9 2>&1)
exit_code=$?
echo "Exit code: $exit_code"
echo "Output: '$ops'"
if [ $exit_code -eq 0 ]; then
    op_count=$(echo "$ops" | wc -l)
    echo "Operation count: $op_count"
    
    # Test with checker if available
    if [ -f "$CHECKER" ]; then
        result=$(echo "$ops" | $CHECKER 5 2 8 1 9 2>&1)
        echo "Checker result: '$result'"
    fi
else
    echo "❌ Push_swap failed!"
fi
echo ""

# Test 3: Random 10 numbers
numbers=($(shuf -i 1-20 -n 10))
echo "Test 3: Testing 10 random numbers: ${numbers[*]}"
echo "Command: $PUSH_SWAP ${numbers[*]}"
ops=$($PUSH_SWAP "${numbers[@]}" 2>&1)
exit_code=$?
echo "Exit code: $exit_code"
if [ $exit_code -eq 0 ]; then
    op_count=$(echo "$ops" | wc -l)
    echo "Operation count: $op_count"
    echo "First few operations: $(echo "$ops" | head -5 | tr '\n' ' ')"
    
    # Test with checker if available
    if [ -f "$CHECKER" ]; then
        result=$(echo "$ops" | $CHECKER "${numbers[@]}" 2>&1)
        echo "Checker result: '$result'"
    fi
else
    echo "❌ Push_swap failed!"
    echo "Error output: '$ops'"
fi
