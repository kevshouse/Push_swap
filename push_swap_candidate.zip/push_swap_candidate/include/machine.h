/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 16:59:51 by keanders          #+#    #+#             */
/*   Updated: 2025/06/07 15:25:36 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MACHINE_H
# define MACHINE_H

# include <stddef.h>
# include <stdlib.h>
# include "ft_bool.h"

/* Stack structures */
typedef struct s_node
{
	int				value;
	struct s_node	*prev;
	struct s_node	*next;
}					t_node;

typedef struct s_stack
{
	size_t			size;
	t_node			*top;
	t_node			*bottom;
}					t_stack;

/* Log levels */
typedef enum e_log_level
{
	LOG_NONE,
	LOG_ERROR,
	LOG_WARNING,
	LOG_INFO,
	LOG_DEBUG
}	t_log_level;

typedef enum e_operation
{
	OP_SA,
	OP_SB,
	OP_SS,
	OP_PA,
	OP_PB,
	OP_RA,
	OP_RB,
	OP_RR,
	OP_RRA,
	OP_RRB,
	OP_RRR,
	OP_INVALID
}	t_operation;

typedef enum e_stack_id
{
	STACK_A,
	STACK_B
}	t_stack_id;

typedef struct s_machine
{
	t_stack			*a;
	t_stack			*b;
	size_t			op_count;
	t_log_level		log_level;
	int				log_fd;
}	t_machine;

typedef struct s_push_chunks_params
{
	int		*sorted_arr;
	size_t	size;
	int		chunk_size;
}	t_push_chunks_params;

typedef struct s_chunk_info
{
	int		*sorted_arr;
	int		start;
	int		end;
	int		*count;
}	t_chunk_info;

/* Operation functions */
void		do_sa(t_machine *m);
void		do_sb(t_machine *m);
void		do_ss(t_machine *m);
void		do_pa(t_machine *m);
void		do_pb(t_machine *m);
void		do_ra(t_machine *m);
void		do_rb(t_machine *m);
void		do_rr(t_machine *m);
void		do_rra(t_machine *m);
void		do_rrb(t_machine *m);
void		do_rrr(t_machine *m);

/* Machine functions */
t_machine	*machine_init(int count, char **values);
void		execution_dispatcher(t_machine *m, t_operation op);

/* Machine helper functions */
t_bool		validate_arguments(int count, char **values);
t_bool		validate_numbers(int *numbers, int count);
t_machine	*create_machine(void);
t_bool		create_stacks(t_machine *m);
void		populate_stack_a(t_machine *m, int *numbers, int count);

/* Machine inspection functions */
size_t		machine_stack_size(const t_machine *m, t_stack_id stack_id);
int			machine_top_value(const t_machine *m, t_stack_id stack_id);
t_bool		machine_is_sorted(const t_machine *m, t_stack_id stack_id);
t_bool		machine_verify_stack_links(const t_machine *m, t_stack_id stack_id);
size_t		machine_op_count(const t_machine *m);
int			find_max_index_in_b(t_machine *m);
void		push_b_to_a(t_machine *m);
void		rotate_min_to_top_a(t_machine *m);

/* Stack verification functions */
t_bool		machine_verify_stack_links(const t_machine *m, t_stack_id stack_id);
void		machine_print_stack(const t_machine *m, t_stack_id stack_id);

/* Sorting utility functions */
void		rotate_to_top_b(t_machine *m, int index);
int			find_min_index(t_stack *stack);
int			find_max_index_in_b(t_machine *m);
void		push_b_to_a(t_machine *m);
void		rotate_min_to_top_a(t_machine *m);

/* Utility functions */
int			execute_operation_from_string(t_machine *m, const char *op_str);
t_stack		*stack_create(void);
void		stack_add_back(t_stack *s, int value);
//t_bool		parse_arguments(int count, char **values, int **numbers);

/* Cleanup and logging */
void		machine_free(t_machine *m);
void		init_logging(t_machine *m, t_log_level level, const char *filename);
void		log_message(t_machine *m, t_log_level level, const char *msg);

/* Validation functions */
t_bool		ft_isvalidnum(const char *str);
t_bool		ft_issafe(const char *str);
t_bool		has_duplicates(const int *arr, int count);
t_bool		parse_arguments(int count, char **values, int **numbers);

/* Operation parsing and execution */
t_operation	parse_operation(const char *op_str);
int			execute_operation_from_string(t_machine *m, const char *op_str);

/* I/O utility functions */
void		ft_putstr_const_fd(const char *s, int fd);
void		ft_putendl_const_fd(const char *s, int fd);
void		ft_putstr_const(const char *s);
void		ft_putendl_const(const char *s);
void		ft_putnbr_const_fd(int n, int fd);
void		ft_putnbr_const(int n);
void		print_error_and_exit(t_machine *m, const char *line);

#endif