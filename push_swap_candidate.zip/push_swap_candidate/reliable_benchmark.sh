#!/bin/bash

# Reliable Push_Swap Benchmark
# - Input validation
# - Detailed error reporting
# - Checker verification

# Configuration
TEST_COUNT=5
NUMBER_COUNT=100
CHECKER="./checker_linux"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Starting reliable benchmark${NC}"
echo "========================================"

total_success=0
total_fail=0

for ((i=1; i<=$TEST_COUNT; i++)); do
    # Generate and validate numbers
    NUMBERS=($(shuf -i 1-1000 -n $NUMBER_COUNT))
    UNIQUE_COUNT=$(printf "%s\n" "${NUMBERS[@]}" | sort -u | wc -l)

    if [ "$UNIQUE_COUNT" -ne "$NUMBER_COUNT" ]; then
        echo -e "${RED}Test $i: Duplicate numbers generated!${NC}"
        continue
    fi

    # Format argument string
    ARG="${NUMBERS[*]}"

    echo -e "${YELLOW}Test $i: Running with ${NUMBER_COUNT} numbers${NC}"

    # Run push_swap
    OPERATIONS=$(./push_swap $ARG 2> error.log)
    ERROR_OUTPUT=$(cat error.log)

    if [ -n "$ERROR_OUTPUT" ]; then
        echo -e "${RED}push_swap error: $ERROR_OUTPUT${NC}"
        total_fail=$((total_fail + 1))
        continue
    fi

    OP_COUNT=$(echo "$OPERATIONS" | wc -l | awk '{print $1}')

    # Run checker
    CHECKER_RESULT=$(echo "$OPERATIONS" | $CHECKER $ARG 2>&1)

    if [ "$CHECKER_RESULT" == "OK" ]; then
        echo -e "${GREEN}Success! Operations: $OP_COUNT${NC}"
        total_success=$((total_success + 1))
    else
        echo -e "${RED}Failure! Checker output: $CHECKER_RESULT${NC}"

        # Save failing test case
        echo "Failed input: $ARG" > "fail_$i.txt"
        echo "$OPERATIONS" >> "fail_$i.txt"

        total_fail=$((total_fail + 1))
    fi
done

echo "========================================"
echo -e "${YELLOW}Benchmark Summary${NC}"
echo "========================================"
echo -e "Tests run:      $TEST_COUNT"
echo -e "Successful:     ${GREEN}$total_success${NC}"
echo -e "Failed:         ${RED}$total_fail${NC}"
echo "========================================"

if [ $total_fail -gt 0 ]; then
    echo -e "${YELLOW}Analyzing failures...${NC}"
    for fail in fail_*.txt; do
        echo -e "${RED}Failure in $fail${NC}"
        head -n 5 "$fail"
        echo "..."
    done
fi
