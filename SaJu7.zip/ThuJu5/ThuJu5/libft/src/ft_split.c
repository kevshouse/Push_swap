/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/05 13:06:33 by keanders          #+#    #+#             */
/*   Updated: 2025/06/05 13:09:11 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

static size_t	count_words(char const *s, char c)
{
	size_t	count;
	int		in_word;

	count = 0;
	in_word = 0;
	while (*s)
	{
		if (*s != c && !in_word)
		{
			count++;
			in_word = 1;
		}
		else if (*s == c)
			in_word = 0;
		s++;
	}
	return (count);
}

static char	**free_array(char **arr, size_t i)
{
	while (i > 0)
		free(arr[--i]);
	free(arr);
	return (NULL);
}

static char	**split_one_word(char const *s, char c, t_split *state)
{
	while (s[state->start] == c)
		state->start++;
	state->end = state->start;
	while (s[state->end] && s[state->end] != c)
		state->end++;
	state->result[state->i] = malloc((state->end - state->start) + 1);
	if (!state->result[state->i])
		return (free_array(state->result, state->i));
	ft_memcpy(state->result[state->i], s + state->start,
		state->end - state->start);
	state->result[state->i][state->end - state->start] = '\0';
	state->start = state->end;
	state->i++;
	return (state->result);
}

char	**ft_split(char const *s, char c)
{
	t_split	state;

	if (!s)
		return (NULL);
	state.word_count = count_words(s, c);
	state.result = malloc((state.word_count + 1) * sizeof(char *));
	if (!state.result)
		return (NULL);
	state.i = 0;
	state.start = 0;
	while (state.i < state.word_count)
	{
		if (split_one_word(s, c, &state) == NULL)
			return (NULL);
	}
	state.result[state.word_count] = NULL;
	return (state.result);
}
