# Push_swap Project File Review Checklist

## Project Overview
This checklist covers all source files, headers, and build configurations for the push_swap project including the bonus checker implementation.

---

## 🔴 **HIGH PRIORITY FILES** (Review First)

### Core Headers
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `include/machine.h` | Main machine API and data structures | **CRITICAL** - Core interface |
| [ ] | `include/sorting_machine.h` | Sorting algorithm interface | **CRITICAL** - Main program logic |
| [ ] | `include/ft_bool.h` | Boolean type definitions | Standard types |
| [ ] | `include/ft_io.h` | I/O utilities interface | Supporting utilities |

### Main Programs
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `src/main.c` | **push_swap main program** | **CRITICAL** - Entry point |
| [ ] | `src/checker.c` | **Bonus checker program** | **NEW** - Bonus implementation |
| [ ] | `src/sorter.c` | Core sorting algorithm | **CRITICAL** - Main logic |

### Build System
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `Makefile` | **Build configuration** | **CRITICAL** - Updated for bonus |

---

## 🟡 **MEDIUM PRIORITY FILES** (Core Implementation)

### Stack Machine Implementation
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `src/stack_processes/machine_init.c` | Machine initialization | Core functionality |
| [ ] | `src/stack_processes/machine_free.c` | Memory cleanup | Memory management |
| [ ] | `src/stack_processes/stack_machine.c` | Stack data structure | Core data handling |
| [ ] | `src/stack_processes/stack_utils.c` | Stack utility functions | Supporting functions |
| [ ] | `src/stack_processes/stack_inspection.c` | Stack analysis functions | Debugging/validation |
| [ ] | `src/stack_processes/execution_dispatcher.c` | Operation execution | Command processing |

### Stack Operations
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `src/stack_processes/operations_p.c` | Push operations (pa, pb) | Core operations |
| [ ] | `src/stack_processes/operations_s.c` | Swap operations (sa, sb, ss) | Core operations |
| [ ] | `src/stack_processes/operations_r.c` | Rotate operations (ra, rb, rr) | Core operations |
| [ ] | `src/stack_processes/operations_rr.c` | Reverse rotate (rra, rrb, rrr) | Core operations |

### Bonus Implementation
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `src/operation_parser.c` | **Parse operation strings** | **NEW** - For checker |
| [ ] | `src/get_next_line/get_next_line.h` | **GNL header** | **NEW** - External dependency |
| [ ] | `src/get_next_line/get_next_line.c` | **GNL main function** | **NEW** - Read stdin |
| [ ] | `src/get_next_line/get_next_line_utils.c` | **GNL utilities** | **NEW** - String functions |

### Supporting Files
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `src/log_utils.c` | Logging utilities | Debugging support |
| [ ] | `src/ft_putstr_const.c` | String output utility | I/O helper |

---

## 🟢 **LOW PRIORITY FILES** (Testing & Documentation)

### Test Files
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `tests/test_framework.c` | Criterion test setup | Testing infrastructure |
| [ ] | `tests/test_stack_machine.c` | Stack machine tests | Unit tests |
| [ ] | `tests/test_sorter.c` | Sorting algorithm tests | Algorithm validation |
| [ ] | `tests/test_validation.c` | Input validation tests | Error handling tests |
| [ ] | `tests/test_minimal.c` | Minimal test cases | Basic functionality |

### Libft Integration
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `libft/includes/libft.h` | Libft function declarations | External library |
| [ ] | `libft/includes/ft_printf.h` | Printf function interface | External library |
| [ ] | `libft/Makefile` | Libft build configuration | External library |

### Utility Scripts & Documentation
| ✅ | File Path | Description | Notes |
|---|-----------|-------------|-------|
| [ ] | `ToDo.md` | Project TODO list | Development tracking |
| [ ] | `check.sh` | Testing script | Automated testing |
| [ ] | `diagnostics.sh` | Diagnostic script | Debugging helper |
| [ ] | `bench_mark.sh` | Performance testing | Performance analysis |
| [ ] | `format42.sh` | Code formatting | Code style |

---

## 📋 **Review Guidelines**

### For Each File, Check:
- [ ] **Norminette compliance** (42 coding standard)
- [ ] **Memory leaks** (proper malloc/free pairs)
- [ ] **Error handling** (edge cases covered)
- [ ] **Function documentation** (clear purpose)
- [ ] **Variable naming** (descriptive and consistent)
- [ ] **Code efficiency** (no unnecessary operations)

### Critical Areas to Focus On:
1. **Memory Management**: Ensure all malloc calls have corresponding free
2. **Error Handling**: Invalid input, failed allocations, etc.
3. **Edge Cases**: Empty stacks, single elements, already sorted
4. **Bonus Integration**: Checker doesn't break main program
5. **Build System**: All targets work correctly

### Testing Checklist:
- [ ] `make` builds push_swap successfully
- [ ] `make bonus` builds checker successfully  
- [ ] `make test` runs all unit tests
- [ ] `make fclean && make` clean rebuild works
- [ ] Programs handle invalid input gracefully
- [ ] Bonus checker validates operations correctly

---

## 🎯 **Submission Readiness**

### Final Checks:
- [ ] All source files pass norminette
- [ ] No compilation warnings or errors
- [ ] All tests pass
- [ ] Bonus functionality works correctly
- [ ] Memory leaks eliminated (test with valgrind)
- [ ] Code is well-documented and readable

**Total Files Reviewed: _____ / 47**

---

*Note: Focus on HIGH PRIORITY files first as they contain the core logic and interfaces. MEDIUM PRIORITY contains implementation details. LOW PRIORITY files are supporting tools and tests.*