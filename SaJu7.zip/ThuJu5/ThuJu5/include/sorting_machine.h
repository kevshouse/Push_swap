/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_machine.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:15:44 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORTING_MACHINE_H
# define SORTING_MACHINE_H

# include "machine.h"

/* Main sorting function */
void	sorting_control(t_machine *m);

/* Rotation functions */
int		calculate_rotation_cost(t_machine *m, int index);
void	rotate_to_top_b(t_machine *m, int index);
void	rotate_min_to_top(t_machine *m, size_t min_index, size_t current_size);
int		find_min_index(t_stack *stack);

/* Chunk processing functions */
void	push_chunks_to_b(t_machine *m, t_push_chunks_params p);
void	process_top_element(t_machine *m, t_chunk_info info);
int		*create_sorted_arr(t_stack *stack);
void	handle_element_in_range(t_machine *m, int top_val, t_chunk_info info);

/* Utility functions */
int		find_max_index_in_b(t_machine *m);
void	push_b_to_a(t_machine *m);
void	rotate_min_to_top_a(t_machine *m);

#endif