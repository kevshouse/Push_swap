/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_chunk.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:05:27 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <stdlib.h>

static void	sort_array(int *arr, int size)
{
	int	i;
	int	j;
	int	temp;

	i = 0;
	while (i < size - 1)
	{
		j = i + 1;
		while (j < size)
		{
			if (arr[i] > arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
			j++;
		}
		i++;
	}
}

int	*create_sorted_arr(t_stack *stack)
{
	int		*arr;
	t_node	*current;
	int		i;

	if (!stack || stack->size == 0)
		return (NULL);
	arr = malloc(sizeof(int) * stack->size);
	if (!arr)
		return (NULL);
	current = stack->top;
	i = 0;
	while (current && i < (int)stack->size)
	{
		arr[i] = current->value;
		current = current->next;
		i++;
	}
	sort_array(arr, (int)stack->size);
	return (arr);
}

void	process_top_element(t_machine *m, t_chunk_info info)
{
	int	top_val;

	if (!m || !m->a || !m->a->top || !info.sorted_arr || !info.count)
		return ;
	top_val = machine_top_value(m, STACK_A);
	if (top_val >= info.sorted_arr[info.start]
		&& top_val <= info.sorted_arr[info.end])
		handle_element_in_range(m, top_val, info);
	else
		execution_dispatcher(m, OP_RA);
}

static void	process_chunk_elements(t_machine *m,
		t_push_chunks_params p, int start, int end)
{
	t_chunk_info	info;
	int				count_in_chunk;
	int				target_count;

	count_in_chunk = 0;
	target_count = end - start + 1;
	info.sorted_arr = p.sorted_arr;
	info.start = start;
	info.end = end;
	info.count = &count_in_chunk;
	while (count_in_chunk < target_count
		&& machine_stack_size(m, STACK_A) > 0)
	{
		process_top_element(m, info);
	}
}

void	push_chunks_to_b(t_machine *m, t_push_chunks_params p)
{
	int		chunk_start;
	int		chunk_end;

	chunk_start = 0;
	while (chunk_start < (int)p.size)
	{
		chunk_end = chunk_start + p.chunk_size;
		if (chunk_end >= (int)p.size)
			chunk_end = p.size - 1;
		process_chunk_elements(m, p, chunk_start, chunk_end);
		chunk_start = chunk_end + 1;
	}
}
