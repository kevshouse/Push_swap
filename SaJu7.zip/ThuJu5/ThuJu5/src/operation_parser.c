/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operation_parser.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/14 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:17:06 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../libft/includes/libft.h"
#include <string.h>

static int	ft_strcmp_local(const char *s1, const char *s2)
{
	if (!s1 || !s2)
		return (-1);
	while (*s1 && *s2 && *s1 == *s2)
	{
		s1++;
		s2++;
	}
	return ((unsigned char)*s1 - (unsigned char)*s2);
}

static t_operation	parse_operation(const char *op_str)
{
	if (!op_str)
		return (OP_INVALID);
	if (ft_strcmp_local(op_str, "sa") == 0)
		return (OP_SA);
	if (ft_strcmp_local(op_str, "sb") == 0)
		return (OP_SB);
	if (ft_strcmp_local(op_str, "ss") == 0)
		return (OP_SS);
	if (ft_strcmp_local(op_str, "pa") == 0)
		return (OP_PA);
	if (ft_strcmp_local(op_str, "pb") == 0)
		return (OP_PB);
	if (ft_strcmp_local(op_str, "ra") == 0)
		return (OP_RA);
	if (ft_strcmp_local(op_str, "rb") == 0)
		return (OP_RB);
	if (ft_strcmp_local(op_str, "rr") == 0)
		return (OP_RR);
	if (ft_strcmp_local(op_str, "rra") == 0)
		return (OP_RRA);
	if (ft_strcmp_local(op_str, "rrb") == 0)
		return (OP_RRB);
	if (ft_strcmp_local(op_str, "rrr") == 0)
		return (OP_RRR);
	return (OP_INVALID);
}

static t_operation	parse_push_operations(const char *op_str)
{
	if (ft_strcmp(op_str, "pa") == 0)
		return (OP_PA);
	if (ft_strcmp(op_str, "pb") == 0)
		return (OP_PB);
	return (OP_INVALID);
}

static t_operation	parse_rotate_operations(const char *op_str)
{
	if (ft_strcmp(op_str, "ra") == 0)
		return (OP_RA);
	if (ft_strcmp(op_str, "rb") == 0)
		return (OP_RB);
	if (ft_strcmp(op_str, "rr") == 0)
		return (OP_RR);
	if (ft_strcmp(op_str, "rra") == 0)
		return (OP_RRA);
	if (ft_strcmp(op_str, "rrb") == 0)
		return (OP_RRB);
	if (ft_strcmp(op_str, "rrr") == 0)
		return (OP_RRR);
	return (OP_INVALID);
}

t_operation	parse_operation(const char *op_str)
{
	t_operation	result;

	if (!op_str)
		return (OP_INVALID);
	if (ft_strcmp(op_str, "sa") == 0)
		return (OP_SA);
	if (ft_strcmp(op_str, "sb") == 0)
		return (OP_SB);
	if (ft_strcmp(op_str, "ss") == 0)
		return (OP_SS);
	result = parse_push_operations(op_str);
	if (result != OP_INVALID)
		return (result);
	return (parse_rotate_operations(op_str));
}
