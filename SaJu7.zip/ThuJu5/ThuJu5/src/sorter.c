/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:05:52 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 22:38:49 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <limits.h>
#include <stddef.h>
#include <stdlib.h>

static void	sort_two(t_machine *m)
{
	t_node	*top;
	t_node	*second;

	if (!m || !m->a || m->a->size < 2)
		return ;
	top = m->a->top;
	second = top->next;
	if (top->value > second->value)
		execution_dispatcher(m, OP_SA);
}

static void	sort_three_case(t_machine *m, int a, int b, int c)
{
	if (a > b && b < c && a < c)
		execution_dispatcher(m, OP_SA);
	else if (a > b && b > c)
	{
		execution_dispatcher(m, OP_SA);
		execution_dispatcher(m, OP_RRA);
	}
	else if (a > b && b < c && a > c)
		execution_dispatcher(m, OP_RA);
	else if (a < b && b > c && a < c)
	{
		execution_dispatcher(m, OP_SA);
		execution_dispatcher(m, OP_RA);
	}
	else if (a < b && b > c && a > c)
		execution_dispatcher(m, OP_RRA);
}

static void	sort_three(t_machine *m)
{
	int	a;
	int	b;
	int	c;

	if (!m || !m->a || m->a->size < 3)
		return ;
	a = m->a->top->value;
	b = m->a->top->next->value;
	c = m->a->top->next->next->value;
	sort_three_case(m, a, b, c);
}

static void	chunk_sort(t_machine *m)
{
	t_push_chunks_params	params;
	int						*sorted_arr;
	size_t					size;

	sorted_arr = create_sorted_arr(m->a);
	size = m->a->size;
	if (!sorted_arr)
		return ;
	params.sorted_arr = sorted_arr;
	params.size = size;
	if (size <= 100)
		params.chunk_size = size / 5;
	else if (size <= 500)
		params.chunk_size = size / 8;
	else
		params.chunk_size = size / 20;
	push_chunks_to_b(m, params);
	free(sorted_arr);
	push_b_to_a(m);
	rotate_min_to_top_a(m);
}

void	sorting_control(t_machine *m)
{
	size_t	size;

	if (!m || !m->a)
		return ;
	if (machine_is_sorted(m, STACK_A))
		return ;
	size = m->a->size;
	if (size == 2)
		sort_two(m);
	else if (size == 3)
		sort_three(m);
	else
		chunk_sort(m);
}
