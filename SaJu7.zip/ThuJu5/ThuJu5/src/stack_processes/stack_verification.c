/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_varification.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 22:56:48 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"

t_bool	machine_verify_stack_links(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s;
	t_node			*current;
	size_t			count;

	if (stack_id == STACK_A)
		s = m->a;
	else
		s = m->b;
	if (!s || s->size == 0)
		return (FT_TRUE);
	current = s->top;
	count = 1;
	while (current->next)
	{
		if (current->next->prev != current)
			return (FT_FALSE);
		current = current->next;
		count++;
	}
	if (current != s->bottom || count != s->size)
		return (FT_FALSE);
	return (FT_TRUE);
}

void	machine_print_stack(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s;
	t_node			*current;

	if (stack_id == STACK_A)
		s = m->a;
	else
		s = m->b;
	if (!s)
	{
		ft_printf("(null)\n");
		return ;
	}
	ft_printf("[");
	current = s->top;
	while (current)
	{
		ft_printf("%d", current->value);
		if (current->next)
			ft_printf(", ");
		current = current->next;
	}
	ft_printf("]\n");
}
