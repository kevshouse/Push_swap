/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine_free.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 17:20:27 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:37:27 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include <unistd.h>
#include <stdlib.h>

static void	free_stack(t_stack *s)
{
	t_node	*current;
	t_node	*next;

	if (!s)
		return ;
	current = s->top;
	while (current)
	{
		next = current->next;
		free(current);
		current = next;
	}
	free(s);
}

static void	cleanup_logging(t_machine *m)
{
	if (m->log_fd > STDERR_FILENO)
		close(m->log_fd);
	m->log_fd = -1;
}

void	machine_free(t_machine *m)
{
	if (!m)
		return ;
	log_message(m, LOG_DEBUG, "Freeing machine resources");
	cleanup_logging(m);
	if (m->a)
		free_stack(m->a);
	if (m->b)
		free_stack(m->b);
	free(m);
}
