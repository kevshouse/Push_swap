/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine_init_utils.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 19:03:58 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include "../../include/ft_bool.h"
#include <unistd.h>

t_bool	validate_arguments(int count, char **values)
{
	if (count < 0 || (count > 0 && !values))
		return (FT_FALSE);
	return (FT_TRUE);
}

t_bool	validate_numbers(int *numbers, int count)
{
	if (has_duplicates(numbers, count))
		return (FT_FALSE);
	return (FT_TRUE);
}

t_machine	*create_machine(void)
{
	t_machine	*m;

	m = ft_calloc(1, sizeof(t_machine));
	if (!m)
		return (NULL);
	m->log_level = LOG_WARNING;
	m->log_fd = STDERR_FILENO;
	m->op_count = 0;
	return (m);
}

t_bool	create_stacks(t_machine *m)
{
	m->a = stack_create();
	m->b = stack_create();
	if (!m->a || !m->b)
		return (FT_FALSE);
	return (FT_TRUE);
}

void	populate_stack_a(t_machine *m, int *numbers, int count)
{
	int	i;

	i = 0;
	while (i < count)
	{
		stack_add_back(m->a, numbers[i]);
		i++;
	}
}
