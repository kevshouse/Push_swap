/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_p.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 19:57:57 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 19:59:31 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"

void	do_pa(t_machine *m)
{
	t_node	*node;

	if (m->b->size == 0)
		return ;
	node = m->b->top;
	m->b->top = m->b->top->next;
	if (m->b->top)
		m->b->top->prev = NULL;
	else
		m->b->bottom = NULL;
	m->b->size--;
	node->next = m->a->top;
	if (m->a->top)
		m->a->top->prev = node;
	else
		m->a->bottom = node;
	m->a->top = node;
	m->a->size++;
	ft_putstr_fd("pa\n", STDOUT_FILENO);
	m->op_count++;
}

void	do_pb(t_machine *m)
{
	t_node	*node;

	if (m->a->size == 0)
		return ;
	node = m->a->top;
	m->a->top = m->a->top->next;
	if (m->a->top)
		m->a->top->prev = NULL;
	else
		m->a->bottom = NULL;
	m->a->size--;
	node->next = m->b->top;
	if (m->b->top)
		m->b->top->prev = node;
	else
		m->b->bottom = node;
	m->b->top = node;
	m->b->size++;
	ft_putstr_fd("pb\n", STDOUT_FILENO);
	m->op_count++;
}
