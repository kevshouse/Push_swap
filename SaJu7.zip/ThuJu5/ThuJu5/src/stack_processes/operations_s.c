/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_s.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 20:01:16 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 20:02:32 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"

void	do_sa(t_machine *m)
{
	int		temp;

	if (m->a->size < 2)
		return ;
	temp = m->a->top->value;
	m->a->top->value = m->a->top->next->value;
	m->a->top->next->value = temp;
	ft_putstr_fd("sa\n", STDOUT_FILENO);
	m->op_count++;
}

void	do_sb(t_machine *m)
{
	int		temp;

	if (m->b->size < 2)
		return ;
	temp = m->b->top->value;
	m->b->top->value = m->b->top->next->value;
	m->b->top->next->value = temp;
	ft_putstr_fd("sb\n", STDOUT_FILENO);
	m->op_count++;
}

void	do_ss(t_machine *m)
{
	int		temp_a;
	int		temp_b;
	int		done;

	done = 0;
	if (m->a->size >= 2)
	{
		temp_a = m->a->top->value;
		m->a->top->value = m->a->top->next->value;
		m->a->top->next->value = temp_a;
		done = 1;
	}
	if (m->b->size >= 2)
	{
		temp_b = m->b->top->value;
		m->b->top->value = m->b->top->next->value;
		m->b->top->next->value = temp_b;
		done = 1;
	}
	if (done)
	{
		ft_putstr_fd("ss\n", STDOUT_FILENO);
		m->op_count++;
	}
}
