/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 19:38:45 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include "../../include/ft_bool.h"

t_bool	parse_arguments(int count, char **values, int **numbers)
{
	int		i;

	*numbers = malloc(sizeof(int) * count);
	if (!*numbers)
		return (FT_FALSE);
	i = 0;
	while (i < count)
	{
		if (!ft_isvalidnum(values[i]) || !ft_issafe(values[i]))
		{
			free(*numbers);
			return (FT_FALSE);
		}
		(*numbers)[i] = ft_atoi(values[i]);
		i++;
	}
	return (FT_TRUE);
}

t_bool	has_duplicates(const int *arr, int count)
{
	int	i;
	int	j;

	i = 0;
	while (i < count - 1)
	{
		j = i + 1;
		while (j < count)
		{
			if (arr[i] == arr[j])
				return (FT_TRUE);
			j++;
		}
		i++;
	}
	return (FT_FALSE);
}
