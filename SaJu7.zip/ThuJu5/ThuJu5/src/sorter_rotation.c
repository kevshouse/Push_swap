/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_rotation.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 22:06:38 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <limits.h>

int	find_min_index(t_stack *stack)
{
	t_node	*current;
	int		min_val;
	int		min_index;
	int		i;

	if (!stack || !stack->top)
		return (-1);
	current = stack->top;
	min_val = current->value;
	min_index = 0;
	i = 0;
	while (current)
	{
		if (current->value < min_val)
		{
			min_val = current->value;
			min_index = i;
		}
		current = current->next;
		i++;
	}
	return (min_index);
}

int	calculate_rotation_cost(t_machine *m, int index)
{
	int	size_b;
	int	cost;

	if (!m || !m->b)
		return (0);
	size_b = m->b->size;
	if (index < size_b - index)
		cost = index;
	else
		cost = -(size_b - index);
	return (cost);
}

void	rotate_to_top_b(t_machine *m, int index)
{
	int	cost;
	int	i;

	cost = calculate_rotation_cost(m, index);
	i = 0;
	if (cost > 0)
	{
		while (i < cost)
		{
			execution_dispatcher(m, OP_RB);
			i++;
		}
	}
	else
	{
		while (i < -cost)
		{
			execution_dispatcher(m, OP_RRB);
			i++;
		}
	}
}

void	rotate_min_to_top(t_machine *m, size_t min_index, size_t current_size)
{
	size_t	i;

	i = 0;
	if (min_index < current_size - min_index)
	{
		while (i < min_index)
		{
			execution_dispatcher(m, OP_RA);
			i++;
		}
	}
	else
	{
		while (i < current_size - min_index)
		{
			execution_dispatcher(m, OP_RRA);
			i++;
		}
	}
}
