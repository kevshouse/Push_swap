/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_io_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:20:26 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include <unistd.h>

void	ft_putnbr_const(int n)
{
	ft_putnbr_const_fd(n, STDOUT_FILENO);
}

void	print_error_and_exit(t_machine *m, const char *line)
{
	ft_putstr_const_fd("Error\n", STDERR_FILENO);
	if (line)
		free((char *)line);
	if (m)
		machine_free(m);
	exit(1);
}
