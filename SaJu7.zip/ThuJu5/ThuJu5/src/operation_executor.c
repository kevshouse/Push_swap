/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operation_executor.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:13:51 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"

static size_t	ft_strlen_local(const char *s)
{
	size_t	len;

	if (!s)
		return (0);
	len = 0;
	while (s[len])
		len++;
	return (len);
}

int	execute_operation_from_string(t_machine *m, const char *op_str)
{
	t_operation	op;

	if (!m || !op_str)
		return (-1);
	op = parse_operation(op_str);
	if (op == OP_INVALID)
		return (-1);
	execution_dispatcher(m, op);
	return (0);
}
