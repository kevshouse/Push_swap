/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 20:41:47 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"

int	find_max_index_in_b(t_machine *m)
{
	int		max_val;
	int		max_index;
	int		i;
	t_node	*current;

	if (!m || !m->b || !m->b->top)
		return (-1);
	max_val = m->b->top->value;
	max_index = 0;
	i = 0;
	current = m->b->top;
	while (current)
	{
		if (current->value > max_val)
		{
			max_val = current->value;
			max_index = i;
		}
		current = current->next;
		i++;
	}
	return (max_index);
}

void	push_b_to_a(t_machine *m)
{
	int	max_index;

	while (machine_stack_size(m, STACK_B) > 0)
	{
		max_index = find_max_index_in_b(m);
		if (max_index >= 0)
			rotate_to_top_b(m, max_index);
		execution_dispatcher(m, OP_PA);
	}
}

void	rotate_min_to_top_a(t_machine *m)
{
	int		min_index;
	int		size_a;
	int		cost;
	int		k;

	min_index = find_min_index(m->a);
	if (min_index < 0)
		return ;
	size_a = m->a->size;
	k = 0;
	if (min_index < size_a - min_index)
		cost = min_index;
	else
		cost = -(size_a - min_index);
	if (cost > 0)
	{
		while (k++ < cost)
			execution_dispatcher(m, OP_RA);
	}
	else
	{
		while (k++ < -cost)
			execution_dispatcher(m, OP_RRA);
	}
}
