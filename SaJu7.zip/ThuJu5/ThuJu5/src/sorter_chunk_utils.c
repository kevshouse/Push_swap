/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter_chunk_utils.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/01 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 23:04:57 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"

void	handle_element_in_range(t_machine *m, int top_val, t_chunk_info info)
{
	int	median;

	median = info.sorted_arr[info.start + (info.end - info.start) / 2];
	execution_dispatcher(m, OP_PB);
	if (top_val < median)
		execution_dispatcher(m, OP_RB);
	(*(info.count))++;
}
