#!/usr/bin/env python3
import sys

def main():
    args = sys.argv[1:]
    if not args:
        return

    try:
        stack_a = list(map(int, args))
    except:
        print("Error")
        return

    operations = sys.stdin.read().splitlines()

    # Simulate operations
    stack_b = []
    for op in operations:
        if op == "sa":
            if len(stack_a) > 1:
                stack_a[0], stack_a[1] = stack_a[1], stack_a[0]
        # Add other operations similarly
        # ... (implementation omitted for brevity)

    # Check result
    if stack_a == sorted(stack_a) and not stack_b:
        print("OK")
    else:
        print("KO")

if __name__ == "__main__":
    main()
