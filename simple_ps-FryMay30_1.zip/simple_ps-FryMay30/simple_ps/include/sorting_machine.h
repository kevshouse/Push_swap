#ifndef SORTING_MACHINE_H
# define SORTING_MACHINE_H

# include "machine.h"

void	sorting_control(t_machine *m);
//void    sort_three(t_machine *m);

#endif
