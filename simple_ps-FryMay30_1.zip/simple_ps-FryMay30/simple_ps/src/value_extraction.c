// N.B.
// Integrate the code of this file into other file/s!
//


#include "../include/machine.h"

typedef struct s_sort_case
{
  int state[3];
  t_operation ops[2];
  int op_count;
} t_sort_case;

// Precomputed solutions for all permutations
const t_sort_case cases[6] = {
    {{1,2,3}, {}, 0},              // Already sorted
    {{1,3,2}, {OP_SA, OP_RA}, 2},  // e.g., [5,10,7]
    {{2,1,3}, {OP_SA}, 1},         // e.g., [7,5,10]
    {{2,3,1}, {OP_RRA}, 1},        // e.g., [7,10,5]
    {{3,1,2}, {OP_RA}, 1},         // e.g., [10,5,7]
    {{3,2,1}, {OP_SA, OP_RRA}, 2}  // e.g., [10,7,5]
};

int a = machine_top_value(m, STACK_A);
int b = machine_top_value(m, STACK_A, 1); // Second Element
int c = machine_top_value(m, STACK_A, 2); // Third Element

void normalize(int arr[3], int normalized[3]) {

  int sorted[3] = {arr[0], arr[1], arr[2]};
  int i;
  int j;
  int temp;
  // buble sort the copy (3 elements)

  i = 0;
  while (i < 2) {
    while (j < 2 - i) {
      if (sorted[j] > sorted[j + 1]) {
        temp = sorted[j];
        sorted[j] = sorted[j + 1];
        sorted[j + 1] = temp;
      }
      j++;
    }
    i++;
  }
  // Map to relative positions (1 = smallest, 2 middle, and 3 is the largest )
  i = 0;
  while (i < 3) {
    if (arr[i] == sorted[0])
      normalized[i] = 1;
    else if (arr[i] == sorted[1])
      normalized[i] = 2;
    else
      normalized[i] = 3;
    i++;
  }
}
// where does the following argument and loop fit in?
int     normalized[3];
int     i;
int     j;

i = 0;
j = 0;
normalize((int[3]){a, b, c}, normalized);
while (i < 6)
{
    if (ft_memcmp(normalized, cases[i].state, sizeof(normaized)))
        continue;
    while(j < cases[i].op_count)
    {
        machine_execute(m, cases[i].ops[j]);
        j++;
    }
    i++;
}
