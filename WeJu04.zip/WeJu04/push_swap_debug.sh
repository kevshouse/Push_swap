#!/bin/bash

# Push_Swap Debug Script
# Tests with increasing input sizes

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Test sequences
TEST_CASES=(
    "1"
    "2 1"
    "3 1 2"
    "4 3 2 1"
    "5 4 3 2 1"
    "6 2 8 4 10"
    "9 7 5 3 1"
)

# Header
echo -e "${YELLOW}Starting Push_Swap Debug Tests...${NC}"
echo "========================================"

# Run tests
for test in "${TEST_CASES[@]}"; do
    echo -e "${YELLOW}Testing input: $test${NC}"

    # Run push_swap and capture operations
    ops=$(./push_swap $test 2>&1)
    exit_status=$?
    count=$(echo "$ops" | wc -l | awk '{print $1}')

    # Run checker
    result=$(echo "$ops" | ./checker_linux $test 2>&1)

    # Print results
    if [ "$result" = "OK" ]; then
        echo -e "Result: ${GREEN}OK${NC} ($count ops)"
    else
        echo -e "Result: ${RED}KO${NC}"
        echo "Operations:"
        echo "$ops"
    fi

    # Print exit status
    if [ $exit_status -ne 0 ]; then
        echo -e "${RED}Exit status: $exit_status${NC}"
    fi

    echo "----------------------------------------"
done

# Memory check for largest test
echo -e "${YELLOW}Memory Check for 5 elements:${NC}"
valgrind --leak-check=full ./push_swap 5 4 3 2 1 > /dev/null

echo -e "${YELLOW}Debugging complete${NC}"
