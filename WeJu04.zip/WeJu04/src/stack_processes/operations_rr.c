#include "../../include/machine.h"

static void reverse_rotate_stack(t_stack *s)
{
	t_node *node;

	if(s->size < 2)
		return;
	node            = s->bottom;
	s->bottom       = s->bottom->prev;
	s->bottom->next = NULL;
	node->prev      = NULL;
	node->next      = s->top;
	s->top->prev    = node;
	s->top          = node;
}

void do_rra(t_machine *m)
{
	if(m->a->size < 2)
		return;
	reverse_rotate_stack(m->a);
	ft_putstr_fd("rra\n", STDOUT_FILENO);
	m->op_count++;
}

void do_rrb(t_machine *m)
{
	if(m->b->size < 2)
		return;
	reverse_rotate_stack(m->b);
	ft_putstr_fd("rrb\n", STDOUT_FILENO);
	m->op_count++;
}

void do_rrr(t_machine *m)
{
	int rra_done;
	int rrb_done;

	rra_done = 0;
	rrb_done = 0;
	if(m->a->size >= 2)
	{
		reverse_rotate_stack(m->a);
		rra_done = 1;
	}
	if(m->b->size >= 2)
	{
		reverse_rotate_stack(m->b);
		rrb_done = 1;
	}
	if(rra_done || rrb_done)
	{
		if(rra_done && rrb_done)
			ft_putstr_fd("rrr\n", STDOUT_FILENO);
		else if(rra_done)
			ft_putstr_fd("rra\n", STDOUT_FILENO);
		else
			ft_putstr_fd("rrb\n", STDOUT_FILENO);
		m->op_count++;
	}
}
