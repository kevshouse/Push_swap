#include "../../include/machine.h"
#include "../../libft/includes/libft.h" // For ft_putstr_fd, ft_printf

/* Operation name strings */
static const char *g_op_names[] = {
    [OP_SA] = "sa",   [OP_SB] = "sb",   [OP_SS] = "ss",
    [OP_PA] = "pa",   [OP_PB] = "pb",   [OP_RA] = "ra",
    [OP_RB] = "rb",   [OP_RR] = "rr",   [OP_RRA] = "rra",
    [OP_RRB] = "rrb", [OP_RRR] = "rrr", [OP_INVALID] = "unknown"};

/* Validation helpers */
static t_bool is_valid_operation(t_operation op)
{
	return (op >= OP_SA && op <= OP_RRR);
}

static t_bool is_stack_ready(t_stack *s, t_operation op)
{
	if(!s)
		return (FT_FALSE);

	if(op == OP_SA || op == OP_RA || op == OP_RRA)
		return (s->size >= 2);
	if(op == OP_SB || op == OP_RB || op == OP_RRB)
		return (s->size >= 2);
	if(op == OP_PA)
		return (s->size > 0);
	if(op == OP_PB)
		return (s->size > 0);
	if(op == OP_SS || op == OP_RR || op == OP_RRR)
		return (FT_TRUE);
	return (FT_FALSE);
}

/* Operation dispatcher */
void execution_dispatcher(t_machine *m, t_operation op)
{
	void (*operations[])(t_machine *) = {
	    [OP_SA] = do_sa,   [OP_SB] = do_sb,   [OP_SS] = do_ss,  [OP_PA] = do_pa,
	    [OP_PB] = do_pb,   [OP_RA] = do_ra,   [OP_RB] = do_rb,  [OP_RR] = do_rr,
	    [OP_RRA] = do_rra, [OP_RRB] = do_rrb, [OP_RRR] = do_rrr};

	/* Null check */
	if(!m)
	{
		ft_putstr_fd(STDERR_FILENO, "Error: Null machine pointer\n");
		return;
	}

	/* Operation validation */
	if(!is_valid_operation(op))
	{
		log_message(m, LOG_ERROR, "Invalid operation code");
		return;
	}

	/* Stack readiness check */
	t_bool      ready   = FT_TRUE;
	const char *op_name = g_op_names[op];

	if(op == OP_SA || op == OP_RA || op == OP_RRA || op == OP_PB)
		ready = is_stack_ready(m->a, op);
	else if(op == OP_SB || op == OP_RB || op == OP_RRB || op == OP_PA)
		ready = is_stack_ready(m->b, op);
	else if(op == OP_SS || op == OP_RR || op == OP_RRR)
		ready = is_stack_ready(m->a, op) || is_stack_ready(m->b, op);

	if(!ready)
	{
		log_message(m, LOG_WARNING, "Stack not ready for operation");
		return;
	}

	/* Execute operation */
	operations[op](m);

	/* Log successful execution */
	if(m->log_level >= LOG_INFO)
		ft_putendl_fd(op_name, m->log_fd);

	/* Debug logging */
	if(m->log_level >= LOG_DEBUG)
	{
		ft_printf(m->log_fd, "DEBUG: Executed %s - ", op_name);
		ft_printf(m->log_fd, "Stack A: %zu, Stack B: %zu\n", m->a->size,
		          m->b->size);
	}
}
