#ifndef MACHINE_H
# define MACHINE_H

# include <stddef.h>
# include "ft_bool.h"

/* Stack structures */
typedef struct s_node {
	int				value;
	struct s_node	*prev;
	struct s_node	*next;
}	t_node;

typedef struct s_stack {
	size_t	size;
	t_node	*top;
	t_node	*bottom;
}	t_stack;

/* Log levels */
typedef enum e_log_level {
	LOG_NONE,     // No logging
	LOG_ERROR,    // Errors only
	LOG_WARNING,  // Errors + warnings
	LOG_INFO,     // Basic operation info
	LOG_DEBUG     // Detailed debugging
}	t_log_level;

typedef enum e_operation {
    OP_SA,
    OP_SB,
    OP_SS,
    OP_PA,
    OP_PB,
    OP_RA,
    OP_RB,
    OP_RR,
    OP_RRA,
    OP_RRB,
    OP_RRR
} t_operation;

typedef enum e_stack_id {
    STACK_A,
    STACK_B
} t_stack_id;

/* Machine structure */
typedef struct s_machine {
	t_stack		*a;
	t_stack		*b;
	size_t		op_count;
	t_log_level	log_level;
	int			log_fd;       // Log destination (file descriptor)
}	t_machine;


void machine_execute(t_machine *m, t_operation op);
size_t machine_stack_size(const t_machine *m, t_stack_id stack_id);
int machine_top_value(const t_machine *m, t_stack_id stack_id);
t_bool machine_is_sorted(const t_machine *m, t_stack_id stack_id);
t_bool has_duplicates(int *arr, int count);
size_t machine_op_count(const t_machine *m);

/* Stack API */
t_stack		*stack_create(void);
void		stack_add_back(t_stack *s, int value);

/* Machine API */
t_machine	*machine_init(int count, char **values);
void		machine_free(t_machine *m);

/* Logging API */
void		init_logging(t_machine *m, t_log_level level, const char *filename);
void		log_message(t_machine *m, t_log_level level, const char *msg);

/* Validation API */
int 		ft_isvalidnum(const char *str);
t_bool		ft_issafe(const char *str);

#endif
