#include <unistd.h>

void allman()
{
    int fd;
    char buf;
    int num_chars;

    fd = 1;
    buf = 'a';
    num_chars = 1;

    write(fd, &buf, num_chars);
}
