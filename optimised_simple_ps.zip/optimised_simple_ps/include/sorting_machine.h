#ifndef SORTING_MACHINE_H
# define SORTING_MACHINE_H

# include "machine.h"
# include "../libft/includes/libft.h"

void	sorting_control(t_machine *m);
//void    sort_three(t_machine *m);

#endif
