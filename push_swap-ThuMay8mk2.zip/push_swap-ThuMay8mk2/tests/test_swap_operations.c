#include <criterion/criterion.h>
#include "../inc/push_swap.h"

// Rotate Operations Test Suite
TestSuite(rotate_suite);

/*// Test Case: test_ra_empty_stack
Test(rotate_suite, test_ra_empty_stack) {
    t_stack *a = create_stack(); // Create an empty stack
    ra(a); // Attempt to rotate
    cr_assert_eq(a->size, 0); // Stack A should remain empty
    free_stack(a);
}

// Test Case: test_ra_single_element
Test(rotate_suite, test_ra_single_element) {
    t_stack *a = create_stack();
    push(a, 1); // Push a single element onto the stack
    ra(a); // Attempt to rotate
    cr_assert_eq(a->top->data, 1); // Stack A should still have the same element
    cr_assert_eq(a->size, 1); // Stack A size should remain 1
    free_stack(a);
}

// Test Case: test_rb_empty_stack
Test(rotate_suite, test_rb_empty_stack) {
    t_stack *b = create_stack(); // Create an empty stack
    rb(b); // Attempt to rotate
    cr_assert_eq(b->size, 0); // Stack B should remain empty
    free_stack(b);
}

// Test Case: test_rb_single_element
Test(rotate_suite, test_rb_single_element) {
    t_stack *b = create_stack();
    push(b, 1); // Push a single element onto the stack
    rb(b); // Attempt to rotate
    cr_assert_eq(b->top->data, 1); // Stack B should still have the same element
    cr_assert_eq(b->size, 1); // Stack B size should remain 1
}

// Test Case: test_rb_normal_operation
Test(rotate_suite, test_rb_normal_operation) {
    t_stack *b = create_stack();
    push(b, 4);
    push(b, 5);
    push(b, 6); // Stack B: 4 (top), 5, 6 (bottom)

    rb(b); // Rotate B
    cr_assert_eq(b->top->data, 5); // After rotation, top should be 5
    cr_assert_eq(b->top->next->data, 6); // Next should be 6
    cr_assert_eq(b->size, 3); // Size should remain 3
}*/

// Function to test rotation for a single element stack
void test_single_element_rotation(t_stack *stack, void (*rotate_func)(t_stack *), int expected_value) {
    push(stack, expected_value); // Push a single element onto the stack
    rotate_func(stack); // Attempt to rotate
    cr_assert_eq(stack->top->data, expected_value, "Stack should still have the same element after rotation.");
    cr_assert_eq(stack->size, 1, "Stack size should remain 1 after rotation.");
}

// Function to test empty stack rotation
void test_empty_stack_rotation(t_stack *stack, void (*rotate_func)(t_stack *)) {
    rotate_func(stack); // Attempt to rotate
    cr_assert_eq(stack->size, 0, "Stack should remain empty after rotation.");
}

// Rotate Operations Test Suite
Test(rotate_suite, test_rotate_empty_and_single_element_stacks) {
    // Test for empty stack A
    t_stack *a = create_stack(); // Create an empty stack
    test_empty_stack_rotation(a, ra); // Test rotation for empty stack A
    free_stack(a);

    // Test for single element stack A
    t_stack *b = create_stack(); // Create another new stack
    test_single_element_rotation(b, ra, 1); // Test rotation for single element stack A
    free_stack(b);

    // Test for single element stack B
    t_stack *c = create_stack(); // Create another new stack
    test_single_element_rotation(c, rb, 2); // Test rotation for single element stack B
    free_stack(c);
}

// Additional tests can be added here...
