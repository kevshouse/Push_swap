#include <criterion/criterion.h>
#include "../inc/push_swap.h"

// Rotate Operations Test Suite
//TestSuite(rotate_suite);

// Test Case: test_ra_empty_stack
Test(rotate_suite, test_rotate_ra_empty_stack) { // Renamed to avoid conflict
    t_stack *a = create_stack(); // Create an empty stack
    ra(a); // Attempt to rotate
    cr_assert_eq(a->size, 0); // Stack A should remain empty
    free_stack(a);
}

// Test Case: test_rb_empty_stack
Test(rotate_suite, test_rotate_rb_empty_stack) { // Renamed to avoid conflict
    t_stack *b = create_stack(); // Create an empty stack
    rb(b); // Attempt to rotate
    cr_assert_eq(b->size, 0); // Stack B should remain empty
    free_stack(b);
}

// Test Case: test_rb_single_element
Test(rotate_suite, test_rotate_rb_single_element) { // Renamed to avoid conflict
    t_stack *b = create_stack();
    push(b, 1); // Push a single element onto the stack
    rb(b); // Attempt to rotate
    cr_assert_eq(b->top->data, 1); // Stack B should still have the same element
    cr_assert_eq(b->size, 1); // Stack B size should remain 1
}

Test(rotate_suite, test_rotate_single_element_stacks) {
        // Test for single element in stack A
        t_stack *a = create_stack(); // Create a new stack
        push(a, 1); // Push a single element onto the stack
        ra(a); // Attempt to rotate
        cr_assert_eq(a->top->data, 1, "Stack A should still have the same element after rotation.");
        cr_assert_eq(a->size, 1, "Stack A size should remain 1 after rotation.");
        free_stack(a);

        // Test for single element in stack B
        t_stack *b = create_stack(); // Create another new stack
        push(b, 2); // Push a single element onto the stack
        rb(b); // Attempt to rotate
        cr_assert_eq(b->top->data, 2, "Stack B should still have the same element after rotation.");
        cr_assert_eq(b->size, 1, "Stack B size should remain 1 after rotation.");
        free_stack(b);
}
