#include <criterion/criterion.h>
#include "../inc/push_swap.h"

// Test Case: test_pa_normal_operation
Test(push_pop_suite, test_pa_normal_operation) {
    t_stack *a = create_stack();
    t_stack *b = create_stack();
    push(b, 1);
    push(b, 2);
    pa(a, b);
    printf("a->size = %d\n",a->size);
    printf("b->size = %d\n",b->size);
    //cr_assert_eq(a->top->data, 2);
    //cr_assert_eq(b->top->data, 1);
    cr_assert_eq(a->size, 1);
    cr_assert_eq(b->size, 1);
    free_stack(a);
    free_stack(b);
}

Test(push_pop_suite, test_pa_empty_destination_stack)
{
    t_stack *a = create_stack();
    t_stack *b = create_stack();

    push(b, 1); // Push 1 onto stack B
    pa(a, b);   // Move top of B to A

    cr_assert_eq(b->size, 0, "Stack B should be empty after pa operation");
    cr_assert_eq(a->size, 1, "Stack A should have one element after pa operation");

    if (a->top != NULL) {
        cr_assert_eq(a->top->data, 1, "Top of stack A should be 1 after pa operation");
    }

    free_stack(a);
    free_stack(b);
}

Test(push_pop_suite, test_pb_normal_operation) {
    t_stack *a = create_stack();
    t_stack *b = create_stack();
    push(a, 1);
    push(a, 2);
    pb(a, b);

    if (b->top != NULL) {
        cr_assert_eq(b->top->data, 2, "Element should be moved to stack B");
    }

    if (a->top != NULL) {
        cr_assert_eq(a->top->data, 1, "Stack A should have one element left");
    }

    cr_assert_eq(a->size, 1, "Stack A should have one element");
    cr_assert_eq(b->size, 1, "Stack B should have one element");

    free_stack(a);
    free_stack(b);
}

// Test Case: test_pb_empty_source_stack
Test(push_pop_suite, test_pb_empty_source_stack)
{
    t_stack *a = create_stack();
    t_stack *b = create_stack();
    pb(a, b); // Call the function without expecting a return value
    cr_assert_eq(a->size, 0); // Stack A should remain empty
    cr_assert_eq(b->size, 0); // Stack B should remain empty
    free_stack(a);
    free_stack(b);
}

// Test Case: test_pb_empty_destination_stack
Test(push_pop_suite, test_pb_empty_destination_stack) {
    t_stack *a = create_stack();
    t_stack *b = create_stack();
    push(a, 1);
    pb(a, b);
    //cr_assert_eq(b->top->data, 1); // Element should be moved to stack B
    cr_assert_eq(a->size, 0); // Stack A should be empty
    cr_assert_eq(b->size, 1); // Stack B should have one element
    free_stack(a);
    free_stack(b);
}
