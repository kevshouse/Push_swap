#include <criterion/criterion.h>
# include "../inc/push_swap.h"

Test(atoi_secure, valid_input)
{
    t_atoi_result result = ft_atoi_secure("123");
    cr_assert_eq(result.value, 123);
    cr_assert_eq(result.error, 0);
}

Test(atoi_secure, overflow)
{
    t_atoi_result result = ft_atoi_secure("2147483648");  // INT_MAX + 1
    cr_assert_eq(result.error, 1);
}
Test(atoi_secure, invalid_char)
{
    t_atoi_result result = ft_atoi_secure("12a3");
    cr_assert_eq(result.error, 1);
}
