#The Push_Swap project utilizes a limited set of stack manipulation operations to sort integers efficiently.
##The primary operations include:

1. sa (swap a): Swaps the first two elements of stack A.
1. sb (swap b): Swaps the first two elements of stack B.
1. ss (swap both): Performs sa and sb simultaneously.
pa (push a): Moves the top element from stack B to stack A.
pb (push b): Moves the top element from stack A to stack B.
ra (rotate a): Rotates stack A upwards, moving the top element to the bottom.
rb (rotate b): Rotates stack B upwards.
rr (rotate both): Performs ra and rb simultaneously.
rra (reverse rotate a): Rotates stack A downwards, moving the bottom element to the top.
rrb (reverse rotate b): Rotates stack B downwards.
rrr (reverse rotate both): Performs rra and rrb simultaneously.
These operations are combined to achieve the goal of sorting stack A with the fewest moves possible.
-------------------//---------------------------
sa (swap a): Swaps the first two elements at the top of stack A. If there is only one or no elements, it does nothing.

sb (swap b): Swaps the first two elements at the top of stack B. Similar to sa, it does nothing if there is only one or no elements.

ss (swap both): Executes sa and sb at the same time, allowing for simultaneous swapping of the top elements of both stacks.

pa (push a): Takes the first element from the top of stack B and places it at the top of stack A. If stack B is empty, it does nothing.

pb (push b): Takes the first element from the top of stack A and places it at the top of stack B. It does nothing if stack A is empty.

ra (rotate a): Shifts all elements of stack A up by one position, moving the first element to the last position.

rb (rotate b): Shifts all elements of stack B up by one position, similar to ra.

rr (rotate both): Executes ra and rb simultaneously, rotating both stacks at the same time.

rra (reverse rotate a): Shifts all elements of stack A down by one position, moving the last element to the top.

rrb (reverse rotate b): Shifts all elements of stack B down by one position.

rrr (reverse rotate both): Executes rra and rrb simultaneously, allowing for reverse rotation of both stacks at the same time.
-------------------//---------------------------

Testing list:
1. Push Operation Tests
Test Case: test_push_multiple_elements
Description: Verify that multiple elements can be pushed onto the stack.
Steps: Push several elements, then check the stack's size and element values.
Test Case: test_push_negative_values
Description: Ensure that negative numbers are correctly pushed onto the stack.
Steps: Push negative values and verify their presence in the stack.
Test Case: test_push_reverse_order
Description: Test pushing elements in reverse order and check the stack's order.
Steps: Push elements in descending order and verify the stack's top element.
Test Case: test_push_to_empty_stack
Description: Confirm that pushing to an empty stack works correctly.
Steps: Push an element to an empty stack and check if it becomes the top.
Test Case: test_push_to_freed_stack
Description: Test pushing to a stack that has been freed and reallocated.
Steps: Free the stack, reinitialize it, push an element, and verify its presence.
Test Case: test_push_to_null
Description: Ensure that pushing to a NULL stack pointer handles gracefully.
Steps: Expect an error or crash when attempting to push to a NULL stack.
Test Case: test_push_zero
Description: Verify that pushing zero onto the stack works.
Steps: Push zero and check its presence in the stack.
2. Swap Operations (sa, sb, ss)
Test Case: test_sa_normal_operation
Description: Test swapping the top two elements of stack A.
Steps: Create a stack with multiple elements, perform sa, and check the new top elements.
Test Case: test_sa_single_element
Description: Ensure that sa does nothing with a single element.
Steps: Perform sa on a stack with one element and check for changes.
Test Case: test_sa_empty_stack
Description: Test sa on an empty stack and expect an error.
Steps: Call sa on an empty stack and check for the appropriate error handling.
Test Case: test_sb_normal_operation
Description: Similar to test_sa_normal_operation but for stack B.
Test Case: test_sb_single_element
Description: Similar to test_sa_single_element but for stack B.
Test Case: test_sb_empty_stack
Description: Similar to test_sa_empty_stack but for stack B.
Test Case: test_ss_normal_operation
Description: Test simultaneous swap on both stacks A and B.
Steps: Perform ss on both stacks and verify the top elements.
Test Case: test_ss_single_element_stacks
Description: Test ss when both stacks have one element each.
Steps: Perform ss and check if the top elements are swapped in both stacks.
Test Case: test_ss_empty_stack
Description: Test ss when one or both stacks are empty.
Steps: Expect appropriate error handling when ss is called on empty stacks.
3. Rotate Operations (ra, rb, rr)
Test Case: test_ra_normal_operation
Description: Test rotating stack A by one position.
Steps: Create a stack with multiple elements, perform ra, and check the new order.
Test Case: test_ra_single_element
Description: Ensure that ra does nothing with a single element.
Steps: Perform ra on a stack with one element and check for changes.
Test Case: test_ra_empty_stack
Description: Test ra on an empty stack and expect an error.
Steps: Call ra on an empty stack and check for error handling.
Test Case: test_rb_normal_operation
Description: Similar to test_ra_normal_operation but for stack B.
Test Case: test_rb_single_element
Description: Similar to test_ra_single_element but for stack B.
Test Case: test_rb_empty_stack
Description: Similar to test_ra_empty_stack but for stack B.
Test Case: test_rr_normal_operation
Description: Test simultaneous rotate on both stacks A and B.
Steps: Perform rr on both stacks and verify the new order.
Test Case: test_rr_single_element_stacks
Description: Test rr when both stacks have one element each.
Steps: Perform rr and check if the rotation occurs correctly in both stacks.
Test Case: test_rr_empty_stack
Description: Test rr when one or both stacks are empty.
Steps: Expect appropriate error handling when rr is called on empty stacks.
4. Reverse Rotate Operations (rra, rrb, rrr)
Test Case: test_rra_normal_operation
Description: Test reverse rotating stack A by one position.
Steps: Create a stack with multiple elements, perform rra, and check the new order.
Test Case: test_rra_single_element
Description: Ensure that rra does nothing with a single element.
Steps: Perform rra on a stack with one element and check for changes.
Test Case: test_rra_empty_stack
Description: Test rra on an empty stack and expect an error.
Steps: Call rra on an empty stack and check for error handling.
Test Case: test_rrb_normal_operation
Description: Similar to test_rra_normal_operation but for stack B.
Test Case: test_rrb_single_element
Description: Similar to test_rra_single_element but for stack B.
Test Case: test_rrb_empty_stack
Description: Similar to test_rra_empty_stack but for stack B.
Test Case: test_rrr_normal_operation
Description: Test simultaneous reverse rotate on both stacks A and B.
Steps: Perform rrr on both stacks and verify the new order.
Test Case: test_rrr_single_element_stacks
Description: Test rrr when both stacks have one element each.
Steps: Perform rrr and check if the reverse rotation occurs correctly in both stacks.
Test Case: test_rrr_empty_stack
Description: Test rrr when one or both stacks are empty.
Steps: Expect appropriate error handling when rrr is called on empty stacks.
5. Push and Pop Operations (pa, pb)
Test Case: test_pa_normal_operation
Description: Test moving the top element from stack B to stack A.
Steps: Create elements in stack B, perform pa, and verify the element is moved.
Test Case: test_pa_empty_source_stack
Description: Test pa when stack B is empty.
Steps: Expect an error or no operation when pa is called with an empty stack B.
Test Case: test_pa_empty_destination_stack
Description: Test pa when stack A is empty.
Steps: Move an element from stack B to an empty stack A and verify the result.
Test Case: test_pb_normal_operation
Description: Similar to test_pa_normal_operation but moving from stack A to stack B.
Test Case: test_pb_empty_source_stack
Description: Similar to test_pa_empty_source_stack but for stack A.
Test Case: test_pb_empty_destination_stack
Description: Similar to test_pa_empty_destination_stack but for stack B.
6. Sort Three Elements (sort_three)
Test Case: test_sort_three_already_sorted
Description: Test sorting when the top three elements are already in order.
Steps: Create a stack with elements in ascending order, call sort_three, and verify no changes.
Test Case: test_sort_three_reverse_sorted
Description: Test sorting when the top three elements are in descending order.
Steps: Create a stack with elements in descending order, call sort_three, and verify they are sorted.
Test Case: test_sort_three_partial_sorted
Description: Test sorting when the top three elements are partially sorted.
Steps: Create a stack with elements like 3, 1, 2, call sort_three, and verify they become 1, 2, 3.
Test Case: test_sort_three_with_duplicates
Description: Test sorting when there are duplicate elements in the top three.
Steps: Create a stack with elements like 2, 1, 2, call sort_three, and verify the order.
7. Additional Tests
Test Case: test_stack_underflow
Description: Test operations that may cause stack underflow and ensure they handle errors.
Steps: Perform operations like sa, ra, pa on empty or nearly empty stacks and check for errors.
Test Case: test_large_input_handling
Description: Test operations with large input sizes to ensure performance and correctness.
Steps: Create stacks with many elements and perform operations to verify they work as expected.
Test Case: test_memory_leaks
Description: Ensure that all memory is properly allocated and freed.
Steps: Use tools like Valgrind to check for memory leaks after performing various operations.
Implementing Tests in Criterion
Each test case will be implemented as a separate test function within the Criterion framework. For example:

```c
void test_sa_normal_operation(void) {
    t_stack *a = create_stack();
    push(a, 1);
    push(a, 2);
    push(a, 3);
    sa(a);
    cr_assert_eq(a->top->data, 2);
    cr_assert_eq(a->top->next->data, 1);
    cr_assert_eq(a->top->next->next->data, 3);
    free_stack(a);
}
```
