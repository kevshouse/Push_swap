#include <criterion/criterion.h>
#include <stdlib.h>
#include <stdio.h>
#include "../inc/push_swap.h"

// Helper function to create a new stack
// Moved to src/init/stack.c
//
/*t_stack* create_stack()
{
    t_stack *stack = malloc(sizeof(t_stack));
    stack->top = NULL;
    stack->tail = NULL;
    stack->size = 0;
    return stack;
}

// Helper function to free a stack
void free_stack(t_stack *stack)
{
    t_node *current = stack->top;
    while (current) {
        t_node *next = current->next;
        free(current);
        current = next;
    }
    free(stack);
    }*/

// Test for push function
Test(push_swap, push_test)
{
    t_stack *stack = create_stack();
    push(stack, 42);
    cr_assert_eq(stack->top->data, 42, "Expected top of stack to be 42");
    cr_assert_eq(stack->size, 1, "Expected stack size to be 1");

    push(stack, 84);
    cr_assert_eq(stack->top->data, 84, "Expected top of stack to be 84 after second push");
    cr_assert_eq(stack->size, 2, "Expected stack size to be 2 after second push");

    free_stack(stack);
}

// Test for swap function
Test(push_swap, swap_test)
{
    t_stack *stack = create_stack();
    push(stack, 1);
    push(stack, 2);
    sa(stack); // Swap the top two elements

    cr_assert_eq(stack->top->data, 1, "Expected top of stack to be 1 after swap");
    cr_assert_eq(stack->top->next->data, 2, "Expected second element to be 2 after swap");

    free_stack(stack);
}

// Test for rotate function
Test(push_swap, rotate_test)
{
    t_stack *stack = create_stack(); // Create a new stack
    push(stack, 1); // Push elements onto the stack
    push(stack, 2);
    push(stack, 3);

    ra(stack); // Rotate the stack

    // Debugging output
    printf("After rotation: top = %d, second = %d, tail = %d\n", stack->top->data, stack->top->next->data, stack->tail->data);

    // Assertions to check the expected state of the stack
    cr_assert_eq(stack->top->data, 2, "Expected top of stack to be 2 after rotation");
    cr_assert_eq(stack->top->next->data, 3, "Expected second element to be 3 after rotation");
    cr_assert_eq(stack->tail->data, 1, "Expected tail of stack to be 1 after rotation");

    free_stack(stack); // Free the stack after use
}

// Test for reverse rotate function
Test(push_swap, reverse_rotate_test)
{
    t_stack *stack = create_stack(); // Create a new stack
    push(stack, 1); // Push elements onto the stack
    push(stack, 2);
    push(stack, 3);

    rra(stack); // Reverse rotate the stack

    // Debugging output
    printf("After reverse rotation: top = %d, second = %d, tail = %d\n", stack->top->data, stack->top->next->data, stack->tail->data);

    // Assertions to check the expected state of the stack
    cr_assert_eq(stack->top->data, 3, "Expected top of stack to be 3 after reverse rotation");
    cr_assert_eq(stack->top->next->data, 1, "Expected second element to be 1 after reverse rotation");
    cr_assert_eq(stack->tail->data, 2, "Expected tail of stack to be 2 after reverse rotation");

    free_stack(stack); // Free the stack after use
}
