#include <criterion/criterion.h>

int ft_atoi_secure(const char *str, int *error);

Test(atoi_secure, valid_input)
{
    int     error;
    cr_assert_eq(ft_atoi_secure("123", &error), 123);
    cr_assert_eq(error, 0);
}

Test(atoi_secure, overflow)
{
    int error;
    ft_atoi_secure("2147483648", &error);  // INT_MAX + 1
    cr_assert_eq(error, 1);
}

Test(atoi_secure, invalid_char)
{
    int error;
    ft_atoi_secure("12a3", &error);
    cr_assert_eq(error, 1);
}
