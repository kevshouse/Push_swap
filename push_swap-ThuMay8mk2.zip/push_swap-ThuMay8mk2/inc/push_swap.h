#ifndef PUSH_SWAP_H
#define PUSH_SWAP_H
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

typedef struct s_stack
{
    struct s_node *top;
    struct s_node *tail;
    int size;
    int sorted; // 1 if sorted in ascending order, 0 otherwise
} t_stack;

typedef struct s_node
{
    int     data;
    int     index;
    struct s_node *next;
    struct s_node *prev;
} t_node;

// Stack Initialization and Cleanup
t_stack *create_stack(void);
void free_stack(t_stack *stack);

typedef struct s_rotation_result {
  int rotations;
  int error;
} t_rotation_result;

typedef void (*t_rotate_func)(t_stack *);
#define ROTATION_OK 0
#define ROTATION_EMPTY_STACK -1

// Stack Operations
void free_stack(t_stack *stack);
void push(t_stack *dest, int value);
void ra(t_stack *a);
void rb(t_stack *b);
void rra(t_stack *a);
void rrb(t_stack *b);
void rrr(t_stack *a, t_stack *b);
void pa(t_stack *a, t_stack *b);
void pb(t_stack *a, t_stack *b);
void sa(t_stack *a);
void sb(t_stack *b);

// Sorting Functions

void quick_sort(t_stack *stack_a, t_stack *stack_b);
void ft_qsort(t_stack *stack_a, t_stack *stack_b);
void quick_a(t_stack *stack_a, t_stack *stack_b);
void quick_b(t_stack *stack_b, t_stack *stack_a);
void insertion_sort(t_stack *stack_a, t_stack *stack_b);
void rotate_min_to_top(t_stack *stack, t_rotate_func rotate_func);

// Checker Function

void checker(t_stack *stack_a, t_stack *stack_b);

// Cost Calculation

int compare_int(int a, int b);
t_rotation_result calculate_rotations(t_stack *stack);
t_rotation_result calculate_rotations_a(t_stack *a);
t_rotation_result calculate_rotations_b(t_stack *b);
// t_rotation_result calculate_rotations(t_stack *stack, int (*compare)(int, int));
//t_rotation_result calculate_rotations_a(t_stack *a, int value);
//t_rotation_result calculate_rotations_b(t_stack *b, int value);

// Count Moves

int count_moves(t_stack *stack_a, t_stack *stack_b);

// Sorting Three Elements

void sort_three(t_stack *stack);

// Secure atoi

typedef struct s_atoi_result
{
    int     value;
    int     error;
} t_atoi_result;

t_atoi_result ft_atoi_secure(const  char *str);

#endif
