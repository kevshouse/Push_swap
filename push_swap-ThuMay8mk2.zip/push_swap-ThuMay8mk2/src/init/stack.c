# include "../../inc/push_swap.h"

// Helper function to create a new stack
/**
 * @brief Creates a new empty stack.
 *
 * @return t_stack* A pointer to the newly created stack, or NULL if memory allocation fails.
 */
/*t_stack* create_stack()
{
    t_stack *stack = malloc(sizeof(t_stack));
    if (!stack)
        return (NULL); // Allocation failed!
    stack->top = NULL;
    stack->tail = NULL;
    stack->size = 0;
    return stack;
}*/
t_stack* create_stack() {
    t_stack *stack = malloc(sizeof(t_stack));
    if (!stack) return NULL;
    stack->top = NULL;
    stack->tail = NULL;
    stack->size = 0;
    stack->sorted = 1; // Initially empty stack is considered sorted
    return stack;
}

/**
 * @brief Frees all memory allocated for the stack.
 *
 * @param stack A pointer to the stack to be freed.
 */
// Helper function to free a stack
/*void free_stack(t_stack *stack)
{
    if (stack == NULL)
        return;
    t_node *current = stack->top;
    while (current != NULL)
    {
        t_node *next = current->next;
        free(current);
        current = next;
    }
    free(stack);
    stack = NULL; // Important: Stack point must be NULL after freeing
    }*/
void free_stack(t_stack *stack)
{
    if (stack == NULL)
        return;
    t_node *current = stack->top;
    t_node *next_node;
    while (current != NULL)
    {
        next_node = current->next; // Store the next node
        free(current); // Free the current node
        current = next_node; // Move to the next node
    }
    free(stack); // Finally, free the stack structure itself
}
void print_stack(t_stack *stack)
{
    t_node *current = stack->top;
    printf("Stack: ");
    while (current) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}
