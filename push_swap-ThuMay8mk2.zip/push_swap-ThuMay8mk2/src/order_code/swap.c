// Generic swap for any stack
# include "../../inc/push_swap.h"

static void swap(t_stack *stack)
{
    if (stack->top && stack->top->next)
    {
        t_node *first = stack->top;
        t_node *second = first->next;

        first->next = second->next; // Update first's next to second's next
        first->prev = second; // First's prev should point to second
        second->next = first; // Second's next should point to first
        second->prev = NULL; // Second's prev should be NULL since it's now the top

        if (first->next != NULL)
        {
            first->next->prev = first; // Update the next node's prev to first
        }
        else
        {
            stack->tail = first; // If first was the last node, update the tail
        }

        stack->top = second; // Update the top to be the second node

        // Debug output
        printf("Swapped top two values: %d and %d\n", first->data, second->data);
        printf("New top data: %d\n", stack->top->data);
        if (stack->top->prev != NULL)
        {
            printf("Top's prev data: %d\n", stack->top->prev->data);
        }
        else
        {
            printf("Top's prev is NULL\n");
        }
    }
    else
    {
        printf("Swap operation failed: Not enough elements in the stack.\n");
    }
}

// sa and sb wrappers
void sa(t_stack *a)
{
    if (!a )
        return;
    swap(a);
}

void sb(t_stack *b)
{
    if (!b )
        return;
    swap(b);
}

void ss(t_stack *a, t_stack *b)
{
    if (!a || !b)
        return;
    swap(a);
    swap(b);
}
