// Generic reverse rotate (shift down)
# include "../../inc/push_swap.h"

static void reverse_rotate(t_stack *stack)
{
    if (stack->top && stack->top->next) // Ensure there are at least two elements
    {
        t_node *last = stack->top;
        t_node *second_last = NULL;
        // Traverse to find the last and second last nodes
        while (last->next)
        {
            second_last = last;
            last = last->next;
        }
        if (second_last)
        {
            second_last->next = NULL;
            last->next = stack->top;
            last->prev = NULL;
            stack->top = last;
            stack->tail = second_last;
        }
    }
}

void rra(t_stack *a)
{
    if (!a)
        return;
    reverse_rotate(a);
}

void rrb(t_stack *b)
{
    if (!b)
        return;
    reverse_rotate(b);
}

void rrr(t_stack *a, t_stack *b)
{
    if (!a || !b)
        return;
    reverse_rotate(a);
    reverse_rotate(b);
}
