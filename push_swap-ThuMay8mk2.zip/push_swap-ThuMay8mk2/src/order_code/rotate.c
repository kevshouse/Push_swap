// Generic rotate (shift up)
# include "../../inc/push_swap.h"

/*void print_stack(t_stack *stack)
{
    t_node *current = stack->top;
    printf("Stack: ");
    while (current) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}*/

// Static function to perform the actual rotation
/*static void rotate(t_stack *stack)
{
    if (stack->size < 2)
    {
        printf("No rotation needed for stack with size %d.\n", stack->size);
        return; // No rotation needed for 0 or 1 element
    }

    t_node *old_top = stack->top; // Store the current top
    t_node *new_top = old_top->next; // The new top will be the second element

    // Update pointers
    stack->top = new_top; // New top is the second element
    //old_top->next = NULL; // Old top will become the last element
    old_top->prev = stack->tail; // Link to the current tail

    if (stack->tail)
    {
        stack->tail->next = old_top; // Current tail points to old top
    }
    stack->tail = old_top; // Update tail to old top
    new_top->prev = NULL; // New top has no previous element
}*/
static void rotate(t_stack *stack)
{
    if (stack->size < 2)
    {
        printf("No rotation needed for stack with size %d.\n", stack->size);
        return; // No rotation needed for 0 or 1 element
    }

    t_node *old_top = stack->top; // Store the current top
    t_node *new_top = old_top->next; // The new top will be the second element

    // Debugging output
    //printf("Before rotation:\n");
    //print_stack(stack);
    //printf("Old top: %d, New top: %d\n", old_top->data, new_top->data);

    // Update pointers
    stack->top = new_top; // New top is the second element

    // Link the old top to the current tail
    if (stack->tail)
    {
        stack->tail->next = old_top; // Current tail points to old top
        old_top->prev = stack->tail; // Old top's previous points to the current tail
    }
    else
    {
        // If the stack was empty, old_top is now the only element
        old_top->prev = NULL; // Old top has no previous element
    }

    stack->tail = old_top; // Update tail to old top
    old_top->next = NULL; // Old top becomes the last element
    new_top->prev = NULL; // New top has no previous element

    // Debugging output
    //printf("After rotation:\n");
    //print_stack(stack);
    //printf("New top: %d, New tail: %d\n", stack->top->data, stack->tail->data);
}

// Wrappers
void ra(t_stack *a)
{
    if (a == NULL || a->size < 2)
        return; // No rotation needed for NULL or 0/1 element
    rotate(a);
}

void rb(t_stack *b)
{
    if (b == NULL || b->size < 2)
        return; // No rotation needed for NULL or 0/1 element
    rotate(b);

}

void rr(t_stack *a, t_stack *b)
{
    if (!a || !b)
        return;
    rotate(a);
    rotate(b);
}
