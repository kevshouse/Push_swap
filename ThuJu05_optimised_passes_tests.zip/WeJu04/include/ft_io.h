#ifndef FT_IO_H
# define FT_IO_H

# include <unistd.h>
# include "../libft/includes/libft.h"

void	ft_putstr_const_fd(const char *s, int fd);
void	ft_putendl_const_fd(const char *s, int fd);
void	ft_putstr_const(const char *s);
void	ft_putendl_const(const char *s);
void	ft_putnbr_const_fd(int n, int fd);
void	ft_putnbr_const(int n);

#endif