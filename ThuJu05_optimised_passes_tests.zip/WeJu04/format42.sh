#!/bin/bash

# format42.sh - Custom formatter for 42 School style
# Applies clang-format and then adds tabs between return type and function name
# according to 42 School style (Norm)

# Check if we have files to process
if [ $# -eq 0 ]; then
    echo "Usage: $0 <file1> [file2] [file3] ..."
    echo "Formats C files according to 42 School style"
    exit 1
fi

# Process each file
for file in "$@"; do
    if [ ! -f "$file" ]; then
        echo "Error: File '$file' not found"
        continue
    fi
    
    # Apply clang-format first
    clang-format -i "$file"
    
    # Create a temporary file for our edits
    temp_file=$(mktemp)
    
    # Apply the 42 School style formatting
    # Two-step process:
    # 1. First convert all spaces in type declarations to single spaces
    # 2. Then convert the space between type and identifier to a tab
    
    # Step 1: Normalize spaces in declarations
    cat "$file" | sed -E '
        # Normalize spaces between type and identifier, preserving pointers with type
        s/^([ \t]*)(static[ \t]+)?(void|int|char|float|double|size_t|long|short|unsigned|signed|t_[a-zA-Z0-9_]+)([ \t]*\*+)?[ \t]+([a-zA-Z_][a-zA-Z0-9_]*)/\1\2\3\4 \5/g
    ' > "$temp_file"
    
    # Step 2: Convert the normalized space to a tab
    sed -i -E '
        # Replace the space between type (with or without pointer) and identifier with a tab
        s/^([ \t]*)(static[ \t]+)?(void|int|char|float|double|size_t|long|short|unsigned|signed|t_[a-zA-Z0-9_]+)([ \t]*\*+)? ([a-zA-Z_][a-zA-Z0-9_]*)/\1\2\3\4\t\5/g
        
        # Handle struct/union/enum/typedef declarations
        s/^([ \t]*)(typedef[ \t]+)?(struct|union|enum)[ \t]+([a-zA-Z_][a-zA-Z0-9_]*)[ \t]+([a-zA-Z_][a-zA-Z0-9_]*)/\1\2\3\t\4\t\5/g
    ' "$temp_file"
    
    # Move the temporary file back to the original
    mv "$temp_file" "$file"
    
    echo "Formatted: $file"
done

echo "Formatting complete"
exit 0