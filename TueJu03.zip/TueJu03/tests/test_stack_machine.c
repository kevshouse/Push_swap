#include "../include/machine.h"
// #include <criterion/criterion.h>
// #include <criterion/criterion.h>
#include </sgoinfre/students/keanders/homebrew/Cellar/criterion/2.4.2_2/include/criterion/criterion.h>

#include <stdio.h>

Test(stack_machine, init_valid)
{
	printf("=== RUNNING stack_machine::init_valid ===\n");
	char      *values[] = {"1", "2", "3"};
	t_machine *m        = machine_init(3, values);

	cr_assert_not_null(m, "Machine initialization failed");
	cr_assert_eq(machine_stack_size(m, STACK_A), 3,
	             "Expected stack size 3, got %zu",
	             machine_stack_size(m, STACK_A));

	machine_free(m);
	printf("=== FINISHED stack_machine::init_valid ===\n");
}

Test(stack_machine, init_invalid)
{
	printf("=== RUNNING stack_machine::init_invalid ===\n");
	char      *values[] = {"1", "a", "3"};
	t_machine *m        = machine_init(3, values);

	cr_assert_null(m, "Machine should be NULL for invalid input");
	printf("=== FINISHED stack_machine::init_invalid ===\n");
}

Test(stack_machine, empty_stack)
{
	printf("=== RUNNING stack_machine::empty_stack ===\n");
	char      *values[] = {};
	t_machine *m        = machine_init(0, values);

	cr_assert_not_null(m, "Machine should be initialized with empty stack");
	cr_assert_eq(machine_stack_size(m, STACK_A), 0,
	             "Stack A should be empty, got %zu",
	             machine_stack_size(m, STACK_A));

	machine_free(m);
	printf("=== FINISHED stack_machine::empty_stack ===\n");
}
