#include <criterion/criterion.h>

Test(minimal, should_pass) {
    cr_assert(1, "This test should pass");
}

Test(minimal, should_fail) {
    cr_assert(0, "This test should fail");
}
