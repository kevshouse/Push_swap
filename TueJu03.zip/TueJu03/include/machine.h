#ifndef MACHINE_H
# define MACHINE_H

# include <stddef.h>
# include "ft_bool.h"

/* Stack structures */
typedef struct s_node {
	int				value;
	struct s_node	*prev;
	struct s_node	*next;
}	t_node;

typedef struct s_stack {
	size_t	size;
	t_node	*top;
	t_node	*bottom;
}	t_stack;

/* Log levels */
typedef enum e_log_level {
	LOG_NONE,     // No logging
	LOG_ERROR,    // Errors only
	LOG_WARNING,  // Errors + warnings
	LOG_INFO,     // Basic operation info
	LOG_DEBUG     // Detailed debugging
}	t_log_level;

/* Machine structure */
typedef struct s_machine {
	t_stack		*a;
	t_stack		*b;
	size_t		op_count;
	t_log_level	log_level;
	int			log_fd;       // Log destination (file descriptor)
}	t_machine;

/* Stack API */
t_stack		*stack_create(void);
void		stack_add_back(t_stack *s, int value);

/* Machine API */
t_machine	*machine_init(int count, char **values);
void		machine_free(t_machine *m);

/* Logging API */
void		init_logging(t_machine *m, t_log_level level, const char *filename);
void		log_message(t_machine *m, t_log_level level, const char *msg);

/* Validation API */
t_bool		ft_isvalidnum(const char *str);
t_bool		ft_issafe(const char *str);

#endif
