#include "../include/machine.h"
#include "../libft/includes/libft.h"
#include <fcntl.h>  // For open()
#include <unistd.h> // For close()

/* Initialize logging */
void init_logging(t_machine *m, t_log_level level, const char *filename)
{
	if(!m)
		return;

	m->log_level = level;

	if(filename)
	{
		m->log_fd = open(filename, O_WRONLY | O_CREAT | O_APPEND, 0644);
		if(m->log_fd < 0)
		{
			m->log_fd = STDERR_FILENO;
			ft_putstr_fd(STDERR_FILENO, "Failed to open log file\n");
		}
	}
	else
	{
		m->log_fd = STDERR_FILENO;
	}
}

/* Log message with level filtering */
void log_message(t_machine *m, t_log_level level, const char *msg)
{
	const char *prefix;

	if(!m || !msg || level < LOG_ERROR || level > LOG_DEBUG)
		return;

	if(level > m->log_level)
		return;

	// Set appropriate prefix
	if(level == LOG_ERROR)
		prefix = "ERROR: ";
	else if(level == LOG_WARNING)
		prefix = "WARNING: ";
	else if(level == LOG_INFO)
		prefix = "INFO: ";
	else
		prefix = "DEBUG: ";

	// Write to log
	ft_putstr_fd(prefix, m->log_fd);
	ft_putendl_fd(msg, m->log_fd);

	// For errors, also print to stderr if not already
	if(level == LOG_ERROR && m->log_fd != STDERR_FILENO)
	{
		ft_putstr_fd(prefix, STDERR_FILENO);
		ft_putendl_fd(msg, STDERR_FILENO);
	}
}
