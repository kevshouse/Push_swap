/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:06:00 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:24:15 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>

/* Static helper functions */
static t_stack *stack_create(void)
{
	t_stack *s;

	s = ft_calloc(1, sizeof(t_stack));
	if(s)
	{
		s->size   = 0;
		s->top    = NULL;
		s->bottom = NULL;
	}
	return (s);
}

static void stack_add_back(t_stack *s, int value)
{
	t_node *new;

	new = ft_calloc(1, sizeof(t_node));
	if(!new)
		return;
	new->value = value;
	new->next  = NULL;
	if(!s->top)
	{
		s->top    = new;
		s->bottom = new;
		new->prev = NULL;
	}
	else
	{
		new->prev       = s->bottom;
		s->bottom->next = new;
		s->bottom       = new;
	}
	s->size++;
}

static void free_stack(t_stack *s)
{
	t_node *current;
	t_node *next;

	if(!s)
		return;
	current = s->top;
	while(current)
	{
		next = current->next;
		free(current);
		current = next;
	}
	free(s);
}

/* Public API implementation */
t_machine *machine_init(int count, char **values)
{
	t_machine *m;
	int       *numbers;
	int        i;
	long       num;

	m = ft_calloc(1, sizeof(t_machine));
	if(!m)
		return (NULL);
	m->a = stack_create();
	m->b = stack_create();
	if(!m->a || !m->b)
	{
		machine_free(m);
		return (NULL);
	}
	numbers = malloc(count * sizeof(int));
	if(!numbers)
	{
		machine_free(m);
		return (NULL);
	}
	i = 0;
	while(i < count)
	{
		if(!ft_isvalidnum(values[i]) || !ft_issafe(values[i]))
		{
			free(numbers);
			machine_free(m);
			return (NULL);
		}
		num        = ft_atol(values[i]);
		numbers[i] = (int)num;
		i++;
	}
	/*for(int i = 0; i < count; i++)
	{
	    if(!ft_isvalidnum(values[i]) || !ft_issafe(values[i]))
	    {
	        free(numbers);
	        machine_free(m);
	        return (NULL);
	    }
	    num        = ft_atol(values[i]);
	    numbers[i] = (int)num;
	}*/
	if(has_duplicates(numbers, count))
	{
		free(numbers);
		machine_free(m);
		return (NULL);
	}
	for(int i = 0; i < count; i++)
		stack_add_back(m->a, numbers[i]);
	free(numbers);
	return (m);
}

void machine_free(t_machine *m)
{
	if(!m)
		return;
	if(m->a)
		free_stack(m->a);
	if(m->b)
		free_stack(m->b);
	free(m);
}
