/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_io.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/05 12:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/06/06 00:02:54 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/ft_io.h"

void	ft_putstr_const_fd(const char *s, int fd)
{
	if (s)
		ft_putstr_fd((char *)s, fd);
}

void	ft_putendl_const_fd(const char *s, int fd)
{
	if (s)
		ft_putendl_fd((char *)s, fd);
}

void	ft_putstr_const(const char *s)
{
	ft_putstr_const_fd(s, STDOUT_FILENO);
}

void	ft_putendl_const(const char *s)
{
	ft_putendl_const_fd(s, STDOUT_FILENO);
}

void	ft_putnbr_const_fd(int n, int fd)
{
	ft_putnbr_fd(n, fd);
}

void	ft_putnbr_const(int n)
{
	ft_putnbr_const_fd(n, STDOUT_FILENO);
}
