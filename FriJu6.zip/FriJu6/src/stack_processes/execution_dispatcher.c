/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execution_dispatcher.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/05 21:49:38 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/05 22:43:37 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/ft_io.h"
#include "../../include/machine.h"
#include "../../libft/includes/libft.h"

static const char	*get_op_name(t_operation op)
{
	if (op == OP_SA)
		return ("sa");
	if (op == OP_SB)
		return ("sb");
	if (op == OP_SS)
		return ("ss");
	if (op == OP_PA)
		return ("pa");
	if (op == OP_PB)
		return ("pb");
	if (op == OP_RA)
		return ("ra");
	if (op == OP_RB)
		return ("rb");
	if (op == OP_RR)
		return ("rr");
	if (op == OP_RRA)
		return ("rra");
	if (op == OP_RRB)
		return ("rrb");
	if (op == OP_RRR)
		return ("rrr");
	return ("unknown");
}

static void	execute_operation(t_machine *m, t_operation op)
{
	if (op == OP_SA)
		do_sa(m);
	else if (op == OP_SB)
		do_sb(m);
	else if (op == OP_SS)
		do_ss(m);
	else if (op == OP_PA)
		do_pa(m);
	else if (op == OP_PB)
		do_pb(m);
	else if (op == OP_RA)
		do_ra(m);
	else if (op == OP_RB)
		do_rb(m);
	else if (op == OP_RR)
		do_rr(m);
	else if (op == OP_RRA)
		do_rra(m);
	else if (op == OP_RRB)
		do_rrb(m);
	else if (op == OP_RRR)
		do_rrr(m);
}

static void	log_execution(t_machine *m, const char *op_name)
{
	if (m->log_level >= LOG_INFO)
		ft_putendl_const_fd(op_name, m->log_fd);
	if (m->log_level >= LOG_DEBUG)
	{
		ft_putstr_const_fd("DEBUG: Executed ", m->log_fd);
		ft_putstr_const_fd(op_name, m->log_fd);
		ft_putstr_const_fd(" - Stack A: ", m->log_fd);
		ft_putnbr_fd(m->a->size, m->log_fd);
		ft_putstr_const_fd(", Stack B: ", m->log_fd);
		ft_putnbr_fd(m->b->size, m->log_fd);
		ft_putstr_const_fd("\n", m->log_fd);
	}
}

static t_bool	is_operation_ready(t_machine *m, t_operation op)
{
	if (op == OP_SA || op == OP_RA || op == OP_RRA || op == OP_PB)
	{
		if (!m->a)
			return (FT_FALSE);
		if (op == OP_SA || op == OP_RA || op == OP_RRA)
			return (m->a->size >= 2);
		return (m->a->size > 0);
	}
	else if (op == OP_SB || op == OP_RB || op == OP_RRB || op == OP_PA)
	{
		if (!m->b)
			return (FT_FALSE);
		if (op == OP_SB || op == OP_RB || op == OP_RRB)
			return (m->b->size >= 2);
		return (m->b->size > 0);
	}
	else if (op == OP_SS || op == OP_RR || op == OP_RRR)
		return (FT_TRUE);
	return (FT_FALSE);
}

void	execution_dispatcher(t_machine *m, t_operation op)
{
	const char	*op_name;

	if (!m)
	{
		ft_putstr_const_fd("Error: Null machine pointer\n", STDERR_FILENO);
		return ;
	}
	if (op < OP_SA || op > OP_RRR)
	{
		log_message(m, LOG_ERROR, "Invalid operation code");
		return ;
	}
	op_name = get_op_name(op);
	if (!is_operation_ready(m, op))
	{
		log_message(m, LOG_WARNING, "Stack not ready for operation");
		return ;
	}
	execute_operation(m, op);
	log_execution(m, op_name);
}
