/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:06:00 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/05 22:47:47 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>

size_t	machine_op_count(const t_machine *m)
{
	if (!m)
		return (0);
	return (m->op_count);
}

void	machine_print_stack(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s;
	t_node			*current;

	if (stack_id == STACK_A)
		s = m->a;
	else
		s = m->b;
	if (!s)
	{
		ft_printf("(null)\n");
		return ;
	}
	ft_printf("[");
	current = s->top;
	while (current)
	{
		ft_printf("%d", current->value);
		if (current->next)
			ft_printf(", ");
		current = current->next;
	}
	ft_printf("]\n");
}
/* This file serves as a central include point for stack machine functionality.
 * The actual implementations are distributed across specialized files:
 * - stack_utils.c: Basic stack operations
 * - machine_init.c: Machine initialization
 * - machine_free.c: Machine cleanup
 * - stack_inspection.c: Stack inspection functions
 * - execution_dispatcher.c: Operation execution
 */