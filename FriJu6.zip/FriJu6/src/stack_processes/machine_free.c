/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine_free.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/05 22:48:31 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/05 22:49:30 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include <stdlib.h> // For free()
#include <unistd.h> // For close()

/* Static helpers */
static void	free_stack(t_stack *s)
{
	t_node	*current;
	t_node	*next;

	if (!s)
		return ;
	current = s->top;
	while (current)
	{
		next = current->next;
		free(current);
		current = next;
	}
	free(s);
}

static void	cleanup_logging(t_machine *m)
{
	if (m->log_fd > STDERR_FILENO)
		close(m->log_fd);
	m->log_fd = -1;
}

/* Public API */
void	machine_free(t_machine *m)
{
	if (!m)
		return ;
	log_message(m, LOG_DEBUG, "Freeing machine resources");
	cleanup_logging(m);
	if (m->a)
		free_stack(m->a);
	if (m->b)
		free_stack(m->b);
	free(m);
}
