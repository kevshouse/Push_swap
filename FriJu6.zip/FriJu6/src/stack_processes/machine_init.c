/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine_init.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 00:32:30 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 01:03:16 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include "../../include/stack_utils.h"
#include "../../include/utils.h"
#include <limits.h>
#include <stdlib.h>
#include <unistd.h>

/* Helper functions */
static t_bool	parse_args(int count, char **values, int **numbers)
{
	long	num;
	int		i;

	*numbers = malloc(count * sizeof(int));
	if (!*numbers)
		return (FT_FALSE);
	i = -1;
	while (++i < count)
	{
		if (!ft_isvalidnum(values[i]) || !ft_issafe(values[i]))
			return (free(*numbers), FT_FALSE);
		num = ft_atol(values[i]);
		if (num > INT_MAX || num < INT_MIN)
			return (free(*numbers), FT_FALSE);
		(*numbers)[i] = (int)num;
	}
	return (FT_TRUE);
}

static void	init_stacks(t_machine *m, int *numbers, int count)
{
	int	i;

	m->a = stack_create();
	m->b = stack_create();
	if (!m->a || !m->b)
		return ;
	i = -1;
	while (++i < count)
		stack_add_back(m->a, numbers[i]);
}

static t_machine	*init_error(t_machine *m, char *msg, int *numbers)
{
	if (msg)
		log_message(m, LOG_ERROR, msg);
	if (numbers)
		free(numbers);
	if (m)
	{
		if (m->a)
			stack_free(m->a);
		if (m->b)
			stack_free(m->b);
		free(m);
	}
	return (NULL);
}

static t_bool	process_args(t_machine *m, int count, char **values)
{
	int	*numbers;

	if (!parse_args(count, values, &numbers))
		return (init_error(m, "Invalid number format", NULL), FT_FALSE);
	if (has_duplicates(numbers, count))
		return (init_error(m, "Duplicate numbers detected", numbers), FT_FALSE);
	init_stacks(m, numbers, count);
	free(numbers);
	return (FT_TRUE);
}

t_machine	*machine_init(int count, char **values)
{
	t_machine	*m;

	if (count < 0 || (count > 0 && !values))
		return (NULL);
	m = ft_calloc(1, sizeof(t_machine));
	if (!m)
		return (NULL);
	m->log_level = LOG_WARNING;
	m->log_fd = STDERR_FILENO;
	if (count > 0)
	{
		if (!process_args(m, count, values))
			return (NULL);
	}
	else
	{
		m->a = stack_create();
		m->b = stack_create();
	}
	if (!m->a || !m->b)
		return (init_error(m, "Stack initialization failed", NULL));
	return (m);
}
