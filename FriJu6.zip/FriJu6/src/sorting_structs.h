/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_structs.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 14:30:00 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 07:55:34 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORTING_STRUCTS_H
# define SORTING_STRUCTS_H

# include <stddef.h>

typedef struct s_chunk_data
{
	int	*sorted_arr;
	int	chunk_start;
	int	chunk_end;
	int	median;
}	t_chunk_data;

typedef struct s_push_chunks_params
{
	int		*sorted_arr;
	size_t	size;
	int		chunk_size;
}		t_push_chunks_params;

#endif