/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   log_utils.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 00:01:45 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 00:01:53 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/ft_io.h"
#include "../include/machine.h"
#include <fcntl.h>
#include <unistd.h>

void	init_logging(t_machine *m, t_log_level level, const char *filename)
{
	if (!m)
		return ;
	if (m->log_fd > STDERR_FILENO)
		close(m->log_fd);
	m->log_level = level;
	if (filename)
	{
		m->log_fd = open(filename, O_WRONLY | O_CREAT | O_APPEND, 0644);
		if (m->log_fd < 0)
		{
			m->log_fd = STDERR_FILENO;
			ft_putstr_const_fd("ERROR: cannot open log: ", STDERR_FILENO);
			ft_putendl_const_fd(filename, STDERR_FILENO);
		}
	}
	else
	{
		m->log_fd = STDERR_FILENO;
	}
}

void	log_message(t_machine *m, t_log_level level, const char *msg)
{
	const char	*prefix;

	if (!m || !msg || !*msg)
		return ;
	if (level < LOG_ERROR || level > LOG_DEBUG)
		return ;
	if (level > m->log_level)
		return ;
	if (level == LOG_ERROR)
		prefix = "ERROR: ";
	else if (level == LOG_WARNING)
		prefix = "WARNING: ";
	else if (level == LOG_INFO)
		prefix = "INFO: ";
	else
		prefix = "DEBUG: ";
	ft_putstr_const_fd(prefix, m->log_fd);
	ft_putendl_const_fd(msg, m->log_fd);
	if (level == LOG_ERROR && m->log_fd != STDERR_FILENO)
	{
		ft_putstr_const_fd(prefix, STDERR_FILENO);
		ft_putendl_const_fd(msg, STDERR_FILENO);
	}
}
