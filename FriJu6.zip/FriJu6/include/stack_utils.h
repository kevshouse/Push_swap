/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_utils.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/06 01:00:59 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/06 01:01:03 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_UTILS_H
# define STACK_UTILS_H

# include "machine.h"

t_stack	*stack_create(void);
void	stack_free(t_stack *stack);
void	stack_add_back(t_stack *stack, int value);

#endif