#include "../includes/libft.h"

void ft_putstr_const_fd(const char *s, int fd)
{
	if(s)
		ft_putstr_fd((char *)s, fd);
}
