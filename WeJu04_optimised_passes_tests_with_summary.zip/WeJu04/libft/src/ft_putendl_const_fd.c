#include "../includes/libft.h"

void ft_putendl_const(const char *s)
{
	ft_putendl_const_fd(s, STDOUT_FILENO);
}

void ft_putendl_const_fd(const char *s, int fd)
{
	if(s)
		ft_putendl_fd((char *)s, fd);
}
