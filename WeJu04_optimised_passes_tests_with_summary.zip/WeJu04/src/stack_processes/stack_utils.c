#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include <stdlib.h>
#include <limits.h>

t_stack *stack_create(void)
{
	t_stack *s;

	s = ft_calloc(1, sizeof(t_stack));
	if(s)
	{
		s->size   = 0;
		s->top    = NULL;
		s->bottom = NULL;
	}
	return (s);
}

void stack_add_back(t_stack *s, int value)
{
	t_node *new;

	if(!s)
		return;
	new = ft_calloc(1, sizeof(t_node));
	if(!new)
		return;
	new->value = value;
	new->next  = NULL;
	if(!s->top)
	{
		s->top    = new;
		s->bottom = new;
		new->prev = NULL;
	}
	else
	{
		new->prev       = s->bottom;
		s->bottom->next = new;
		s->bottom       = new;
	}
	s->size++;
}

t_bool ft_isvalidnum(const char *str)
{
	if(!str || !*str)
		return (FT_FALSE);
	if(*str == '-' || *str == '+')
		str++;
	if(!*str)
		return (FT_FALSE);
	while(*str)
	{
		if(!ft_isdigit(*str))
			return (FT_FALSE);
		str++;
	}
	return (FT_TRUE);
}

t_bool ft_issafe(const char *str)
{
	long num;
	int  sign;

	sign = 1;
	num  = 0;
	if(*str == '-' || *str == '+')
	{
		if(*str == '-')
			sign = -1;
		str++;
	}
	while(*str >= '0' && *str <= '9')
	{
		num = num * 10 + (*str - '0');
		if((sign == 1 && num > INT_MAX) ||
		   (sign == -1 && num > (long)INT_MAX + 1))
			return (FT_FALSE);
		str++;
	}
	return (FT_TRUE);
}
