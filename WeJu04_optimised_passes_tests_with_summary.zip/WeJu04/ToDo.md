Typical Directory Structure:
push_swap/
├── include/
│   └── machine.h
├── libft/
│   ├── includes/
│   └── ... (libft implementation)
├── src/
│   ├── execution_dispatcher.c
│   ├── machine_init.c
│   ├── machine_free.c
│   ├── log_utils.c
│   ├── stack_utils.c
│   ├── operations_s.c
│   ├── operations_p.c
│   ├── operations_r.c
│   ├── operations_rr.c
│   └── stack_inspection.c
├── Makefile
└── main.c (your main push_swap file)

Remove the depricated files from src directory (those not listed in the tree above).
