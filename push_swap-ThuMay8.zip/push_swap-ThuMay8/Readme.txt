push_swap/
├── includes/
│   └── push_swap.h  // Structs and function prototypes
└── src/
    ├── order_code/
    │   ├── swap.c    // swap(), sa(), sb(), ss()
    │   ├── push.c    // push(), pa(), pb()
    │   ├── rotate.c  // rotate(), ra(), rb(), rr()
    │   └── reverse_rotate.c  // reverse_rotate(), rra(), rrb(), rrr()
    └── main.c
# ------------ Test Driven Version Below ------------------------- #

project/
├── include/
│   ├── mylib.h        // Main library header
│   ├── utils.h        // Shared utilities
│   └── config.h       // Project-wide configs
├── src/
│   ├── main.c         // Main program
│   ├── mylib.c        // Implementation of mylib.h
│   └── utils.c        // Implementation of utils.h
├── tests/
│   └── test_mylib.c   // Test suite
└── Makefile

Key Benefits
Single Source of Truth: Avoid duplicated declarations.
Clean Separation: Callers #include <header.h> without needing to know implementation details.
Portability: Headers define the contract between components.



#  Make file targets
make clean   # Remove build artifacts
make fclean  # Remove build artifacts and executables
make re      # Clean everything and rebuild from scratch
make all     # Build both app and tests
make app     # Build only the application
make test    # Build and run tests

#########################
# Files to Place in include/
Public Headers
1. Header files defining:
*   Function declarations (API)
*   Public data structures
*   Macros
*   Constants
*   Type definitions (typedefs)
2. Header-Only Libraries
*   Utility libraries that contain only header files (e.g., STB-style headers).
3. API Headers
*   Public-facing interfaces if you're building a library.
4. Project-Wide Configs
*   Configuration files shared across the project:

# What Doesn't Belong in include/
*   Private Headers: Headers only used internally within a single .c file (keep these in src/).
*   Source Files (.c files): These belong in src/.
*   Test-Specific Headers: Keep these in tests/.

Rules
In the context of the School42 Push_swap project, the rules typically emphasize that your program should manipulate the stacks using the defined operations (push, swap, rotate, and reverse rotate) without directly accessing or inspecting the values in the stacks outside of these operations.

Key Points Regarding Stack Manipulation
Encapsulation of Stack Operations: The project is designed to test your ability to implement sorting algorithms using the stack operations provided. You should not directly access the internal structure of the stack to read values without using the defined operations.

No Direct Access: The project guidelines generally discourage accessing the values in the stack directly (e.g., by traversing the linked list or accessing nodes directly) without performing the allowed operations. This means you should not "peek" at values or check conditions without using the stack operations.

Focus on Operations: The goal is to implement a sorting algorithm that relies solely on the operations defined in the project. This encourages you to think about how to manipulate the stack effectively using the allowed operations rather than relying on direct access to the data.

Conclusion
In summary, your program should not see or access other values in the stack without using the defined operations. You should focus on implementing the sorting logic using the operations specified in the project documentation. If you need to check conditions or make decisions based on the values in the stack, you should do so by using the operations (like rotating or popping) to manipulate the stack as required.
