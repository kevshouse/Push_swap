// File: push_swap_sorter.c
//#include "../../inc/push_swap.h"

typedef struct s_cost {
    int ra;
    int rra;
    int rb;
    int rrb;
    int total;
} t_cost;

static t_cost   calculate_cost(t_stack *a, t_stack *b, t_node *node);
static void     execute_cheapest(t_stack *a, t_stack *b);
static void     rotate_to_target(t_stack *a, t_stack *b, t_node *target_a, t_node *target_b);
static t_node   *find_target_node(t_stack *b, int value);

// Main sorting controller
void sort_stack(t_stack *a, t_stack *b)
{
    if (is_sorted(a)) return;

    // Phase 1: Push all except 3 elements to B
    while (a->size > 3 && !is_sorted(a))
    {
        pb(a, b);
        pb(a, b);
        while (a->size > 3)
        {
            execute_cheapest(a, b);
            pb(a, b);
        }
    }

    // Phase 2: Sort remaining 3 elements
    if (a->size == 3)
        sort_three(a);
    else if (a->size == 2)
        sa(a);

    // Phase 3: Smart push back to A
    while (b->size > 0)
    {
        t_node *target = find_target_node(a, b->top->data);
        rotate_to_target(a, b, target, b->top);
        pa(a, b);
    }

    // Final rotation to get minimum to top
    rotate_min_to_top(a);
}

// Cost calculation implementation
static t_cost calculate_cost(t_stack *a, t_stack *b, t_node *node)
{
    t_cost cost = {0};
    t_node *target = find_target_node(b, node->data);

    // Calculate rotations for stack A
    if (node->index <= a->size / 2)
        cost.ra = node->index;
    else
        cost.rra = a->size - node->index;

    // Calculate rotations for stack B
    if (target->index <= b->size / 2)
        cost.rb = target->index;
    else
        cost.rrb = b->size - target->index;

    // Calculate total cost
    cost.total = cost.ra + cost.rb + cost.rra + cost.rrb;
    return cost;
}

// Execute cheapest move based on cost analysis
static void execute_cheapest(t_stack *a, t_stack *b)
{
    t_node *current = a->top;
    t_node *cheapest = current;
    t_cost min_cost = calculate_cost(a, b, current);

    while (current)
    {
        t_cost current_cost = calculate_cost(a, b, current);
        if (current_cost.total < min_cost.total)
        {
            min_cost = current_cost;
            cheapest = current;
        }
        current = current->next;
    }

    // Execute rotations
    rotate_to_target(a, b, cheapest, find_target_node(b, cheapest->data));
}

// Rotation logic handler
static void rotate_to_target(t_stack *a, t_stack *b, t_node *target_a, t_node *target_b)
{
    // Calculate required rotations
    int ra = target_a->index;
    int rra = a->size - target_a->index;
    int rb = target_b->index;
    int rrb = b->size - target_b->index;

    // Optimize rotation combinations
    while (ra > 0 && rb > 0)
    {
        rr(a, b);
        ra--;
        rb--;
    }
    while (rra > 0 && rrb > 0)
    {
        rrr(a, b);
        rra--;
        rrb--;
    }

    // Remaining rotations
    while (ra-- > 0) ra(a);
    while (rra-- > 0) rra(a);
    while (rb-- > 0) rb(b);
    while (rrb-- > 0) rrb(b);
}

// Find proper position in stack B for a value
static t_node *find_target_node(t_stack *b, int value)
{
    t_node *current = b->top;
    t_node *target = NULL;
    int min_diff = INT_MAX;

    while (current)
    {
        if (current->data > value && current->data - value < min_diff)
        {
            min_diff = current->data - value;
            target = current;
        }
        current = current->next;
    }
    return target ? target : find_max(b);
}

// Helper to find max node
t_node *find_max(t_stack *stack)
{
    t_node *max = stack->top;
    t_node *current = stack->top;

    while (current)
    {
        if (current->data > max->data)
            max = current;
        current = current->next;
    }
    return max;
}

// Final stack alignment
void rotate_min_to_top(t_stack *a)
{
    t_node *min = find_min(a);
    int rotations = min->index;

    if (rotations <= a->size / 2)
        while (rotations-- > 0) ra(a);
    else
        while (a->size - rotations++ > 0) rra(a);
}
