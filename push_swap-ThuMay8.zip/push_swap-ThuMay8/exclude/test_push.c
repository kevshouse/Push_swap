#include <criterion/criterion.h>
#include <stdlib.h>
# include "../inc/push_swap.h"

// Helper function to create a new stack
t_stack* create_stack()
{
    t_stack *stack = malloc(sizeof(t_stack));
    stack->top = NULL;
    stack->tail = NULL;
    stack->size = 0;
    return stack;
}

// Helper function to free a stack
void free_stack(t_stack *stack)
{
    t_node *current = stack->top;
    while (current)
    {
        t_node *next = current->next;
        free(current);
        current = next;
    }
    free(stack);
}

// Test for push function
Test(push_swap, push_test)
{
    t_stack *stack = create_stack();
    push(stack, 42);
    cr_assert_eq(stack->top->data, 42, "Expected top of stack to be 42");
    cr_assert_eq(stack->size, 1, "Expected stack size to be 1");

    push(stack, 84);
    cr_assert_eq(stack->top->data, 84, "Expected top of stack to be 84 after second push");
    cr_assert_eq(stack->size, 2, "Expected stack size to be 2 after second push");

    free_stack(stack);
}
