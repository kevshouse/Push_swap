// ft_atoi_secure.c

#include "limits.h"

int ft_atoi_secure(const char *str, int *error)
{
    long        result;
    int         sign;
    int         i;

    result = 0;
    sign = 1;  // Default sign is positive
    i = 0;
    *error = 0;  // Ensure error is initialized to 0

    // Skip leading whitespace
    while (str[i] == ' ' || (str[i] >= '\t' && str[i] <= '\r'))
        i++;

    // Check for sign
    if (str[i] == '-' || str[i] == '+')
    {
        if (str[i] == '-')
            sign = -1;
        else
            sign = 1;
        i++;
    }

    // Check for empty string after sign/whitespace
    if (str[i] == '\0')
    {
        *error = 1;
        return (0);
    }

    // Convert digits to number and check for overflow
    while (str[i] >= '0' && str[i] <= '9')
    {
        result = result * 10 + (str[i] - '0');

        // Check for overflow based on sign
        if ((sign == 1 && result > INT_MAX) ||
            (sign == -1 && result > (long)INT_MAX + 1))
        {
            *error = 1;
            return (0);
        }
        i++;
    }

    // Check for invalid characters
    if (str[i] != '\0')
    {
        *error = 1;
        return (0);
    }

    // Apply sign and return result
    return ((int)(result * sign));
}
