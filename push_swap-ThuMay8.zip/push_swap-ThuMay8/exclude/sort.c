//# include "../../inc/push_swap.h"

// Function to sort the stack
void sort_stack(t_stack *s)
{
    if (s->size <= 1) return; // No need to sort if size is 0 or 1

    if (s->size == 2)
    {
        if (s->top->data > s->top->next->data)
            sa(s); // Swap if the first element is greater than the second
    }
    else if (s->size == 3)
        sort_three(s); // Call the special case for three items
    else
    {
        // Implement sorting logic for larger stacks (e.g., using a sorting algorithm)
        // For example, you could implement a simple bubble sort or selection sort
    }
}
