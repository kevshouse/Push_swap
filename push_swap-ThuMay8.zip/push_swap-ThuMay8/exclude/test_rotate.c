#include <criterion/criterion.h>
#include <stdlib.h>
# include "../inc/push_swap.h"

t_node *new_node(int data);

// Helper: create a new node with given data
t_node *new_node(int data)
{
    t_node *node = malloc(sizeof(t_node));
    cr_assert_not_null(node, "Memory allocation failed");
    node->data = data;
    node->next = NULL;
    return node;
}

// Helper: create an empty stack
t_stack *create_stack(void)
{
    t_stack *stack = malloc(sizeof(t_stack));
    cr_assert_not_null(stack, "Memory allocation failed");
    stack->top = NULL;
    stack->tail = NULL;
    stack->size = 0;
    return stack;
}

// Helper: push value to front of stack (so that new node is new top)
void push(t_stack *stack, int value)
{
    t_node *node = new_node(value);
    node->next = stack->top;
    stack->top = node;

    if (stack->size == 0)
    {
        stack->tail = node;
    }
    stack->size++;
}

// Helper: free all nodes in the stack, then free stack itself
void free_stack(t_stack *stack)
{
    t_node *curr = stack->top;
    while (curr)
    {
        t_node *next = curr->next;
        free(curr);
        curr = next;
    }
    free(stack);
}

// Helper: verify stack nodes' data in order top -> ...
void cr_assert_stack_equals(t_stack *stack, int *values, int len)
{
    cr_assert_eq(stack->size, len, "Stack size mismatch");
    t_node *curr = stack->top;
    for (int i = 0; i < len; i++)
    {
        cr_assert_not_null(curr, "Stack shorter than expected");
        cr_assert_eq(curr->data, values[i], "Stack data mismatch at index %d", i);
        curr = curr->next;
    }
    cr_assert_null(curr, "Stack longer than expected");
}

// ---------- Tests for ra ----------

Test(rotate, ra_multiple_elements)
{
    t_stack *a = create_stack();
    push(a, 3);
    push(a, 2);
    push(a, 1); // Stack order: 1 -> 2 -> 3

    ra(a);

    // After rotation: top should be 2, followed by 3, tail is 1
    int expected[] = {2, 3, 1};
    cr_assert_stack_equals(a, expected, 3);
    cr_assert_eq(a->tail->data, 1);

    free_stack(a);
}

Test(rotate, ra_single_element)
{
    t_stack *a = create_stack();
    push(a, 1); // Stack: 1

    ra(a);

    // Single element stack stays the same
    int expected[] = {1};
    cr_assert_stack_equals(a, expected, 1);
    cr_assert_eq(a->tail->data, 1);

    free_stack(a);
}

Test(rotate, ra_empty_stack)
{
    t_stack *a = create_stack();

    ra(a);

    cr_assert_null(a->top);
    cr_assert_null(a->tail);
    cr_assert_eq(a->size, 0);

    free_stack(a);
}

// ---------- Tests for rr ----------

Test(rotate, rr_both_multiple_elements)
{
    t_stack *a = create_stack();
    push(a, 3);
    push(a, 2);
    push(a, 1); // 1 -> 2 -> 3

    t_stack *b = create_stack();
    push(b, 6);
    push(b, 5);
    push(b, 4); // 4 -> 5 -> 6

    rr(a, b);

    int expected_a[] = {2, 3, 1};
    int expected_b[] = {5, 6, 4};

    cr_assert_stack_equals(a, expected_a, 3);
    cr_assert_eq(a->tail->data, 1);

    cr_assert_stack_equals(b, expected_b, 3);
    cr_assert_eq(b->tail->data, 4);

    free_stack(a);
    free_stack(b);
}

Test(rotate, rr_a_empty_b_multiple)
{
    t_stack *a = create_stack();

    t_stack *b = create_stack();
    push(b, 9);
    push(b, 8);
    push(b, 7); // 7 -> 8 -> 9

    rr(a, b);

    // a unchanged
    cr_assert_null(a->top);
    cr_assert_null(a->tail);
    cr_assert_eq(a->size, 0);

    // b rotated
    int expected_b[] = {8, 9, 7};
    cr_assert_stack_equals(b, expected_b, 3);
    cr_assert_eq(b->tail->data, 7);

    free_stack(a);
    free_stack(b);
}

Test(rotate, rr_a_multiple_b_empty)
{
    t_stack *a = create_stack();
    push(a, 10);
    push(a, 11);
    push(a, 12); // 12 -> 11 -> 10

    t_stack *b = create_stack();

    rr(a, b);

    int expected_a[] = {11, 10, 12};
    cr_assert_stack_equals(a, expected_a, 3);
    cr_assert_eq(a->tail->data, 12);

    cr_assert_null(b->top);
    cr_assert_null(b->tail);
    cr_assert_eq(b->size, 0);

    free_stack(a);
    free_stack(b);
}

Test(rotate, rr_both_empty)
{
    t_stack *a = create_stack();
    t_stack *b = create_stack();

    rr(a, b);

    cr_assert_null(a->top);
    cr_assert_null(a->tail);
    cr_assert_eq(a->size, 0);

    cr_assert_null(b->top);
    cr_assert_null(b->tail);
    cr_assert_eq(b->size, 0);

    free_stack(a);
    free_stack(b);
}
