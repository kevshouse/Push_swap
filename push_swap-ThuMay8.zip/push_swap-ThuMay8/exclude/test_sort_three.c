#include <criterion/criterion.h>
#include "../inc/push_swap.h"

// Helper: create a stack with exactly three nodes given three values
static t_stack *create_stack_three(int d1, int d2, int d3)
{
    t_stack *stack = malloc(sizeof(t_stack));
    t_node *n1 = create_node(d1);
    t_node *n2 = create_node(d2);
    t_node *n3 = create_node(d3);

    // Link nodes
    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    stack->top = n1;
    stack->second_last = n2;
    stack->tail = n3;
    stack->size = 3;

    return stack;
}

// Helper: free stack nodes
void free_stack(t_stack *stack)
{
    t_node *curr = stack->top;
    while (curr)
    {
        t_node *tmp = curr;
        curr = curr->next;
        free(tmp);
    }
    free(stack);
}

// Helper: check if stack nodes are sorted ascending (top to tail)
int is_sorted(t_stack *stack)
{
    t_node *curr = stack->top;
    while (curr && curr->next != NULL)
    {
        if (curr->data > curr->next->data)
            return 0;
        curr = curr->next;
    }
    return 1;
}

// Test Cases

Test(sort_three_suite, sorts_three_integers)
{
    t_stack *stack = create_stack_three(3, 1, 2);

    t_rotation_result result = sort_three(stack);

    cr_assert(is_sorted(stack), "Stack is not sorted after sort_three");
    cr_assert_eq(result.error, NO_ERROR, "Expected no error during sorting");

    free_stack(stack);
}

Test(sort_three_suite, handles_already_sorted)
{
    t_stack *stack = create_stack_three(1, 2, 3);

    t_rotation_result result = sort_three(stack);

    cr_assert(is_sorted(stack), "Stack should remain sorted if already sorted");
    cr_assert_eq(result.error, NO_ERROR, "Expected no error during sorting");

    free_stack(stack);
}

Test(sort_three_suite, sorts_reverse_order)
{
    t_stack *stack = create_stack_three(3, 2, 1);

    t_rotation_result result = sort_three(stack);

    cr_assert(is_sorted(stack), "Stack is not sorted after sort_three on reverse order");
    cr_assert_eq(result.error, NO_ERROR, "Expected no error during sorting");

    free_stack(stack);
}

Test(sort_three_suite, handles_two_equal_elements)
{
    t_stack *stack = create_stack_three(2, 3, 2);

    t_rotation_result result = sort_three(stack);

    cr_assert(is_sorted(stack), "Stack is not sorted after sort_three with duplicates");
    cr_assert_eq(result.error, NO_ERROR, "Expected no error during sorting");

    free_stack(stack);
}
