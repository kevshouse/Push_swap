#include "../../inc/push_swap.h"
#include <stdio.h>
#include <stdlib.h>

void push(t_stack *stack, int data)
{
    if (stack == NULL)
    {
        return;
    }

    t_node *new_node = malloc(sizeof(t_node));
    if (!new_node)
    {
        return;
    }

    new_node->data = data;
    new_node->prev = NULL;
    new_node->next = NULL;

    if (stack->size == 0)
    {
        stack->top = new_node;
        stack->tail = new_node;
    }
    else
    {
        // Link new node's prev to the old top (node below)
        new_node->prev = stack->top;
        // Link old top's next to the new node (node above)
        stack->top->next = new_node;
        // Update stack's top to the new node
        stack->top = new_node;
    }

    stack->size++;
}

// Wrapper for pa (push from b to a)
void pa(t_stack *a, t_stack *b)
{
    if (b == NULL || b->size == 0)
    {
        return;
    }

    int data = b->top->data;
    push(a, data);

    t_node *temp = b->top;
    b->top = b->top->next;
    if (b->top)
    {
        b->top->prev = NULL;
    }
    else
    {
        b->tail = NULL;
    }
    free(temp);
    b->size--;
}

// Wrapper for pb (push from a to b)
void pb(t_stack *a, t_stack *b)
{
    if (a == NULL || a->size == 0)
    {
        return;
    }

    int data = a->top->data;
    push(b, data);

    t_node *temp = a->top;
    a->top = a->top->next;
    if (a->top)
    {
        a->top->prev = NULL;
    }
    else
    {
        a->tail = NULL;
    }
    free(temp);
    a->size--;
}
