// project_main.c

#include "../inc/push_swap.h"

// Dummy implementation for parse_args
void parse_args(t_stack *a) {
    // For now, just push some dummy values to test
    push(a, 3);
    push(a, 2);
    push(a, 1);
}

// Dummy implementation for calculate_indexes
void calculate_indexes(t_stack *stack)
{
    t_node *current = stack->top;
    int index = 0;
    while (current)
    {
        // For now, just assign a simple index
        current->index = index++;
        current = current->next;
    }
}

// Dummy implementation for is_sorted
int is_sorted(t_stack *stack) {
    t_node *current = stack->top;
    while (current && current->next) {
        if (current->data > current->next->data) {
            return 0; // Not sorted
        }
        current = current->next;
    }
    return 1; // Sorted
}

// Dummy implementation for sort_stack
void d_sort_stack(t_stack *a) {
    // For now, just sort three elements
    if (a->size == 3) {
        sort_three(a);
    }
    // You can add more dummy logic here as needed
}

int main() {
    t_stack *a = create_stack();
    t_stack *b = create_stack();

   // parse_args(argc, argv, a);
   // calculate_indexes(a);
   // calculate_indexes(b);

    if (!is_sorted(a)) {
        d_sort_stack(a);
    }

    free_stack(a);
    free_stack(b);
    return 0;
}
