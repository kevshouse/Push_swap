#include "../../inc/push_swap.h"

typedef struct {
    t_node *min_node;
    int rotations;
} t_min_info;

t_min_info* find_min_info(t_stack *stack)
{
    t_min_info *info = malloc(sizeof(t_min_info));
    if (stack->size <= 1) {
        info->min_node = NULL;
        info->rotations = 0;
        return info;
    }
    info->min_node = stack->top;
    t_node *current = stack->top;
    while (current != NULL)
    {
        if (current->data < info->min_node->data)
        {
            info->min_node = current;
        }
        current = current->prev;
    }
    int rotations = 0;
    current = stack->top;
    while (current != info->min_node)
    {
        rotations++;
        current = current->prev;
    }
    info->rotations = rotations;
    return info;
} //Is there any danger that rotate_min_to_top() won't be run
//  leaving info waiting to leak?

void rotate_min_to_top(t_stack *stack, t_rotate_func rotate_func)
{
    t_min_info *info = find_min_info(stack);
    int     i;

    i = 0;
    if (info->min_node == NULL || info->rotations == 0)
    {
        free(info);
        return;
    }
    while (i < info->rotations) {
        rotate_func(stack);
        i++;
    }
    free(info);
}
