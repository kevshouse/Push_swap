// insertion_sort.c
#include "../../inc/push_swap.h"

void insertion_sort(t_stack *stack_a, t_stack *stack_b)
{
    while (stack_a->size > 0)
    {
        rotate_min_to_top(stack_a, ra); // Pass the rotation function
        pa(stack_b, stack_a);
        ra(stack_a);
    }
    // After performing sorting operations
    checker(stack_a, stack_b);
}
