//Modified Quicksort for Larger Stacks

#include "../../inc/push_swap.h"

int select_pivot(t_stack *stack)
{
    if (stack->size < 3) {
        return stack->top->data;
    }
    t_node *mid = stack->top;
    for (int i = 0; i < stack->size / 2; i++)
    {
        mid = mid->prev;
    }
    int low = stack->top->data;
    int high = stack->tail->data;
    if (low < mid->data && mid->data < high)
    {
        return mid->data;
    } else if (low < high && high < mid->data)
    {
        return high;
    }
    else
    {
        return low;
    }
}

void partition(t_stack *stack_a, t_stack *stack_b, int pivot)
{
    while (stack_a->size > 0 && stack_a->top->data != pivot)
    {
        if (stack_a->top->data < pivot)
        {
            pa(stack_b, stack_a);
        } else {
            pa(stack_a, stack_a);
        }
        ra(stack_a);
    }
    if (stack_a->size > 0 && stack_a->top->data == pivot)
    {
        pa(stack_b, stack_a);
        ra(stack_a);
    }
}

void quick_sort(t_stack *stack_a, t_stack *stack_b)
{
    if (stack_a->size <= 1)
    {
        return;
    }
    int pivot = select_pivot(stack_a);
    partition(stack_a, stack_b, pivot);
    quick_sort(stack_a, stack_b);
    quick_sort(stack_b, stack_a);
}
