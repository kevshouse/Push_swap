// checker.c
#include "../../inc/push_swap.h"
#include <stdio.h> // Include for printf

/*void checker(t_stack *stack_a, t_stack *stack_b) {
    if (stack_b->size != 0) {
        printf("Error: Elements remain in stack_b\n");
        return;
    }

    t_node *current = stack_a->top;
    while (current->next != NULL) { // Check until the last node
        if (current->data > current->next->data) { // Compare current with the next node
            printf("Error: Stack_a is not sorted\n");
            return;
        }
        current = current->next; // Move to the next node
    }
    printf("Success: Stack_a is sorted\n");
    }*/

void checker(t_stack *stack_a, t_stack *stack_b)
{
    if (stack_b->size != 0) {
        printf("Error: Elements remain in stack_b\n");
        return;
    }
    t_node *current = stack_a->top;
    while (current != NULL && current->next != NULL)
    {
        printf("Checking node with data %d against next node with data %d\n", current->data, current->next->data);
        if (current->data > current->next->data)
        {
            printf("Error: Stack_a is not sorted\n");
             return;
        }
            current = current->next; // Move to the next node
    }
    printf("Success: Stack_a is sorted\n");
}
