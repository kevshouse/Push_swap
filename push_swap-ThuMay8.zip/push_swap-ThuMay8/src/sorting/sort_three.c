#include "../../inc/push_swap.h"

void sort_three(t_stack *stack)
{
    if (stack->size != 3) return; // Only handle if the size is exactly 3
    int first = stack->top->data;
    int second = stack->top->next->data;
    int third = stack->top->next->next->data;

    // Check the order and perform necessary operations
    if (first > second && second > third)
    {
            // Case: 3, 2, 1 (descending order)
        sa(stack); // Swap first and second
        rra(stack); // Reverse rotate to bring the largest to the top
    }
    else if (first > second && first < third)
    {
        // Case: 2, 1, 3
        sa(stack); // Swap first and second
    }
    else if (second > first && second < third)
    {
            // Case: 1, 3, 2
        rra(stack); // Reverse rotate to bring the largest to the top
    }
    else if (first < second && second > third && first > third)
    {
        // Case: 1, 2, 3 (already sorted)
        // No operation needed
    }
}
