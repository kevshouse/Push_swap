// count_moves.c
#include "../../inc/push_swap.h"
int count_moves(t_stack *stack_a, t_stack *stack_b)
{
    int moves = 0;
    while (stack_a->size > 0 || stack_b->size > 0)
    {
        if (stack_a->size > 0 && (stack_b->size == 0 || stack_a->top->data < stack_b->top->data))
        {
            pa(stack_b, stack_a);
            ra(stack_a);
            moves++;
        }
        else
        {
            pa(stack_a, stack_b);
            rb(stack_b);
            moves++;
        }
    }
    return moves;
}
