// Modified Quicksort for Larger Stacks
//
#include "../../inc/push_swap.h"

void quick_a(t_stack *stack_a, t_stack *stack_b)
{
    if (stack_a->size <= 5)
    {
        insertion_sort(stack_a, stack_b);
    }
    else
    {
        quick_sort(stack_a, stack_b);
    }
    // After performing sorting operations
    checker(stack_a, stack_b);
}

void quick_b(t_stack *stack_b, t_stack *stack_a)
{
    if (stack_b->size <= 5)
    {
        insertion_sort(stack_b, stack_a);
    }
    else
    {
        quick_sort(stack_b, stack_a);
    }
    // After performing sorting operations
    checker(stack_a, stack_b);
}
