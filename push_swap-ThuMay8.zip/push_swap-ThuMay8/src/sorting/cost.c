#include "../../inc/push_swap.h"
#include <stdio.h> // Include for printf

#define SUCCESS 0
#define ERROR_STACK_EMPTY -1
#define ERROR_VALUE_NOT_FOUND -2

// Function to assign indexes to the nodes in the stack
void assign_indexes(t_stack *stack) {
    t_node *current = stack->top;
    int index = 0;

    while (current != NULL) {
        current->index = index;
        printf("Assigned index %d to node with data %d\n", index, current->data); // Debugging statement
        index++;
        current = current->next; // Move to the next node
    }
}

t_rotation_result calculate_rotations(t_stack *stack) {
    t_rotation_result result = {0, ROTATION_OK};

    if (stack->size <= 1) {
        result.error = ROTATION_EMPTY_STACK;
        return result;
    }

    // Assign indexes to the nodes
    assign_indexes(stack);

    t_node *min_node = stack->top;
    t_node *current = stack->top;

    // Find the minimum node
    while (current != NULL) {
        if (current->data < min_node->data) {
            min_node = current;
        }
        current = current->next;
    }

    // Calculate the number of rotations to bring the minimum node to the top
    int index = min_node->index;
    int size = stack->size;

    // The number of rotations needed to bring the minimum node to the top
    result.rotations = (index <= (size - index)) ? index : (size - index);

    return result;
}


// Wrapper functions for stacks a and b
t_rotation_result calculate_rotations_a(t_stack *a) {
    return calculate_rotations(a);
}

t_rotation_result calculate_rotations_b(t_stack *b) {
    return calculate_rotations(b);
}
