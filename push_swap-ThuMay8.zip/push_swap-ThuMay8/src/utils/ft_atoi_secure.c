// ft_atoi_secure.c
#include "../../inc/push_swap.h"
#include <limits.h>

t_atoi_result ft_atoi_secure(const char *str)
{
    t_atoi_result result;
    long        res = 0;
    int         sign = 1;
    int         i = 0;
    result.error = 0;  // Initialize error to 0

    // Skip whitespace
    while (str[i] == ' ' || (str[i] >= '\t' && str[i] <= '\r'))
        i++;

    // Handle sign
    if (str[i] == '-' || str[i] == '+')
    {
        sign = (str[i] == '-') ? -1 : 1;
        i++;
    }

    // Check for empty string after sign
    if (str[i] == '\0')
    {
        result.error = 1;
        return result;
    }

    // Process digits
    while (str[i] >= '0' && str[i] <= '9')
    {
        res = res * 10 + (str[i] - '0');

        // Check overflow
        if ((sign == 1 && res > INT_MAX) ||
            (sign == -1 && res > (long)INT_MAX + 1))
        {
            result.error = 1;
            return result;
        }
        i++;
    }

    // Check trailing characters
    if (str[i] != '\0')
    {
        result.error = 1;
        return result;
    }

    result.value = (int)(res * sign);
    return result;
}
