#include <criterion/criterion.h>
#include "../inc/push_swap.h"

// Test create_stack and free_stack
Test(stack_suite, create_stack)
{
    t_stack *stack = create_stack();
    cr_assert_not_null(stack, "Stack creation failed");
    cr_assert_null(stack->top, "Stack top not null");
    cr_assert_null(stack->tail, "Stack tail not null");
    cr_assert_eq(stack->size, 0, "Stack size not 0");
    free_stack(stack);
}

Test(stack_suite, null_pointer_handling)
{
    t_stack *stack = NULL;
    free_stack(stack);
    // No crash or errors expected
}

Test(stack_suite, multiple_calls)
{
    t_stack *stack = create_stack();
    free_stack(stack);
    stack = NULL; // Set to NULL after freeing
    // No crash or errors expected
}
