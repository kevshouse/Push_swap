#include <criterion/criterion.h>
#include "../inc/push_swap.h"

// Rotate Operations Test Suite
/*TestSuite(rotate_suite);

// Test Case: test_ra_empty_stack
Test(rotate_suite, test_ra_empty_stack) {
    t_stack *a = create_stack(); // Create an empty stack
    ra(a); // Attempt to rotate
    cr_assert_eq(a->size, 0); // Stack A should remain empty
    free_stack(a);
}

// Test Case: test_ra_single_element
Test(rotate_suite, test_ra_single_element) {
    t_stack *a = create_stack();
    push(a, 1); // Push a single element onto the stack
    ra(a); // Attempt to rotate
    cr_assert_eq(a->top->data, 1); // Stack A should still have the same element
    cr_assert_eq(a->size, 1); // Stack A size should remain 1
}

// Test Case: test_ra_normal_operation
Test(rotate_suite, test_ra_normal_operation) {
    t_stack *a = create_stack();
    push(a, 1);
    push(a, 2);
    push(a, 3); // Stack A: 1 (top), 2, 3 (bottom)

    ra(a); // Rotate A
    cr_assert_eq(a->top->data, 2); // After rotation, top should be 2
    cr_assert_eq(a->top->next->data, 3); // Next should be 3
    cr_assert_eq(a->size, 3); // Size should remain 3
    free_stack(a);
}

// Test Case: test_rb_empty_stack
Test(rotate_suite, test_rb_empty_stack) {
    t_stack *b = create_stack(); // Create an empty stack
    rb(b); // Attempt to rotate
    cr_assert_eq(b->size, 0); // Stack B should remain empty
    free_stack(b);
}

// Test Case: test_rb_single_element
Test(rotate_suite, test_rb_single_element) {
    t_stack *b = create_stack();
    push(b, 1); // Push a single element onto the stack
    rb(b); // Attempt to rotate
    cr_assert_eq(b->top->data, 1); // Stack B should still have the same element
    cr_assert_eq(b->size, 1); // Stack B size should remain 1
}

// Test Case: test_rb_normal_operation
Test(rotate_suite, test_rb_normal_operation) {
    t_stack *b = create_stack();
    push(b, 4);
    push(b, 5);
    push(b, 6); // Stack B: 4 (top), 5, 6 (bottom)

    rb(b); // Rotate B
    cr_assert_eq(b->top->data, 5); // After rotation, top should be 5
    cr_assert_eq(b->top->next->data, 6); // Next should be 6
    cr_assert_eq(b->size, 3); // Size should remain 3
    }*/
