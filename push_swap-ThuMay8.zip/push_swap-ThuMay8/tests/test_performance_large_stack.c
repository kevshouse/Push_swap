#include <criterion/criterion.h>
#include "../inc/push_swap.h"
#include <time.h>

Test(performance_suite, test_performance_large_stack) {
    t_stack *a = create_stack();
    for (int i = 0; i < 2; i++) {
        push(a, i); // Push a large number of elements
    }

    // Measure time for rotation
    clock_t start = clock();
    for (int i = 0; i < 2; i++) {
        ra(a); // Rotate multiple times
    }
    clock_t end = clock();
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;

    cr_assert_leq(time_spent, 1.0); // Ensure it takes less than 1 second
    free_stack(a);
}
