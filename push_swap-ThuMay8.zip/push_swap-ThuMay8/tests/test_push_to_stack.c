#include <criterion/criterion.h>
#include "../inc/push_swap.h"

Test(push_suite, push_to_empty_stack)
{
    t_stack *stack = create_stack();
    cr_assert_not_null(stack, "Failed to create stack");

    // Push an element
    push(stack, 42);

    // Verify the stack now has one element
    cr_assert_eq(stack->size, 1, "Stack size is incorrect after push");
    cr_assert_not_null(stack->top, "Stack top is NULL after push");
    cr_assert_null(stack->top->prev, "Top node's prev should be NULL");
    cr_assert_not_null(stack->tail, "Stack tail is NULL after push");

    // Verify the value
    cr_assert_eq(stack->top->data, 42, "Incorrect value at top of stack");
    cr_assert_eq(stack->tail->data, 42, "Incorrect value at tail of stack");

    free_stack(stack);
}

// Test pushing multiple elements in order
Test(push_suite, push_multiple_elements)
{
	t_stack *stack = create_stack();
	cr_assert_not_null(stack, "Failed to create stack");
	// Push elements in order: 1, 2, 3
	push(stack, 1);
	push(stack, 2);
	push(stack, 3);
	// Verify stack size
	cr_assert_eq(stack->size, 3, "Stack size is incorrect after multiple pushes");
	// Verify top element
	cr_assert_eq(stack->top->data, 3, "Top element is incorrect");
	// Verify tail element
	cr_assert_eq(stack->tail->data, 1, "Tail element is incorrect");
	free_stack(stack);
}

// Test pushing elements in reverse order
Test(push_suite, push_reverse_order)
{
	t_stack *stack = create_stack();
	cr_assert_not_null(stack, "Failed to create stack");
	// Push elements in reverse order: 3, 2, 1
	push(stack, 3);
	push(stack, 2);
	push(stack, 1);
	// Verify stack size
	cr_assert_eq(stack->size, 3, "Stack size is incorrect after multiple pushes");
	// Verify top element
	cr_assert_eq(stack->top->data, 1, "Top element is incorrect");
	// Verify tail element
	cr_assert_eq(stack->tail->data, 3, "Tail element is incorrect");
	free_stack(stack);
}

// Test pushing negative values
Test(push_suite, push_negative_values)
{
	t_stack *stack = create_stack();
	cr_assert_not_null(stack, "Failed to create stack");
	// Push negative elements
	push(stack, -5);
	push(stack, -10);
	push(stack, -2);
	// Verify stack size
	cr_assert_eq(stack->size, 3, "Stack size is incorrect after pushing negative values");
	// Verify top element
	cr_assert_eq(stack->top->data, -2, "Top element is incorrect");
	// Verify tail element
	cr_assert_eq(stack->tail->data, -5, "Tail element is incorrect");
	free_stack(stack);
}

// Test pushing zero
Test(push_suite, push_zero)
{
	t_stack *stack = create_stack();
	cr_assert_not_null(stack, "Failed to create stack");
	// Push zero
	push(stack, 0);
	// Verify stack size
	cr_assert_eq(stack->size, 1, "Stack size is incorrect after pushing zero");
	// Verify value
	cr_assert_eq(stack->top->data, 0, "Value at top is incorrect");
	cr_assert_eq(stack->tail->data, 0, "Value at tail is incorrect");
	free_stack(stack);
}

// Test pushing to a NULL pointer

Test(push_suite, push_to_null)
{
	// Passing NULL to push should handle gracefully
	push(NULL, 42);
	// No crash expected
}

// Test pushing to an already freed stack
Test(push_suite, push_to_freed_stack)
{
	t_stack *stack = create_stack();
	free_stack(stack);
	// Passing a freed stack to push should handle gracefully
	push(stack, 42);
	// No crash expected
}
