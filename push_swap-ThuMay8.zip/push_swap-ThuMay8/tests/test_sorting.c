#include "../inc/push_swap.h"
#include <criterion/criterion.h>
#include <stdio.h> // Include for printf

// Test cases for calculate_rotations function
Test(cost_suite, test_calculate_rotations_empty_stack) {
    t_stack *stack = create_stack();
    t_rotation_result result = calculate_rotations(stack); // Updated to one argument
    cr_assert_eq(result.error, ROTATION_EMPTY_STACK, "Expected error for empty stack");
    free_stack(stack);
}

Test(cost_suite, test_calculate_rotations_single_element) {
    t_stack *stack = create_stack();
    push(stack, 1); // Assuming push function is defined
    t_rotation_result result = calculate_rotations(stack); // Updated to one argument
    cr_assert_eq(result.rotations, 0, "Expected 0 rotations for single element");
    free_stack(stack);
}

Test(cost_suite, test_calculate_rotations_multiple_elements) {
    t_stack *stack = create_stack();
    push(stack, 3);
    push(stack, 1);
    push(stack, 2);
    t_rotation_result result = calculate_rotations(stack); // Updated to one argument
    printf("Multiple elements test: Expected 1 rotation, got %d\n", result.rotations);
    cr_assert_eq(result.rotations, 1, "Expected 1 rotation to bring minimum to top");
    free_stack(stack);
}

Test(cost_suite, test_calculate_rotations_already_sorted) {
    t_stack *stack = create_stack();
    push(stack, 1);
    push(stack, 2);
    push(stack, 3);
    t_rotation_result result = calculate_rotations(stack); // Updated to one argument
    printf("Already sorted test: Expected 0 rotations, got %d\n", result.rotations);
    cr_assert_eq(result.rotations, 0, "Expected 0 rotations for already sorted stack");
    free_stack(stack);
}

Test(cost_suite, test_calculate_rotations_reverse_sorted) {
    t_stack *stack = create_stack();
    push(stack, 3);
    push(stack, 2);
    push(stack, 1);

    t_rotation_result result = calculate_rotations(stack);

    cr_assert_eq(result.rotations, 2, "Expected 2 rotations to bring minimum to top");

    free_stack(stack);
}

Test(sort_suite, empty_stack) {
        t_stack *stack = create_stack();
        cr_assert_eq(stack->sorted, 1, "Empty stack should be considered sorted");
        free_stack(stack);
}

Test(sort_suite, single_element) {
        t_stack *stack = create_stack();
        push(stack, 42);
        cr_assert_eq(stack->sorted, 1, "Single element stack should be sorted");
        free_stack(stack);
}

Test(sort_suite, reverse_sorted) {
    t_stack *stack = create_stack();
    push(stack, 3);
    push(stack, 2);
    push(stack, 1);

    sort_three(stack);

    if (stack->top != NULL) {
        cr_assert_eq(stack->sorted, 1, "Stack should be sorted after sorting");
    }

    free_stack(stack);
}

Test(sort_suite, stack_should_be_sorted_after_sorting) {
    t_stack *stack = create_stack();
    push(stack, 3);
    push(stack, 2);
    push(stack, 1);
    sort_three(stack);
    cr_assert_eq(stack->sorted, 1, "Stack should be marked as sorted after sorting");
    free_stack(stack);
}
