/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/17 23:15:50 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/17 23:19:01 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/internal.h"

int	pb(t_machine *machine)
{
	if (!machine || !machine->a || !machine->a->top)
		return (0);
	if (stack_push(&machine->a, &machine->b))
	{
		machine->op_count++;
		ft_printf("pb\n"); // Only place where output happens
		return (1);
	}
	return (0);
}