/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/18 23:39:05 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/18 23:48:34 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_MACHINE_H
# define STACK_MACHINE_H

# include "ft_bool.h"

typedef struct s_machine t_machine;

// Initialization/Cleanup
t_machine  *stack_machine_init(int argc, char **argv);
void        stack_machine_free(t_machine *m);

// Core Operations
void        sa(t_machine *m);
void        sb(t_machine *m);
void        pa(t_machine *m);
void        pb(t_machine *m);
void        ra(t_machine *m);
void        rb(t_machine *m);
void        rr(t_machine *m);
void        rra(t_machine *m);
void        rrb(t_machine *m);
void        rrr(t_machine *m);

// Stack Inspection
t_bool      stack_is_sorted(t_machine *m);
int         stack_size_a(t_machine *m);
int         stack_size_b(t_machine *m);

#endif
3. stack_machine_internal.h (Private Implementation)
c
#ifndef STACK_MACHINE_INTERNAL_H
# define STACK_MACHINE_INTERNAL_H

# include "ft_bool.h"

typedef struct s_node {
    int             value;
    struct s_node   *prev;
    struct s_node   *next;
} t_node;

typedef struct s_stack {
    t_node          *top;
    t_node          *bottom;
    int             size;
} t_stack;

struct s_machine {
    t_stack         a;
    t_stack         b;
    t_bool          error_state;
};

// Internal Helpers
t_bool      validate_input(char **args);
t_node      *create_node(int value);
void        stack_add_front(t_stack *s, t_node *new);
void        stack_clear(t_stack *s);

#endif