/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_machine.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/18 23:39:40 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/18 23:39:41 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORTING_MACHINE_H
# define SORTING_MACHINE_H

# include "stack_machine.h"

// Public Sorting Interface
void        sorting_control(t_machine *m);

#endif