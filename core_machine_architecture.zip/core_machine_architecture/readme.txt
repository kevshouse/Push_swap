# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    readme.txt                                         :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2025/05/17 20:33:16 by kevin-ander       #+#    #+#              #
#    Updated: 2025/05/17 20:33:18 by kevin-ander      ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

At the beginning of the project, I thought of the two stacks as a machine
that would only be indirectly viewed or modified. The "push_swap" operators
(pa, pb, rr, etc) would be wrappers used by a sorting_machine section of my
program to talk to the machine that contained the stacks and the real 
operators, push, pop, rotate, rev_rotate, etc, along with loading indexing 
and managing functions. I had hoped that by using that approach, I would keep
the number of functions and amount of code that needs writing/testing/debugging
to a reasonably small number.

I burned too many hours, wrote many hundreds of code lines before I realised that
my project was/patch driven.

Time to refactor, time to remember what I thought at thee beginning.

Never be afraid to kill code, the wastbin is a good warrior to have on one's teem!