/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/05 11:37:36 by keanders          #+#    #+#             */
/*   Updated: 2025/06/05 11:38:41 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MACHINE_H
# define MACHINE_H

# include <stddef.h>
# include <stdlib.h>
# include "ft_bool.h"

/* Stack structures */
typedef struct s_node
{
	int				value;
	struct s_node	*prev;
	struct s_node	*next;
}					t_node;

typedef struct s_stack
{
	size_t			size;
	t_node			*top;
	t_node			*bottom;
}					t_stack;

/* Log levels */
typedef enum e_log_level
{
	LOG_NONE,
	LOG_ERROR,
	LOG_WARNING,
	LOG_INFO,
	LOG_DEBUG
}	t_log_level;

typedef enum e_operation
{
	OP_SA,
	OP_SB,
	OP_SS,
	OP_PA,
	OP_PB,
	OP_RA,
	OP_RB,
	OP_RR,
	OP_RRA,
	OP_RRB,
	OP_RRR,
	OP_INVALID
}	t_operation;

typedef enum e_stack_id
{
	STACK_A,
	STACK_B
}	t_stack_id;

typedef struct s_machine
{
	t_stack			*a;
	t_stack			*b;
	size_t			op_count;
	t_log_level		log_level;
	int				log_fd;
}					t_machine;

void	do_sa(t_machine *m);
void	do_sb(t_machine *m);
void	do_ss(t_machine *m);
void	do_pa(t_machine *m);
void	do_pb(t_machine *m);
void	do_ra(t_machine *m);
void	do_rb(t_machine *m);
void	do_rr(t_machine *m);
void	do_rra(t_machine *m);
void	do_rrb(t_machine *m);
void	do_rrr(t_machine *m);

void	execution_dispatcher(t_machine *m, t_operation op);
size_t	machine_stack_size(const t_machine *m, t_stack_id stack_id);
int	machine_top_value(const t_machine *m, t_stack_id stack_id);
t_bool	machine_is_sorted(const t_machine *m, t_stack_id stack_id);
t_bool	machine_verify_stack_links(const t_machine *m, t_stack_id stack_id);
size_t	machine_op_count(const t_machine *m);

int	execute_operation_from_string(t_machine *m, const char *op_str);
t_stack	*stack_create(void);
void	stack_add_back(t_stack *s, int value);
t_machine	*machine_init(int count, char **values);
void	machine_free(t_machine *m);
void	init_logging(t_machine *m, t_log_level level, const char *filename);
void	log_message(t_machine *m, t_log_level level, const char *msg);
t_bool	ft_isvalidnum(const char *str);
t_bool	ft_issafe(const char *str);
t_bool	has_duplicates(const int *arr, int count);

#endif
