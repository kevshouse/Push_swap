/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_machine.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/05 11:41:28 by keanders          #+#    #+#             */
/*   Updated: 2025/06/05 11:41:35 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORTING_MACHINE_H
# define SORTING_MACHINE_H

# include "../libft/includes/libft.h"
# include "machine.h"

void	sorting_control(t_machine *m);

#endif
