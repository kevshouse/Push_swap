#include "../../include/machine.h"
#include "../../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>
#include <unistd.h>

/* Helper functions */
static t_bool parse_arguments(int count, char **values, int **numbers)
{
	long num;
	int  i;

	*numbers = malloc(count * sizeof(int));
	if(!*numbers)
		return (FT_FALSE);

	i = 0;
	while(i < count)
	{
		if(!ft_isvalidnum(values[i]) || !ft_issafe(values[i]))
		{
			free(*numbers);
			return (FT_FALSE);
		}
		num = ft_atol(values[i]);
		if(num > INT_MAX || num < INT_MIN)
		{
			free(*numbers);
			return (FT_FALSE);
		}
		(*numbers)[i] = (int)num;
		i++;
	}
	return (FT_TRUE);
}

t_bool has_duplicates(const int *arr, int count)
{
	int i;
	int j;

	i = 0;
	while(i < count - 1)
	{
		j = i + 1;
		while(j < count)
		{
			if(arr[i] == arr[j])
				return (FT_TRUE);
			j++;
		}
		i++;
	}
	return (FT_FALSE);
}

static void init_stacks(t_machine *m, int *numbers, int count)
{
	int i;

	m->a = stack_create();
	m->b = stack_create();
	if(!m->a || !m->b)
		return;

	i = 0;
	while(i < count)
	{
		stack_add_back(m->a, numbers[i]);
		i++;
	}
}

/* Public API */
t_machine *machine_init(int count, char **values)
{
	t_machine *m;
	int       *numbers;

	if(count < 0 || (count > 0 && !values))
		return (NULL);

	m = ft_calloc(1, sizeof(t_machine));
	if(!m)
		return (NULL);

	// Initialize logging system
	m->log_level = LOG_WARNING;   // Default to warnings and errors
	m->log_fd    = STDERR_FILENO; // Default to stderr
	m->op_count  = 0;             // Explicit initialization

	if(count > 0)
	{
		if(!parse_arguments(count, values, &numbers))
		{
			log_message(m, LOG_ERROR, "Invalid number format");
			machine_free(m);
			return (NULL);
		}

		if(has_duplicates(numbers, count))
		{
			log_message(m, LOG_ERROR, "Duplicate numbers detected");
			free(numbers);
			machine_free(m);
			return (NULL);
		}

		init_stacks(m, numbers, count);
		free(numbers);
	}
	else
	{
		// Initialize empty stacks for count=0
		m->a = stack_create();
		m->b = stack_create();
	}

	if(!m->a || !m->b)
	{
		log_message(m, LOG_ERROR, "Stack initialization failed");
		machine_free(m);
		return (NULL);
	}

	log_message(m, LOG_INFO, "Machine initialized successfully");
	return (m);
}
