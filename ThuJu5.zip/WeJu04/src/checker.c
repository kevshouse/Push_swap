/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/14 00:00:00 by keanders          #+#    #+#             */
/*   Updated: 2025/01/14 00:00:00 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "get_next_line/get_next_line.h"
#include "../libft/includes/libft.h"
#include <string.h>

/* Forward declaration from operation_parser.c */
int	execute_operation_from_string(t_machine *m, const char *op_str);

static void	cleanup_and_exit(t_machine *m, char *line, int exit_code)
{
	if (line)
		free(line);
	if (m)
		machine_free(m);
	exit(exit_code);
}

static void	print_error_and_exit(t_machine *m, char *line)
{
	ft_putstr_fd("Error\n", STDERR_FILENO);
	cleanup_and_exit(m, line, 1);
}

static void	process_operations(t_machine *m)
{
	char	*line;
	size_t	len;

	while ((line = get_next_line(STDIN_FILENO)) != NULL)
	{
		/* Calculate line length */
		len = 0;
		while (line[len])
			len++;
		
		/* Skip empty lines */
		if (len <= 1)
		{
			free(line);
			continue;
		}
		
		/* Try to execute the operation */
		if (!execute_operation_from_string(m, line))
		{
			print_error_and_exit(m, line);
		}
		
		free(line);
	}
}

static void	check_and_output_result(t_machine *m)
{
	if (machine_is_sorted(m, STACK_A) && machine_stack_size(m, STACK_B) == 0)
		ft_putstr_fd("OK\n", STDOUT_FILENO);
	else
		ft_putstr_fd("KO\n", STDOUT_FILENO);
}

int	main(int argc, char **argv)
{
	t_machine	*m;

	/* Check if we have arguments */
	if (argc < 2)
		return (1);
	
	/* Initialize the machine with the provided arguments */
	m = machine_init(argc - 1, argv + 1);
	if (!m)
	{
		ft_putstr_fd("Error\n", STDERR_FILENO);
		return (1);
	}
	
	/* Process operations from stdin */
	process_operations(m);
	
	/* Check the final state and output result */
	check_and_output_result(m);
	
	/* Clean up and exit */
	machine_free(m);
	return (0);
}