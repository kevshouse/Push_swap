/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:07:11 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:07:13 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# include <limits.h>
# include <stdlib.h>
# include <stdint.h>
# include <unistd.h>
# include "ft_printf.h"

typedef struct	s_split
{
	char	**result;
	size_t	start;
	size_t	end;
	size_t	i;
	size_t	word_count;
}	t_split;

int     ft_printf(const char *format, ...);
int     ft_max(size_t ref, size_t numb);
long	ft_atoi(const char *str);
long	ft_atol(const char *str);
int     ft_abs(int n);
char	**ft_split(char const *s, char c);
void	*ft_memcpy(void *dst, const void *src, size_t n);
int		ft_isdigit(int c);
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *str, int fd);
void	ft_putendl_fd(char *s, int fd);
void    ft_putnbr_fd(int n, int fd);
//void	ft_swap(int *a, int *b);
void	ft_free_split(char **split);
//int		ft_isvalidnum(const char *str);
void    ft_bzero(void* s, size_t n);
void    *ft_calloc(size_t count, size_t size);

#endif
