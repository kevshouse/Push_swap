#include "../includes/libft.h"

void ft_putnbr_const(int n)
{
	ft_putnbr_const_fd(n, STDOUT_FILENO);
}

void ft_putnbr_const_fd(int n, int fd)
{
	ft_putnbr_fd(n, fd);
}