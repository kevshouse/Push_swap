#include "../includes/libft.h"

void ft_putstr_const(const char *s)
{
	ft_putstr_const_fd(s, STDOUT_FILENO);
}
