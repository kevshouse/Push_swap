/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorter.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:05:52 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:09:44 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <limits.h>
#include <stddef.h>
#include <stdlib.h>

// Helper to find index of minimal value in stack
static int find_min_index(t_stack *s)
{
	t_node *current;
	int     min_index;
	int     min_val;
	int     i;

	if(!s || !s->top)
		return (-1);
	min_index = 0;
	min_val   = s->top->value;
	current   = s->top->next;
	i         = 1;
	while(current)
	{
		if(current->value < min_val)
		{
			min_val   = current->value;
			min_index = i;
		}
		current = current->next;
		i++;
	}
	return (min_index);
}

static void insertion_sort(int *arr, size_t size)
{
	size_t i;
	size_t j;
	int    key;

	i = 1;
	while(i < size)
	{
		key = arr[i];
		j   = i;
		while(j > 0 && arr[j - 1] > key)
		{
			arr[j] = arr[j - 1];
			j--;
		}
		arr[j] = key;
		i++;
	}
}

static void sort_three_case(t_machine *m, int a, int b, int c)
{
	if(a < b && b < c)
		return;
	if(a < b && b > c && a < c)
	{
		execution_dispatcher(m, OP_SA);
		execution_dispatcher(m, OP_RA);
	}
	else if(a > b && b < c && a < c)
		execution_dispatcher(m, OP_SA);
	else if(a < b && b > c && a > c)
		execution_dispatcher(m, OP_RRA);
	else if(a > b && b < c && a > c)
		execution_dispatcher(m, OP_RA);
	else if(a > b && b > c)
	{
		execution_dispatcher(m, OP_SA);
		execution_dispatcher(m, OP_RRA);
	}
}

// Helper to create sorted array from stack
static int *create_sorted_arr(t_stack *s)
{
	size_t  i;
	int    *arr;
	t_node *current;

	arr = malloc(s->size * sizeof(int));
	if(!s || !s->top)
		return (NULL);
	i = 0;
	if(!arr)
		return (NULL);
	current = s->top;
	while(i < s->size)
	{
		arr[i]  = current->value;
		current = current->next;
		i++;
	}
	insertion_sort(arr, s->size);
	return (arr);
}

// Calculate rotation cost for an element
static int calculate_rotation_cost(t_machine *m, int index)
{
	int size_b;
	int cost_up;
	int cost_down;

	size_b    = machine_stack_size(m, STACK_B);
	cost_up   = index;
	cost_down = size_b - index;
	if(cost_up < cost_down)
		return (cost_up);
	else
		return (-cost_down);
}

// Rotate element to top of B with minimal operations
static void rotate_to_top_b(t_machine *m, int index)
{
	int cost;
	int i;

	i    = 0;
	cost = calculate_rotation_cost(m, index);
	if(cost > 0)
	{
		while(i < cost)
		{
			execution_dispatcher(m, OP_RB);
			i++;
		}
	}
	else
	{
		while(i < -cost)
		{
			execution_dispatcher(m, OP_RRB);
			i++;
		}
	}
}

static void rotate_min_to_top(t_machine *m, size_t min_index,
                              size_t current_size)
{
	size_t j;

	j = 0;
	if(min_index <= current_size / 2)
	{
		while(j < min_index)
		{
			execution_dispatcher(m, OP_RA);
			j++;
		}
	}
	else
	{
		while(j < current_size - min_index)
		{
			execution_dispatcher(m, OP_RRA);
			j++;
		}
	}
}

// Sort 3 elements
static void sort_three(t_machine *m)
{
	t_node *top;
	t_node *second;
	t_node *third;
	int     a;
	int     b;
	int     c;

	if(!m || !m->a || m->a->size < 3)
		return;
	top    = m->a->top;
	second = top->next;
	third  = second->next;
	a      = top->value;
	b      = second->value;
	c      = third->value;
	sort_three_case(m, a, b, c);
}

static void sort_five(t_machine *m)
{
	size_t size;
	int    push_count;
	int    i;
	size_t min_index;
	size_t current_size;

	size       = m->a->size;
	push_count = size - 3;
	i          = 0;
	while(i < push_count)
	{
		min_index    = (size_t)find_min_index(m->a);
		current_size = m->a->size;
		rotate_min_to_top(m, min_index, current_size);
		execution_dispatcher(m, OP_PB);
		i++;
	}
	sort_three(m);
	i = 0;
	while(i < push_count)
	{
		execution_dispatcher(m, OP_PA);
		i++;
	}
}

static void process_top_element(t_machine *m, int *sorted_arr, int chunk_start,
                                int chunk_end, int median, int *count_in_chunk)
{
	int top;

	top = machine_top_value(m, STACK_A);
	if(top >= sorted_arr[chunk_start] && top <= sorted_arr[chunk_end])
	{
		execution_dispatcher(m, OP_PB);
		(*count_in_chunk)++;
		if(top < median && machine_stack_size(m, STACK_B) > 1)
			execution_dispatcher(m, OP_RB);
	}
	else
	{
		if(top < sorted_arr[chunk_end])
			execution_dispatcher(m, OP_RA);
		else
			execution_dispatcher(m, OP_RRA);
	}
}

typedef struct s_push_chunks_params
{
	int   *sorted_arr;
	size_t size;
	int    chunk_size;
} t_push_chunks_params;

static void push_chunks_to_b(t_machine *m, t_push_chunks_params p)
{
	int chunk_start;
	int chunk_end;
	int count_in_chunk;
	int median;
	int target_count;

	chunk_start = 0;
	while(chunk_start < (int)p.size)
	{
		chunk_end = chunk_start + p.chunk_size;
		if(chunk_end >= (int)p.size)
			chunk_end = p.size - 1;
		median         = p.sorted_arr[chunk_start + (p.chunk_size * 2) / 3];
		count_in_chunk = 0;
		target_count   = chunk_end - chunk_start + 1;
		while(count_in_chunk < target_count)
		{
			process_top_element(m, p.sorted_arr, chunk_start, chunk_end, median,
			                    &count_in_chunk);
		}
		chunk_start = chunk_end + 1;
	}
}

static int find_best_index_in_b(t_machine *m)
{
	int     min_cost;
	int     cost;
	int     best_index;
	int     i;
	t_node *current;

	min_cost   = INT_MAX;
	best_index = 0;
	i          = 0;
	current    = m->b->top;
	while(current)
	{
		cost = calculate_rotation_cost(m, i);
		if(ft_abs(cost) < ft_abs(min_cost))
		{
			min_cost   = cost;
			best_index = i;
		}
		current = current->next;
		i++;
	}
	return (best_index);
}

static void push_b_to_a(t_machine *m)
{
	int best_index;

	while(machine_stack_size(m, STACK_B) > 0)
	{
		best_index = find_best_index_in_b(m);
		rotate_to_top_b(m, best_index);
		execution_dispatcher(m, OP_PA);
	}
}

static void rotate_min_to_top_a(t_machine *m)
{
	int min_index;
	int size_a;
	int cost;
	int k;

	min_index = find_min_index(m->a);
	if(min_index < 0)
		return;
	size_a = m->a->size;
	k      = 0;
	if(min_index < size_a - min_index)
		cost = min_index;
	else
		cost = -(size_a - min_index);
	if(cost > 0)
	{
		while(k++ < cost)
			execution_dispatcher(m, OP_RA);
	}
	else
	{
		while(k++ < -cost)
			execution_dispatcher(m, OP_RRA);
	}
}

// Optimized chunk-based sorting for large stacks
static void chunk_sort(t_machine *m)
{
	size_t               size;
	int                 *sorted_arr;
	int                  chunk_count;
	int                  chunk_size;
	t_push_chunks_params params;

	sorted_arr = create_sorted_arr(m->a);
	size       = m->a->size;
	if(!sorted_arr)
		return;
	if(size <= 100)
		chunk_count = 4;
	else if(size <= 500)
		chunk_count = 18;
	else
		chunk_count = 30;
	chunk_size = size / chunk_count;
	// Initialize parameter struct
	params.sorted_arr = sorted_arr;
	params.size       = size;
	params.chunk_size = chunk_size;
	push_chunks_to_b(m, params);
	free(sorted_arr);
	push_b_to_a(m);
	rotate_min_to_top_a(m);
}

void sorting_control(t_machine *m)
{
	size_t size;

	if(!m || !m->a)
		return;
	if(machine_is_sorted(m, STACK_A))
		return;
	size = m->a->size;
	if(size <= 1)
		return;
	if(size == 2)
	{
		if(m->a->top->value > m->a->top->next->value)
			execution_dispatcher(m, OP_SA);
	}
	else if(size == 3)
		sort_three(m);
	else if(size <= 5)
		sort_five(m);
	else
		chunk_sort(m);
}
