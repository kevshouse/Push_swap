#include "../../include/machine.h"
#include <unistd.h> // For close()
#include <stdlib.h> // For free()

/* Static helpers */
static void free_stack(t_stack *s)
{
	t_node *current;
	t_node *next;

	if(!s)
		return;
	current = s->top;
	while(current)
	{
		next = current->next;
		free(current);
		current = next;
	}
	free(s);
}

static void cleanup_logging(t_machine *m)
{
	if(m->log_fd > STDERR_FILENO) // Close only if it's a custom fd
		close(m->log_fd);
	m->log_fd = -1;
}

/* Public API */
void machine_free(t_machine *m)
{
	if(!m)
		return;

	log_message(m, LOG_DEBUG, "Freeing machine resources");

	// Cleanup logging resources
	cleanup_logging(m);

	// Free stacks
	if(m->a)
		free_stack(m->a);
	if(m->b)
		free_stack(m->b);

	// Free machine itself
	free(m);
}
