#ifndef MACHINE_H
# define MACHINE_H

# include <stddef.h>
# include "ft_bool.h"

// Define node structure
typedef struct s_node {
    int value;
    struct s_node* next;
    struct s_node* prev;
} t_node;

// Define stack structure
typedef struct s_stack {
    t_node* top;
    t_node* bottom;
    size_t size;
} t_stack;

// Define machine structure
typedef struct s_machine {
    t_stack* a;
    t_stack* b;
    size_t op_count;
} t_machine;

typedef enum e_stack_id {
	STACK_A,
	STACK_B
}	t_stack_id;

typedef enum e_operation {
	OP_SA,
	OP_SB,
	OP_SS,
	OP_PA,
	OP_PB,
	OP_RA,
	OP_RB,
	OP_RR,
	OP_RRA,
	OP_RRB,
	OP_RRR
}	t_operation;

/* Machine lifecycle */
t_machine	*machine_init(int count, char **values);
void		machine_free(t_machine *m);

/* Operation execution */
int			machine_execute(t_machine *m, t_operation op);

/* Stack inspection */
int			machine_top_value(const t_machine *m, t_stack_id stack_id);
size_t		machine_stack_size(const t_machine *m, t_stack_id stack_id);

/* Operation counting */
size_t      machine_op_count(const t_machine *m);

/* Validation */
t_bool		machine_is_sorted(const t_machine *m, t_stack_id stack_id);

/* Stack integrity check */
t_bool      machine_verify_stack_links(const t_machine *m, t_stack_id stack_id);

/* Debug */
void machine_print_stack(const t_machine* m, t_stack_id stack_id);

#endif
