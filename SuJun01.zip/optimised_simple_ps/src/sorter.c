#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <stdlib.h>
#include <limits.h>

// Helper to find index of minimal value in stack
static int find_min_index(t_stack *s) {
    if (!s || !s->top) return -1;

    int min_index = 0;
    int min_val = s->top->value;
    t_node *current = s->top->next;
    int i = 1;

    while (current) {
        if (current->value < min_val) {
            min_val = current->value;
            min_index = i;
        }
        current = current->next;
        i++;
    }
    return min_index;
}

// Helper to create sorted array from stack
static int* create_sorted_arr(t_stack *s) {
    if (!s || !s->top) return NULL;

    int *arr = malloc(s->size * sizeof(int));
    if (!arr) return NULL;

    t_node *current = s->top;
    for (size_t i = 0; i < s->size; i++) {
        arr[i] = current->value;
        current = current->next;
    }

    // Insertion sort
    for (size_t i = 1; i < s->size; i++) {
        int key = arr[i];
        size_t j = i;

        while (j > 0 && arr[j - 1] > key) {
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = key;
    }
    return arr;
}

// Calculate rotation cost for an element
static int calculate_rotation_cost(t_machine *m, int index) {
    int size_b = machine_stack_size(m, STACK_B);
    int cost_up = index;
    int cost_down = size_b - index;
    return (cost_up < cost_down) ? cost_up : -cost_down;
}

// Rotate element to top of B with minimal operations
static void rotate_to_top_b(t_machine *m, int index) {
    int cost = calculate_rotation_cost(m, index);
    if (cost > 0) {
        for (int i = 0; i < cost; i++) {
            machine_execute(m, OP_RB);
        }
    } else {
        for (int i = 0; i < -cost; i++) {
            machine_execute(m, OP_RRB);
        }
    }
}

// Sort 3 elements
static void sort_three(t_machine* m) {
    if (!m || !m->a || m->a->size < 3)
        return;

    t_node* top = m->a->top;
    t_node* second = top->next;
    t_node* third = second->next;

    int a = top->value;
    int b = second->value;
    int c = third->value;

    if (a < b && b < c) return;
    if (a < b && b > c && a < c) {
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RA);
    }
    else if (a > b && b < c && a < c) {
        machine_execute(m, OP_SA);
    }
    else if (a < b && b > c && a > c) {
        machine_execute(m, OP_RRA);
    }
    else if (a > b && b < c && a > c) {
        machine_execute(m, OP_RA);
    }
    else if (a > b && b > c) {
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RRA);
    }
}

// -old Sort up to 5 elements
/*
static void sort_five(t_machine* m) {
    for (int i = 0; i < 2; i++) {
        int min_val = INT_MAX;
        size_t min_index = 0;
        size_t size = m->a->size;

        t_node* current = m->a->top;
        for (size_t j = 0; j < size; j++) {
            if (current->value < min_val) {
                min_val = current->value;
                min_index = j;
            }
            current = current->next;
        }

        if (min_index <= size / 2) {
            for (size_t j = 0; j < min_index; j++) {
                machine_execute(m, OP_RA);
            }
        } else {
            for (size_t j = 0; j < size - min_index; j++) {
                machine_execute(m, OP_RRA);
            }
        }

        machine_execute(m, OP_PB);
    }

    sort_three(m);

    machine_execute(m, OP_PA);
    machine_execute(m, OP_PA);

    int min_value = INT_MAX;
    size_t size = m->a->size;
    size_t min_position = 0;
    t_node* current = m->a->top;

    for (size_t i = 0; i < size; i++) {
        if (current->value < min_value) {
            min_value = current->value;
            min_position = i;
        }
        current = current->next;
    }

    if (min_position <= size / 2) {
        for (size_t i = 0; i < min_position; i++) {
            machine_execute(m, OP_RA);
        }
    } else {
        for (size_t i = 0; i < size - min_position; i++) {
            machine_execute(m, OP_RRA);
        }
    }
}*/

// sort_five
static void sort_five(t_machine* m) {
    size_t size = m->a->size;
    int push_count = size - 3;  // 1 for 4 elements, 2 for 5

    for (int i = 0; i < push_count; i++) {
        int min_val = INT_MAX;
        size_t min_index = 0;
        size_t current_size = m->a->size;

        // Find min value and position
        t_node* current = m->a->top;
        for (size_t j = 0; j < current_size; j++) {
            if (current->value < min_val) {
                min_val = current->value;
                min_index = j;
            }
            current = current->next;
        }

        // Bring min to top
        if (min_index <= current_size / 2) {
            for (size_t j = 0; j < min_index; j++) {
                machine_execute(m, OP_RA);
            }
        } else {
            for (size_t j = 0; j < current_size - min_index; j++) {
                machine_execute(m, OP_RRA);
            }
        }

        machine_execute(m, OP_PB);
    }

    // Sort remaining three
    sort_three(m);

    // Push back from B
    for (int i = 0; i < push_count; i++) {
        machine_execute(m, OP_PA);
    }
}

// Optimized chunk-based sorting for large stacks
static void chunk_sort(t_machine *m) {
    size_t size = m->a->size;
    int *sorted_arr = create_sorted_arr(m->a);
    if (!sorted_arr) return;

    // Optimized chunk counts
    int chunk_count;
    if (size <= 100) chunk_count = 4;
    else if (size <= 500) chunk_count = 18;  // Increased for better performance
    else chunk_count = 30;

    int chunk_size = size / chunk_count;
    int chunk_start = 0;

    while (chunk_start < (int)size) {
        int chunk_end = chunk_start + chunk_size;
        if (chunk_end >= (int)size) chunk_end = size - 1;

        // Weighted median (2/3 through chunk)
        int median = sorted_arr[chunk_start + (chunk_size * 2)/3];
        int count_in_chunk = 0;
        int target_count = chunk_end - chunk_start + 1;

        while (count_in_chunk < target_count) {
            int top = machine_top_value(m, STACK_A);

            if (top >= sorted_arr[chunk_start] && top <= sorted_arr[chunk_end]) {
                machine_execute(m, OP_PB);
                count_in_chunk++;

                // Position smaller elements at bottom
                if (top < median && machine_stack_size(m, STACK_B) > 1) {
                    machine_execute(m, OP_RB);
                }
            } else {
                // Smart rotation direction
                if (top < sorted_arr[chunk_end]) {
                    machine_execute(m, OP_RA);
                } else {
                    machine_execute(m, OP_RRA);
                }
            }
        }
        chunk_start = chunk_end + 1;
    }
    free(sorted_arr);

    // Optimized push back to A
    while (machine_stack_size(m, STACK_B) > 0) {
        int min_cost = INT_MAX;
        int best_index = 0;
        t_node *current = m->b->top;

        // Find element with minimal rotation cost
        for (int i = 0; current; i++) {
            int cost = calculate_rotation_cost(m, i);
            if (abs(cost) < abs(min_cost)) {
                min_cost = cost;
                best_index = i;
            }
            current = current->next;
        }

        // Rotate optimal element to top
        rotate_to_top_b(m, best_index);
        machine_execute(m, OP_PA);
    }

    // Final rotation to min element
    int min_index = find_min_index(m->a);
    if (min_index < 0) return;

    int cost = calculate_rotation_cost(m, min_index);
    if (cost > 0) {
        for (int i = 0; i < cost; i++) machine_execute(m, OP_RA);
    } else {
        for (int i = 0; i < -cost; i++) machine_execute(m, OP_RRA);
    }
}

//Old Main sorting control
/*void sorting_control(t_machine* m) {
    if (!m || !m->a) return;
    size_t size = m->a->size;
    if (size <= 1) return;

    if (size == 2) {
        if (m->a->top->value > m->a->top->next->value) {
            machine_execute(m, OP_SA);
        }
    }
    else if (size == 3) {
        sort_three(m);
    }
    else if (size <= 5) {
        sort_five(m);
    }
    else {
        chunk_sort(m);
    }
}*/

void sorting_control(t_machine* m) {
    if (!m || !m->a) return;

    // Check if already sorted
    if (machine_is_sorted(m, STACK_A)) {
        return;
    }

    size_t size = m->a->size;
    if (size <= 1) return;

    if (size == 2) {
        if (m->a->top->value > m->a->top->next->value) {
            machine_execute(m, OP_SA);
        }
    }
    else if (size == 3) {
        sort_three(m);
    }
    else if (size <= 5) {
        sort_five(m);
    }
    else {
        chunk_sort(m);
    }
}
