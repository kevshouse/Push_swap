#!/bin/sh

# Create directory tree for stack machine architecture
mkdir -p \
  includes/ \
  src/stack_machine/operations \
  src/stack_machine/utils \
  src/sorting_machine \
  libft/

# Create essential header files
touch includes/machine.h
touch includes/internal.h

# Create base source files
touch src/stack_machine/machine_init.c
touch src/stack_machine/machine_free.c
touch src/stack_machine/utils/validation.c
touch src/main.c

# Create basic Makefile template
echo "NAME = push_swap

SRC = \\
  src/main.c \\
  src/stack_machine/machine_init.c \\
  src/stack_machine/machine_free.c

INCLUDES = -Iincludes -Ilibft

LIBFT = -Llibft -lft

all: \$(NAME)

\$(NAME):
	\$(MAKE) -C libft
	cc \$(CFLAGS) \$(SRC) \$(INCLUDES) \$(LIBFT) -o \$(NAME)

clean:
	\$(MAKE) -C libft clean

fclean: clean
	rm -f \$(NAME)

re: fclean all

.PHONY: all clean fclean re" > Makefile

# Set permissions
chmod 755 src/stack_machine/operations
chmod 755 src/stack_machine/utils
chmod 755 src/sorting_machine

echo "Directory structure created:"
tree -d