# -*- coding: utf-8 -*-
import os
import sys

import setuptools

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "c_formatter_42"))  # noqa

setuptools.setup()
