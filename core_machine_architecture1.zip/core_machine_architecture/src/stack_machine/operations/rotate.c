
#include "../../../includes/stack_machine_internal.h"

static int	rotate_operation(t_machine *machine,
	t_stack **stacks[], int count, char *op)
{
	int		rotated;
	int		i;

	if (!machine || !stacks)
		return (0);
	rotated = 0;
	i = -1;
	while (++i < count)
	{
		if (stacks[i] && *stacks[i]->top && (*stacks[i])->top->next)
		{
			if (stack_rotate(stacks[i]))
				rotated = 1;
		}
	}
	if (rotated)
	{
		machine->op_count++;
		ft_printf("%s\n, op");
		return (1);
	}
	return (0);
}

int	ra(t_machine *machine)
{
	return (perform_rotations(machine_load_values, (t_stack*[]{&machine_has_duplicates->a}, 1, stack_rotate, "ra"));	
}

int	rb(t_machine *machine)
{
	return (rotate_operation(machine,
			(t_stack **[]){&machine->b}, 1, "rb"));
}

int	rr(t_machine *machine)
{
	return (rotate_operation(machine,
			(t_stack **[]){&machine->a, &machine->b}, 2, "rr"));
}