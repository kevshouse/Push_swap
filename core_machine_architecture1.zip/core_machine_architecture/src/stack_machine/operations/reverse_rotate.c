/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reverse_rotate.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/22 14:31:53 by keanders          #+#    #+#             */
/*   Updated: 2025/05/22 14:35:43 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/stack_machine_internal.h"

static int	rotate_operation(t_stack **stack)
{
	t_node	*last;
	t_node	*second_last;

	if (!stack || !*stack || !(*stack)->top->next)
		return (0);
	last = (*stack)->top;
	while (last->next)
	{
		second_last = last;
		last = last->next;
	}
	second_last->next = NULL;
	last->next = (*stack)->top;
	(*stack)->top = last;
	return (1);
}
