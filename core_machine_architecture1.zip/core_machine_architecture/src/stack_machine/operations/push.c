/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/17 23:15:50 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/22 15:11:48 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
The Blueprint

1.  Core Stack Machine Architecture

src/
├── stack_machine/           # The "engine" managing stacks
│   ├── machine.h            # Public API for sorting algorithms
│   ├── internal.h           # Private stack helpers (not exposed)
│   ├── operations/          # Base stack manipulation
│   │   ├── push.c           # pa/pb implementations
│   │   ├── rotate.c         # ra/rb/rr
│   │   └── reverse_rotate.c # rra/rrb/rrr
│   └── utils/               # Indexing/normalization
├── sorting_machine/         # Algorithms using machine.h API
│   ├── radix_sort.c
│   ├── small_sort.c
│   └── hybrid_sort.c
└── main.c                   # Glue code
*/
#include "../../../includes/stack_machine_internal.h"

static int	ft_push_operation(t_machine *machine,
	t_stack *src, t_stack *dst, char *op)
{
	if (!machine || !src || !dst || !*src || !*dst)
		return (0);
	if (stack_push(src, dst))
	{
		machine->op_count++;
		ft_printf("%s\n", op);
		return (1);
	}
	return (0);
}

int	pa(t_machine *machine)
{
	return (ft_push_operation(machine, &machine->b, &machine->a, "pa"));
}

int	pb(t_machine *machine)
{
	return (ft_push_operation(machine, &machine->a, &machine->b, "pb"));
}


