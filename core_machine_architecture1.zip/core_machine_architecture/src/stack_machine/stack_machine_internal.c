/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine_internal.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/22 15:58:14 by keanders          #+#    #+#             */
/*   Updated: 2025/05/22 16:27:54 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/stack_machine_internal.h"

static int	perform_rotations(
	t_machine	*machine,
	t_machine	*stacks[],
	int count,
	void (*rotate_fn)(t_stack),
	char *op	
)
{
	int		rotated;
	int		i;

	if (!machine || !stacks)
		return (0);
	rotated = 0;
	i = -1;
	while (++i < count)
	{
		if (stacks[i] && stacks[i]->top && stacks[i]->top->next)
		{
			rotate_fn(stacks[i]);
			rotated = 1;
		}
		if (rotated)
		{
			machine->op_count++;
			ft_printf("%s\n", op);
			return (1);
		}
		return (0);
	}
}
