/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   machine.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/17 23:13:51 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/22 14:48:14 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// # Public API for sorting algorithms

#ifndef MACHINE_H
# define MACHINE_H

# include <stddef.h>
# include "ft_bool.h"

typedef struct s_machine	t_machine;

/* Machine lifecycle */
t_machine					*machine_init(void);
void						machine_free(t_machine *m);
void						machine_error(t_machine *m);

/* Stack initialization */
void						machine_load_values(t_machine *m, int count,
								char **values);

/* Core operations */
int							sa(t_machine *m);
int							sb(t_machine *m);
int							ss(t_machine *m);
int							pa(t_machine *m);
int							pb(t_machine *m);
int							ra(t_machine *m);
int							rb(t_machine *m);
int							rr(t_machine *m);
int							rra(t_machine *m);
int							rrb(t_machine *m);
int							rrr(t_machine *m);

/* Stack inspection (const-safe) */
int							machine_top_value(const t_machine *m, int stack_id);
int							machine_size(const t_machine *m, int stack_id);
const int					*machine_values(const t_machine *m, int stack_id);

/* Validation */
bool						machine_is_sorted(const t_machine *m, int stack_id);
bool						machine_has_duplicates(const t_machine *m);

#endif