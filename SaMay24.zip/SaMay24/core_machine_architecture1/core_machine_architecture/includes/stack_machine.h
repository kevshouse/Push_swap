/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/18 23:39:05 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/22 14:47:40 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_MACHINE_H
# define STACK_MACHINE_H

# include <stddef.h>
# include "ft_bool.h"
# include "../libft/includes/ft_printf.h"

typedef struct s_machine	t_machine;

// Initialization/Cleanup
t_machine					*stack_machine_init(int argc, char **argv);
void						stack_machine_free(t_machine *m);

// Core Operations
void						sa(t_machine *m);
void						sb(t_machine *m);
void						pa(t_machine *m);
void						pb(t_machine *m);
void						ra(t_machine *m);
void						rb(t_machine *m);
void						rr(t_machine *m);
void						rra(t_machine *m);
void						rrb(t_machine *m);
void						rrr(t_machine *m);

// Stack Inspection
t_bool						stack_is_sorted(t_machine *m);
int							stack_size_a(t_machine *m);
int							stack_size_b(t_machine *m);

#endif
