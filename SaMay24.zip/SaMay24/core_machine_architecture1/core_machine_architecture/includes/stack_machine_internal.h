/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine_internal.h                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/17 23:11:56 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/05/22 16:25:23 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// # Private stack helpers (not exposed)

#ifndef STACK_MACHINE_INTERNAL_H
# define STACK_MACHINE_INTERNAL_H

# include <stddef.h>
# include "ft_bool.h"
# include "machine.h"
# include <stdlib.h>
typedef enum e_stack_id
{
	STACK_A,
	STACK_B
}					t_stack_id;

typedef struct s_node
{
	int				value;
	int				index;
	struct s_node	*next;
	struct s_node	*prev;
}					t_node;

typedef struct s_stack
{
	t_node			*top;
	t_node			*bottom;
	int				size;
}					t_stack;

struct				s_machine
{
	t_stack			*a;
	t_stack			*b;
	int				op_count;
	t_bool			debug_mode;
};

/* Stack core operations */
void				stack_rotate(t_stack *s);
void				stack_reverse_rotate(t_stack *s);
t_bool              stack_push(t_stack *stack, int value);
t_bool              stack_pop(t_stack *stack, int *value);
void				stack_swap(t_stack *s);
t_bool              swap_nodes(t_stack *stack);

/* Stack initialization helpers */
t_bool				stack_add_back(t_stack *s, int value);
t_bool				stack_add_front(t_stack *s, int value);

/* Stack lifecycle */
t_stack *stack_create(void);
void    stack_destroy(t_stack *stack);

/* Indexing and validation */
void				stack_index(t_stack *s);
int                 stack_find_position(const t_stack *stack, int value);
t_bool				stack_has_duplicates(t_stack *s);
t_bool				stack_is_sorted(t_stack *s);

/* Debug utilities */
void				stack_print(t_stack *s, const char *name);

#endif
