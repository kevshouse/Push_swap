#include "../includes/stack_machine_internal.h"
#include <criterion/criterion.h> // Correct header

Test(stack, push_pop)
{
	t_stack *stack = stack_create();
	cr_assert_not_null(stack, "Stack creation failed");

	cr_assert(stack_push(stack, 42), "Push failed");
	cr_assert_eq(stack->top->value, 42, "Top value mismatch");

	int val;
	cr_assert(stack_pop(stack, &val), "Pop failed");
	cr_assert_eq(val, 42, "Popped value mismatch");

	stack_destroy(stack);
}
