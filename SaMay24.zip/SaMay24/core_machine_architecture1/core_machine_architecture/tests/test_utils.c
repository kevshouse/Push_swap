// #include "../includes/stack_machine_internal.h"
// #include <criterion/criterion.h>
