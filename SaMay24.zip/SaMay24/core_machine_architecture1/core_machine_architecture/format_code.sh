#!/bin/bash

# format_code.sh - A script to format C files according to Allman style
# Uses the .clang-format file in the project root

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Check if clang-format is installed
if ! command -v clang-format &> /dev/null; then
    echo -e "${RED}Error: clang-format is not installed.${NC}"
    echo "Please install clang-format to use this script."
    exit 1
fi

# Function to format a single file
format_file() {
    local file="$1"
    if [[ ! -f "$file" ]]; then
        echo -e "${RED}Error: File not found: $file${NC}"
        return 1
    fi
    
    # Only format C files
    if [[ "$file" != *.c && "$file" != *.h ]]; then
        echo -e "${YELLOW}Skipping non-C file: $file${NC}"
        return 0
    fi
    
    echo -e "${GREEN}Formatting: $file${NC}"
    clang-format -style=file -i "$file"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Successfully formatted: $file${NC}"
    else
        echo -e "${RED}Failed to format: $file${NC}"
        return 1
    fi
}

# Function to format all C files in a directory
format_directory() {
    local dir="$1"
    if [[ ! -d "$dir" ]]; then
        echo -e "${RED}Error: Directory not found: $dir${NC}"
        return 1
    fi
    
    echo -e "${GREEN}Formatting all C files in: $dir${NC}"
    find "$dir" -type f \( -name "*.c" -o -name "*.h" \) -print0 | while IFS= read -r -d $'\0' file; do
        format_file "$file"
    done
}

# Main script
if [ $# -eq 0 ]; then
    echo "Usage: $0 [file.c ... | directory ...]"
    echo "  - Format specific C files by listing them as arguments"
    echo "  - Format all C files in directories by listing directories as arguments"
    echo "  - Without arguments, formats the current directory"
    format_directory "."
else
    for path in "$@"; do
        if [ -f "$path" ]; then
            format_file "$path"
        elif [ -d "$path" ]; then
            format_directory "$path"
        else
            echo -e "${RED}Error: Path not found: $path${NC}"
        fi
    done
fi

echo -e "${GREEN}Formatting complete!${NC}"