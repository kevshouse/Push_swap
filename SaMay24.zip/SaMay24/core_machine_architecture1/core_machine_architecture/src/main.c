
// src/main.c
#include "../includes/stack_machine.h"

int main(int argc, char **argv)
{
	t_machine *machine = stack_machine_init(argc, argv);
	// sorting_control(machine); // Trigger sorting logic
	stack_machine_free(machine);
	return (0);
}
