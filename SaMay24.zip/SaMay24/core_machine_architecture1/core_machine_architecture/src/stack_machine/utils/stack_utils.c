#include "../../../includes/stack_machine_internal.h"

int stack_find_position(const t_stack *stack, int value)
{
	t_node *current = stack->top;
	int pos;

	pos = 0;
	while (current)
	{
		if (current->value == value)
			return (pos);
		current = current->next;
		pos++;
	}
	return (-1);
}

t_bool swap_nodes(t_stack *stack)
{
	if (!stack || stack->size < 2)
		return (FT_FALSE);

	t_node *first = stack->top;
	t_node *second = first->next;

	// Swap logic
	first->next = second->next;
	second->next = first;
	stack->top = second;

	// Update prev pointers (critical for doubly linked lists)
	first->prev = second;
	second->prev = NULL;
	if (first->next)
		first->next->prev = first;
	return (FT_TRUE);
}

t_stack *stack_create(void)
{
	t_stack *stack = malloc(sizeof(t_stack));
	if (!stack)
		return (NULL);
	stack->top = NULL;
	stack->bottom = NULL;
	stack->size = 0;
	return (stack);
}

void stack_destroy(t_stack *stack)
{
	if (!stack)
		return;

	t_node *current = stack->top;
	while (current)
	{
		t_node *next = current->next;
		free(current);
		current = next;
	}
	free(stack);
}
