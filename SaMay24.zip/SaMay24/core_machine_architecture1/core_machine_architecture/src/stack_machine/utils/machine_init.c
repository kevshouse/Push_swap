#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/libft.h"

t_machine *stack_machine_init(int argc, char **argv)
{
	t_machine *machine = malloc(sizeof(t_machine));
	if (!machine)
		return NULL;

	machine->a = stack_create();
	machine->b = stack_create();
	machine->op_count = 0;
	machine->debug_mode = FT_FALSE;

	// Load initial values into Stack A (example logic)
	for (int i = 1; i < argc; i++)
	{
		int value = ft_atoi(argv[i]);
		stack_push(machine->a, value);
	}
	// refactor, refactor, refactor!!!

	return (machine);
}
