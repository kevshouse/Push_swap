/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_r_rotate.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/22 14:31:53 by keanders          #+#    #+#             */
/*   Updated: 2025/05/22 14:35:43 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/ft_printf.h"

static int reverse_rotate_stack(t_stack **s)
{
	if (!s || !*s || !(*s)->bottom || !(*s)->bottom->prev)
		return 0;

	t_node *old_bottom = (*s)->bottom;
	(*s)->bottom = old_bottom->prev;
	(*s)->bottom->next = NULL;

	old_bottom->next = (*s)->top;
	(*s)->top->prev = old_bottom;
	(*s)->top = old_bottom;
	return 1;
}

int rra(t_machine *m)
{
	if (reverse_rotate_stack(&m->a))
	{
		m->op_count++;
		ft_printf("rra\n");
		return 1;
	}
	return 0;
}

int rrb(t_machine *m)
{
	if (reverse_rotate_stack(&m->b))
	{
		m->op_count++;
		ft_printf("rrb\n");
		return 1;
	}
	return 0;
}

int rrr(t_machine *m)
{
	int a_rotated = reverse_rotate_stack(&m->a);
	int b_rotated = reverse_rotate_stack(&m->b);

	if (a_rotated || b_rotated)
	{
		m->op_count++;
		ft_printf("rrr\n");
		return 1;
	}
	return 0;
}
