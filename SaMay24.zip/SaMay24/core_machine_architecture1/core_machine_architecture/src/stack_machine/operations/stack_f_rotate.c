#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/ft_printf.h"

static int rotate_stack(t_stack **s)
{
	if (!s || !*s || !(*s)->top->next)
		return (0);
	t_node *old_top = (*s)->top;

	(*s)->top = old_top->next;
	old_top->next = NULL;
	old_top->prev = (*s)->bottom;
	if ((*s)->bottom)
		(*s)->bottom->next = old_top;
	else
		(*s)->bottom = old_top;
	(*s)->bottom = old_top;
	(*s)->top->prev = NULL;
	return (1);
}

int ra(t_machine *m)
{
	if (rotate_stack(&m->a))
	{
		m->op_count++;
		ft_printf("ra\n");
		return (1);
	}
	return (0);
}

int rb(t_machine *m)
{
	if (rotate_stack(&m->b))
	{
		m->op_count++;
		ft_printf("rb\n");
		return (1);
	}
	return (0);
}

int rr(t_machine *m)
{
	int a_rotated = rotate_stack(&m->a);
	int b_rotated = rotate_stack(&m->b);

	if (a_rotated || b_rotated)
	{
		m->op_count++;
		ft_printf("rr\n");
		return (1);
	}
	return (0);
}
