#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/ft_printf.h"

int sa(t_machine *m)
{
	if (!m || !m->a)
		return (0);

	if (swap_nodes(m->a))
	{
		m->op_count++;
		ft_printf("sa\n");
		return (1);
	}
	return (0);
}

int sb(t_machine *m)
{
	if (!m || !m->b)
		return (0);

	if (swap_nodes(m->b))
	{
		m->op_count++;
		ft_printf("sb\n");
		return (1);
	}
	return (0);
}

int ss(t_machine *m)
{
	int a_swapped = swap_nodes(m->a);
	int b_swapped = swap_nodes(m->b);

	if (a_swapped || b_swapped)
	{
		m->op_count++;
		ft_printf("ss\n");
		return (1);
	}
	return (0);
}
