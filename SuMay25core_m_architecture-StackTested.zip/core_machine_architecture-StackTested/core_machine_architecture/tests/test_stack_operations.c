#include "../includes/stack_machine_internal.h"
#include <criterion/criterion.h> // Correct header

Test(stack, push_pop)
{
	t_stack *stack = stack_create();
	cr_assert_not_null(stack, "Stack creation failed");

	cr_assert(stack_push(stack, 42), "Push failed");
	cr_assert_eq(stack->size, 1, "Stack size should be 1 after push");
	cr_assert_eq(stack->top->value, 42, "Top value mismatch");

	int val;
	cr_assert(stack_pop(stack, &val), "Pop failed");
	cr_assert_eq(val, 42, "Popped value mismatch");
	cr_assert_eq(stack->size, 0, "Stack size should be 0 after pop");
	stack_destroy(stack);
}

// Test edge cases (empty stack)
Test(stack_ops, pop_empty_stack) {
    t_stack *stack = stack_create();
    int val;
    cr_assert_not(stack_pop(stack, &val), "Pop should fail on empty stack");
    stack_destroy(stack);
}

Test(stack, create_and_destroy) {
    t_stack *stack = stack_create();
    cr_assert_not_null(stack, "Stack creation failed");
    cr_assert_eq(stack->size, 0, "New stack size should be 0");
    cr_assert_null(stack->top, "New stack top should be NULL");
    cr_assert_null(stack->bottom, "New stack bottom should be NULL");
    stack_destroy(stack);
}

Test(stack, push_multiple) {
    t_stack *stack = stack_create();

    // Push 3 values
    cr_assert(stack_push(stack, 1));
    cr_assert(stack_push(stack, 2));
    cr_assert(stack_push(stack, 3));

    // Verify size and order
    cr_assert_eq(stack->size, 3, "Stack size should be 3");
    cr_assert_eq(stack->top->value, 3, "Top should be 3");
    cr_assert_eq(stack->bottom->value, 1, "Bottom should be 1");

    stack_destroy(stack);
}

Test(stack, pop_multiple) {
    t_stack *stack = stack_create();
    stack_push(stack, 10);
    stack_push(stack, 20);

    int val;
    cr_assert(stack_pop(stack, &val));
    cr_assert_eq(val, 20, "First pop should return 20");
    cr_assert_eq(stack->size, 1, "Size should be 1 after first pop");

    cr_assert(stack_pop(stack, &val));
    cr_assert_eq(val, 10, "Second pop should return 10");
    cr_assert_eq(stack->size, 0, "Size should be 0 after second pop");

    stack_destroy(stack);
}

Test(stack, rotate) {
    t_stack *stack = stack_create();
    stack_push(stack, 3);
    stack_push(stack, 2);
    stack_push(stack, 1);  // Stack: [1, 2, 3] (top to bottom)

    stack_rotate(stack);   // After rotation: [2, 3, 1]

    cr_assert_eq(stack->top->value, 2, "Top should be 2 after rotate");
    cr_assert_eq(stack->bottom->value, 1, "Bottom should be 1 after rotate");
    cr_assert_eq(stack->size, 3, "Size should remain 3");

    stack_destroy(stack);
}

Test(stack, reverse_rotate) {
    t_stack *stack = stack_create();
    
    // Create the stack with 3 elements
    cr_assert(stack_push(stack, 3), "Push 3 failed");
    cr_assert(stack_push(stack, 2), "Push 2 failed");
    cr_assert(stack_push(stack, 1), "Push 1 failed");
    
    // Verify stack state before operation
    cr_assert_eq(stack->size, 3, "Stack size should be 3 before rotate");
    cr_assert_eq(stack->top->value, 1, "Top should be 1 before rotate");
    cr_assert_eq(stack->bottom->value, 3, "Bottom should be 3 before rotate");
    
    // Verify linked list integrity
    cr_assert_null(stack->top->prev, "Top's prev should be NULL");
    cr_assert_eq(stack->top->next->value, 2, "Top's next should be 2");
    cr_assert_eq(stack->top->next->prev, stack->top, "Middle's prev should point to top");
    cr_assert_null(stack->bottom->next, "Bottom's next should be NULL");
    cr_assert_eq(stack->bottom->prev->value, 2, "Bottom's prev should be 2");
    
    // Perform the operation with a safeguard
    if (stack->size >= 2 && stack->top && stack->bottom) {
        stack_reverse_rotate(stack);  // After reverse rotate: [3, 1, 2]
    }
    
    // Verify result
    cr_assert_eq(stack->size, 3, "Stack size should still be 3");
    cr_assert_eq(stack->top->value, 3, "Top should be 3 after reverse rotate");
    cr_assert_eq(stack->bottom->value, 2, "Bottom should be 2 after reverse rotate");
    
    // Verify linked list integrity after operation
    cr_assert_null(stack->top->prev, "New top's prev should be NULL");
    cr_assert_eq(stack->top->next->value, 1, "New top's next should be 1");
    cr_assert_null(stack->bottom->next, "New bottom's next should be NULL");
    
    stack_destroy(stack);
}

Test(stack, swap) {
    t_stack *stack = stack_create();
    stack_push(stack, 2);
    stack_push(stack, 1);  // Stack: [1, 2]

    stack_swap(stack);     // After swap: [2, 1]

    cr_assert_eq(stack->top->value, 2, "Top should be 2 after swap");
    cr_assert_eq(stack->top->next->value, 1, "Second element should be 1");

    stack_destroy(stack);
}

Test(stack, push_null_stack) {
    cr_assert_not(stack_push(NULL, 42), "Push to NULL stack should fail");
}

Test(stack, destroy_non_empty) {
    t_stack *stack = stack_create();
    stack_push(stack, 42);
    stack_destroy(stack);  // Should not crash or leak memory
}

Test(stack, stress_test) {
    t_stack *stack = stack_create();

    // Push 1000 elements
    for (int i = 0; i < 1000; i++) {
        cr_assert(stack_push(stack, i));
    }
    cr_assert_eq(stack->size, 1000, "Size should be 1000");

    // Pop all elements
    int val;
    for (int i = 999; i >= 0; i--) {
        cr_assert(stack_pop(stack, &val));
        cr_assert_eq(val, i, "Popped value mismatch");
    }

    stack_destroy(stack);
}

Test(stack, is_sorted) {
    t_stack *stack = stack_create();
    stack_push(stack, 3);
    stack_push(stack, 2);
    stack_push(stack, 1);  // Stack: [1, 2, 3] (sorted ascending)

    cr_assert(stack_is_sorted(stack, ASCENDING), "Stack should be sorted ascending");
    cr_assert_not(stack_is_sorted(stack, DESCENDING), "Stack should not be sorted descending");

    stack_destroy(stack);
    }
