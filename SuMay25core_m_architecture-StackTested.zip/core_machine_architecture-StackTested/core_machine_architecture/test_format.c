#include <stdio.h>
#include <stdlib.h>

// This function has K&R style braces (not Allman)
int add(int a, int b){
	return a + b;
}

// This function has inconsistent formatting
void print_numbers(int start, int end)
{
	for (int i = start; i <= end; i++)
	{
		printf("%d ", i);
		if (i % 5 == 0)
		{
			printf("(divisible by 5)");
		}
	}
	printf("\n");
}

// This function has mixed styles and bad spacing
int calculate_something(int x, int y, int z)
{
	if (x > 10)
	{
		return x * y + z;
	}
	else
	{
		int result = 0;
		for (int i = 0; i < x; i++)
		{
			result += (y * i) - z;
		}
		return result;
	}
}

int main()
{
	int result = add(5, 10);
	printf("Result of add: %d\n", result);

	printf("Printing numbers from 1 to 20:\n");
	print_numbers(1, 20);

	int calc = calculate_something(15, 3, 7);
	printf("Result of calculation: %d\n", calc);

	// Messy if-else structure
	if (result > 10)
		printf("Result is greater than 10\n");
	else
	{
		printf("Result is not greater than 10\n");
	}

	return 0;
}
