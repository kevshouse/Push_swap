int main() {
    int x = 5;
    if (x > 3) {
        printf("Hello, World!\n");
    }
    return (0);
}
