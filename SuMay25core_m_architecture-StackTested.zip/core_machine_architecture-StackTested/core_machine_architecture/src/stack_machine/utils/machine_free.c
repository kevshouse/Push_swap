#include "../../../includes/stack_machine_internal.h"

void stack_machine_free(t_machine *m)
{
	if (!m)
		return;

	stack_destroy(m->a);
	stack_destroy(m->b);
	free(m);
}
