#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/ft_printf.h"

#include "../../../includes/stack_machine_internal.h"

void stack_rotate(t_stack *s) {
    if (!s || s->size < 2)
        return;

    t_node *old_top = s->top;
    s->top = old_top->next;
    old_top->next = NULL;

    // Update bottom
    s->bottom->next = old_top;
    s->bottom = old_top;

    // Update prev pointers (if using a doubly linked list)
    old_top->prev = s->bottom;
    s->top->prev = NULL;
}

#include "../../../includes/stack_machine_internal.h"

void stack_reverse_rotate(t_stack *s) {
    // Basic validation - exit early if impossible to rotate
    if (!s || s->size < 2 || !s->top || !s->bottom)
        return;
    
    // Handle the special case of 2 elements
    if (s->size == 2) {
        stack_swap(s);
        return;
    }
    
    // Save references to key nodes
    t_node *old_bottom = s->bottom;
    t_node *new_bottom = old_bottom->prev;
    t_node *old_top = s->top;
    
    // Extra defensive check - make sure linked list integrity is maintained
    if (!new_bottom || !old_top || old_bottom == old_top)
        return;
    
    // Detach the bottom node from its current position
    new_bottom->next = NULL;
    
    // Re-link the old bottom as the new top
    old_bottom->prev = NULL;
    old_bottom->next = old_top;
    old_top->prev = old_bottom;
    
    // Update stack pointers
    s->top = old_bottom;
    s->bottom = new_bottom;
}

static int rotate_stack(t_stack **s)
{
	if (!s || !*s || !(*s)->top->next)
		return (0);
	t_node *old_top = (*s)->top;

	(*s)->top = old_top->next;
	old_top->next = NULL;
	old_top->prev = (*s)->bottom;
	if ((*s)->bottom)
		(*s)->bottom->next = old_top;
	else
		(*s)->bottom = old_top;
	(*s)->bottom = old_top;
	(*s)->top->prev = NULL;
	return (1);
}

int ra(t_machine *m)
{
	if (rotate_stack(&m->a))
	{
		m->op_count++;
		ft_printf("ra\n");
		return (1);
	}
	return (0);
}

int rb(t_machine *m)
{
	if (rotate_stack(&m->b))
	{
		m->op_count++;
		ft_printf("rb\n");
		return (1);
	}
	return (0);
}

int rr(t_machine *m)
{
	int a_rotated = rotate_stack(&m->a);
	int b_rotated = rotate_stack(&m->b);

	if (a_rotated || b_rotated)
	{
		m->op_count++;
		ft_printf("rr\n");
		return (1);
	}
	return (0);
}
