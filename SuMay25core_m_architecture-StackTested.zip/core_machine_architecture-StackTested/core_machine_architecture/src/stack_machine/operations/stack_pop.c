#include "../../../includes/stack_machine_internal.h"

t_bool stack_pop(t_stack *stack, int *value)
{
	if (!stack || !stack->top || !value)
		return (FT_FALSE);
	t_node *node_to_remove;

	node_to_remove = stack->top;
	*value = node_to_remove->value;
	stack->top = node_to_remove->next;
	if (stack->top)
		stack->top->prev = NULL;  // Set new top's prev to NULL
	if (stack->size == 1)
	{
		stack->bottom = NULL;
	}
	free(node_to_remove);
	stack->size--;
	return (FT_TRUE);
}
