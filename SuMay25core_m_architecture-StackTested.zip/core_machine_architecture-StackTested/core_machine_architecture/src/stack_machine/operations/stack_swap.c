#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/ft_printf.h"  // If you use ft_printf

void stack_swap(t_stack *s) {
    if (!s || s->size < 2)
        return;

    t_node *first = s->top;
    t_node *second = first->next;

    // Swap the first two nodes
    first->next = second->next;
    second->next = first;
    s->top = second;

    // Update prev pointers (for doubly linked lists)
    first->prev = second;
    second->prev = NULL;
    if (first->next)
        first->next->prev = first;

    // Update bottom pointer if there are only two elements
    if (s->size == 2)
        s->bottom = first;
}

// Operations for sa, sb, ss
int sa(t_machine *m) {
    if (!m || !m->a || m->a->size < 2)
        return 0;
    stack_swap(m->a);
    m->op_count++;
    ft_printf("sa\n");
    return 1;
}

int sb(t_machine *m) {
    if (!m || !m->b || m->b->size < 2)
        return 0;
    stack_swap(m->b);
    m->op_count++;
    ft_printf("sb\n");
    return 1;
}

int ss(t_machine *m) {
    int a_swapped = sa(m);
    int b_swapped = sb(m);
    if (a_swapped || b_swapped) {
        m->op_count--;  // sa/sb already incremented op_count
        ft_printf("ss\n");
        return 1;
    }
    return 0;
}
