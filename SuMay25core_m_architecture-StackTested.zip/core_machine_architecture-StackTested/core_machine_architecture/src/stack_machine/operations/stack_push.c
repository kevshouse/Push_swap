#include "../../../includes/stack_machine_internal.h"
#include "../../../libft/includes/ft_printf.h"

t_bool stack_push(t_stack *stack, int value)
{
	t_node *new_node;

	if (!stack)
		return (FT_FALSE);
	new_node = malloc(sizeof(t_node));
	if (!new_node)
		return (FT_FALSE);
	new_node->value = value;
	new_node->next = stack->top;
	new_node->prev = NULL;  // New node becomes top, so prev is NULL
	
	if (stack->top)
		stack->top->prev = new_node;  // Set old top's prev to new node
		
	stack->top = new_node;
	if (stack->size == 0)
	{
		stack->bottom = new_node;
	}
	stack->size++;
	return (FT_TRUE);
}

int pa(t_machine *m)
{
	int value;

	if (stack_pop(m->b, &value) && stack_push(m->a, value))
	{
		m->op_count++;
		ft_printf("pa\n");
		return (1);
	}
	return (0);
}

int pb(t_machine *m)
{
	int value;

	if (stack_pop(m->a, &value) && stack_push(m->b, value))
	{
		m->op_count++;
		ft_printf("pb\n");
		return (1);
	}
	return (0);
}
