#include "includes/stack_machine_internal.h"
#include <stdio.h>
#include <stdlib.h>

// Simple debugging function to print the stack contents
void debug_print_stack(t_stack *stack, const char *label) {
    printf("\n=== %s ===\n", label);
    if (!stack) {
        printf("Stack is NULL\n");
        return;
    }
    
    printf("Stack size: %d\n", stack->size);
    printf("Top node: %p\n", (void*)stack->top);
    printf("Bottom node: %p\n", (void*)stack->bottom);
    
    int i = 0;
    t_node *current = stack->top;
    while (current) {
        printf("Node %d: value=%d, addr=%p, next=%p, prev=%p\n",
               i++, current->value, (void*)current, (void*)current->next, (void*)current->prev);
        current = current->next;
    }
    printf("\n");
}

// Function to check if the stack pointers are consistent
void check_stack_integrity(t_stack *stack) {
    if (!stack) {
        printf("Stack is NULL\n");
        return;
    }
    
    // Check if size is consistent with node count
    int count = 0;
    t_node *current = stack->top;
    while (current) {
        count++;
        current = current->next;
    }
    
    if (count != stack->size) {
        printf("INTEGRITY ERROR: Node count (%d) != stack size (%d)\n", count, stack->size);
    } else {
        printf("Size check: OK\n");
    }
    
    // Check doubly-linked list integrity
    int errors = 0;
    current = stack->top;
    t_node *prev = NULL;
    
    while (current) {
        if (current->prev != prev) {
            printf("INTEGRITY ERROR: Node %p has prev=%p, expected %p\n", 
                   (void*)current, (void*)current->prev, (void*)prev);
            errors++;
        }
        prev = current;
        current = current->next;
    }
    
    if (prev != stack->bottom) {
        printf("INTEGRITY ERROR: Last node (%p) != stack->bottom (%p)\n", 
               (void*)prev, (void*)stack->bottom);
        errors++;
    }
    
    if (errors == 0) {
        printf("Pointer integrity: OK\n");
    }
}

int main() {
    // Create a new stack
    t_stack *stack = stack_create();
    if (!stack) {
        printf("Stack creation failed\n");
        return 1;
    }
    
    // Push some values (3, 2, 1) to match test case
    printf("Pushing values 3, 2, 1 to stack\n");
    stack_push(stack, 3);
    stack_push(stack, 2);
    stack_push(stack, 1);
    
    // Check initial stack state
    debug_print_stack(stack, "Initial Stack");
    check_stack_integrity(stack);
    
    // Apply reverse rotate
    printf("\nApplying stack_reverse_rotate\n");
    stack_reverse_rotate(stack);
    
    // Check stack after operation
    debug_print_stack(stack, "After Reverse Rotate");
    check_stack_integrity(stack);
    
    // Clean up
    stack_destroy(stack);
    printf("Stack destroyed\n");
    
    return 0;
}